import datetime,difflib,hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-src')
RED=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-redfinal-src')
OUT=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-evidence')
RUN=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot')
ARCHIVE=OUT.parent/'workflow-canonical-duplicate-schedule-20261020-raw.tar.gz'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=dict(parent_commit='25dcf84eb5afbb5e7613f1275ccf7cdee14c521a',published_base='18175834a9df99aeda94786e6d804570c25f6083',complete=True,compile_receipts_reused=False,fresh_cpp_build=False,native_artifact_reused=True,legacy_artifact_reused=True,native={},red={},cleanup_drills={},owners={},source_objects={},generated_rust_outputs={})
for stage in ['redfinal','greenfinal']:
    gates=json.loads((OUT/(stage+'-gates.json')).read_text());owner=json.loads((OUT/(stage+'.json')).read_text());parent=json.loads((OUT/(stage+'-parent.json')).read_text())
    assert gates['complete'] and gates['source_unchanged'] and all(g.get('accepted') and g['waited_by_original_parent'] for g in gates['gates'])
    assert owner['complete'] and owner['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
    assert parent['complete'] and parent['owner_waited'] and parent['owner_wait_returncode']==0
    sd=subprocess.run(['systemctl','show','canonical-duplicate-'+stage,'-p','MainPID','-p','ActiveState','-p','Result','-p','ExecMainStatus'],capture_output=True,text=True,check=True).stdout
    assert 'MainPID=0' in sd and 'ActiveState=inactive' in sd and 'Result=success' in sd
    summary['owners'][stage]=dict(gates=gates,systemd=sd,parent_sha256=digest(OUT/(stage+'-parent.json')),owner_sha256=digest(OUT/(stage+'.json')))
for folder in ['canonical','migration','lifecycle','spawn']:
    path=OUT/f'greenfinal-{folder}-raw/receipt.json';r=json.loads(path.read_text())
    assert r['complete'] and all(c['waited_by_parent'] for c in r['children'])
    assert len({(c['parent_pid'],c['pid']) for c in r['children']})==len(r['children'])
    assert r['binary_sha256']==summary['owners']['greenfinal']['gates']['fixture_binary_sha256']
    summary['native'][folder]=dict(cases=len(r['cases']),case_names=[c['case'] for c in r['cases']],original_child_waits=len(r['children']),receipt_sha256=digest(path))
for case in ['schedule-empty-future','schedule-future-empty','schedule-empty-single','schedule-empty-repeated','schedule-future-repeated']:
    p=OUT/f'redfinal-{case}-raw/receipt.json';r=json.loads(p.read_text());assert r['all_original_children_waited']
    expected_failure=case in ['schedule-empty-future','schedule-future-empty']
    assert r['complete'] != expected_failure
    if expected_failure:assert r.get('error')
    summary['red'][case]=dict(expected_failure=expected_failure,error=r.get('error'),original_child_waits=len(r['children']),receipt_sha256=digest(p),probe=r['active_schedule_probe'])
assert summary['red']['schedule-future-empty']['probe']['rpc_records'][-1]['code']=='FAILED_PRECONDITION'
assert 'last future schedule dispatched immediately' in summary['red']['schedule-empty-future']['error']
for fault in ['error','signal']:
    path=OUT/f'greenfinal-parent-{fault}-raw/receipt.json';r=json.loads(path.read_text());assert not r['complete'] and r['all_original_children_waited']
    summary['cleanup_drills'][fault]=dict(expected_failure=True,original_child_waits=len(r['children']),all_waited=True,error=r['error'],receipt_sha256=digest(path))
log=(OUT/'greenfinal-all-targets.log').read_text();matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
assert matches and all(v[0]=='ok' and int(v[2])==0 for v in matches)
summary['all_targets']=dict(library_passed=int(matches[0][1]),library_ignored=int(matches[0][3]),total_passed=sum(int(v[1]) for v in matches),total_ignored=sum(int(v[3]) for v in matches),suite_results=matches)
consumer=re.search(r'Running unittests src/lib\.rs \([^\n]*reboot_rust_build_fixture[^\n]*\)\n(.*?)\n\s*Doc-tests reboot_rust_build_fixture',log,re.S);assert consumer
summary['all_targets']['generated_consumer_passed']=int(re.findall(r'test result: ok\. (\d+) passed;',consumer.group(1))[-1])
summary['native_case_total']=sum(r['cases'] for r in summary['native'].values());summary['native_original_wait_total']=sum(r['original_child_waits'] for r in summary['native'].values())
for stage,source in [('greenfinal',ROOT),('redfinal',RED)]:
    manifest=json.loads((OUT/(stage+'-source-inputs.json')).read_text())
    for key,expected in manifest.items():
        if key.startswith('source/'):p=source/key.removeprefix('source/')
        elif key.startswith('python-runfiles/'):p=RUN/key.removeprefix('python-runfiles/')
        elif key=='tools/python-generator-launcher':p=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python')
        else:continue
        assert digest(p)==expected,(stage,key,'changed')
        target=OUT/'objects'/expected;target.parent.mkdir(exist_ok=True)
        if not target.exists():target.write_bytes(p.read_bytes())
        summary['source_objects'][stage+'/'+key]=dict(sha256=expected,member='objects/'+expected,bytes=p.stat().st_size)
    summary[stage+'_source_manifest_sha256']=digest(OUT/(stage+'-source-inputs.json'))
greenfinal_manifest=json.loads((OUT/'greenfinal-source-inputs.json').read_text());red_manifest=json.loads((OUT/'redfinal-source-inputs.json').read_text())
summary['source_input_count']=len(greenfinal_manifest)
summary['source_object_count']=len({v['sha256'] for v in summary['source_objects'].values()})
summary['red_to_green_source_differences']=[k for k in greenfinal_manifest if greenfinal_manifest[k]!=red_manifest.get(k)]
assert summary['red_to_green_source_differences']==['source/reboot/rust/src/workflow_spawn.rs']
summary['fixture_binary_sha256']=digest(OUT/'fixed-app');summary['old_binary_sha256']=digest(OUT/'old-app');summary['native_database_sha256']=greenfinal_manifest['tools/native-database-reused'];summary['legacy_binary_sha256']=greenfinal_manifest['tools/legacy-rust-app']
mutation=OUT/'mutation';mutation.mkdir(exist_ok=True)
old=RED/'reboot/rust/src/workflow_spawn.rs';fixed=ROOT/'reboot/rust/src/workflow_spawn.rs'
(mutation/'workflow_spawn.old.rs').write_bytes(old.read_bytes());(mutation/'workflow_spawn.fixed.rs').write_bytes(fixed.read_bytes())
(mutation/'fixed-to-old.patch').write_text(''.join(difflib.unified_diff(fixed.read_text().splitlines(True),old.read_text().splitlines(True),fromfile='fixed/reboot/rust/src/workflow_spawn.rs',tofile='old/reboot/rust/src/workflow_spawn.rs')))
summary['mutation']={str(p.relative_to(OUT)):digest(p) for p in mutation.iterdir()}
# Cargo JSON identifies the exact build-script outputs associated with this build.
for line in (OUT/'greenfinal-fixture-build.log').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')=='generated-workflow-app':
        summary['fixture_cargo_artifact']=r
    if r.get('reason')!='build-script-executed' or not any(name in r.get('package_id','') for name in ['reboot-rust-schema','generated-workflow-app']):continue
    output=Path(r['out_dir'])
    for original in output.rglob('*.rs'):
        target=OUT/'generated-rust'/output.parent.name/original.relative_to(output);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
        summary['generated_rust_outputs'][str(target.relative_to(OUT))]=dict(sha256=digest(target),observed_build_output=str(original),cargo_package_id=r['package_id'])
assert summary['generated_rust_outputs'] and summary['fixture_cargo_artifact']
for p in OUT.parent.glob('canonical_duplicate_*.py'):(OUT/p.name).write_bytes(p.read_bytes())
summary['prior_1208_retirement_sha256']=digest(OUT/'prior-1208-retirement.json')
(OUT/'source-objects.json').write_text(json.dumps(summary.pop('source_objects'),indent=2,sort_keys=True))
(OUT/'qualification.json').write_text(json.dumps(summary,indent=2,sort_keys=True))
files=[]
for directory,dirs,names in os.walk(OUT):
    dirs[:]=[n for n in dirs if n!='tmp' and '__pycache__' not in n and not n.endswith('rocks')]
    for name in names:
        p=Path(directory)/name
        if p.is_symlink() or name in ['fixed-app','old-app','archive-members.json','archive-receipt.json']:continue
        if name.endswith('.tmp'):continue
        files.append(p)
files.sort();inventory={str(p.relative_to(OUT)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in files}
(OUT/'archive-members.json').write_text(json.dumps(inventory,indent=2,sort_keys=True))
with tarfile.open(ARCHIVE,'w:gz') as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
    tar.add(OUT/'archive-members.json',arcname='archive-members.json',recursive=False)
record=dict(archive_sha256=digest(ARCHIVE),bytes=ARCHIVE.stat().st_size,file_members=len(inventory)+1,qualification_sha256=digest(OUT/'qualification.json'),source_manifest_sha256=summary['greenfinal_source_manifest_sha256'],large_executables_included=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'archive-receipt.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print(json.dumps({k:v for k,v in summary.items() if k in ['all_targets','native_case_total','native_original_wait_total','fixture_binary_sha256','native','red_to_green_source_differences']}))
