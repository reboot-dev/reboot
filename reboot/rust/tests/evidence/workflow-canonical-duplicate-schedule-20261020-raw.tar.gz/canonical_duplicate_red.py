import datetime, hashlib, json, os, signal, subprocess
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-red-src')
OUT=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-evidence')
RUN=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot')
PY='/home/benchbuild/reboot-rust/.venv-acceptance/bin/python'
BIN=OUT/'old-app'
DB=Path(os.environ['REBOOT_NATIVE2PC_CXX_DATABASE'])
ENV=os.environ.copy()|dict(CANONICAL_TASK_BIN=str(BIN),CANONICAL_TASK_PYTHON=PY,CANONICAL_TASK_EVIDENCE=str(OUT/'red-canonical-raw'),CANONICAL_MIGRATION_EVIDENCE=str(OUT/'red-migration-raw'),CANONICAL_LEGACY_BIN=str(Path('/home/benchbuild/.cache/canonical-admission-20261020-evidence/legacy-app')),CANONICAL_LEGACY_SOURCE_COMMIT='18175834a9df99aeda94786e6d804570c25f6083',CANONICAL_PYTHON_PLUGIN='/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python',CANONICAL_PYTHON_RUNFILES=str(RUN),WORKFLOW_TASK_BIN=str(BIN),WORKFLOW_TASK_PYTHON=PY,WORKFLOW_TASK_EVIDENCE=str(OUT/'red-lifecycle-raw'),WORKFLOW_SPAWN_BIN=str(BIN),WORKFLOW_SPAWN_PYTHON=PY,WORKFLOW_SPAWN_EVIDENCE=str(OUT/'red-spawn-raw'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
    paths=[p for p in (ROOT/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts]
    paths+=list((ROOT/'rbt').rglob('*.proto'))
    paths += [ROOT/'reboot/templates/reboot.py.j2',ROOT/'reboot/protoc_gen_reboot_python.py',ROOT/'reboot/protoc_gen_reboot_generic.py',ROOT/'reboot/server/database.cc']
    result={'source/'+str(p.relative_to(ROOT)):digest(p) for p in paths}
    for package in ['reboot','rbt']:
        for p in (RUN/package).rglob('*'):
            if p.is_file() and p.suffix in ['.py','.j2'] and '__pycache__' not in p.parts:
                result['python-runfiles/'+str(p.relative_to(RUN))]=digest(p)
    result['tools/python-generator-launcher']=digest(Path(ENV['CANONICAL_PYTHON_PLUGIN']))
    result['tools/native-database-reused']=digest(DB)
    result['tools/legacy-rust-app']=digest(Path('/home/benchbuild/.cache/canonical-admission-20261020-evidence/legacy-app'))
    return result
for relative in ['reboot/templates/reboot.py.j2','reboot/protoc_gen_reboot_python.py','reboot/protoc_gen_reboot_generic.py']:
    assert digest(ROOT/relative)==digest(RUN/relative),('Python generator source differs',relative)
assert digest(DB)=='619002c569e9841144a8bbedf4f2ce6a753bb0e6b103af71883d91d43f413803'
manifest=inputs();(OUT/'red-source-inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
receipt=dict(complete=False,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_pid=os.getpid(),base_commit='18175834a9df99aeda94786e6d804570c25f6083',gates=[],source_manifest_sha256=digest(OUT/'red-source-inputs.json'),controller_sha256=digest(Path(__file__)),fresh_cpp_build=False,native_artifact_reused=True)
def save():
    p=OUT/'red-gates.json.tmp';p.write_text(json.dumps(receipt,indent=2))
    with p.open('rb') as f:os.fsync(f.fileno())
    os.replace(p,OUT/'red-gates.json');fd=os.open(OUT,os.O_RDONLY);os.fsync(fd);os.close(fd)
def interrupted(*_):raise InterruptedError('red controller termination')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,interrupted)
def run(name,command,env=None,expected=0,timeout=1200):
    log=OUT/(name+'.log');gate=dict(name=name,command=command,expected_exit=expected,waited_by_original_parent=False);receipt['gates'].append(gate);save()
    with log.open('wb') as out:
        p=subprocess.Popen(command,cwd=ROOT/'reboot/rust',env=ENV|(env or {}),stdout=out,stderr=subprocess.STDOUT)
        gate['pid']=p.pid;save()
        try:p.wait(timeout=timeout)
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=40)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            gate.update(waited_by_original_parent=True,exit=p.returncode,log_sha256=digest(log));save()
    assert (p.returncode==0 if expected==0 else p.returncode!=0),(name,p.returncode,log)
    gate['accepted']=True;save()
save()
try:
    run('red-fixture-build',['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'])
    BIN.write_bytes((Path(os.environ['CARGO_TARGET_DIR'])/'debug/generated-workflow-app').read_bytes()); BIN.chmod(0o755)
    receipt['fixture_binary_sha256']=digest(BIN);save()
    for case in ['schedule-empty-future','schedule-future-empty','schedule-empty-single','schedule-empty-repeated','schedule-future-repeated']:
        # Do not fail fast: preserve the independent failure in BOTH orders.
        log=OUT/('red-'+case+'.log')
        env={'CANONICAL_NATIVE_CASES':case}
        expected=1 if case in ['schedule-empty-future','schedule-future-empty'] else 0
        run('red-'+case,[PY,str(ROOT/'reboot/rust/tests/fixtures/workflow_app/prove_canonical_admission.py'),str(BIN),str(OUT/('red-'+case+'-raw'))],env,expected=expected)
        raw=json.loads((OUT/('red-'+case+'-raw/receipt.json')).read_text())
        assert raw['all_original_children_waited']
    receipt['complete']=True
finally:
    receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['source_unchanged']=inputs()==manifest;save()
assert receipt['complete'] and receipt['source_unchanged']
