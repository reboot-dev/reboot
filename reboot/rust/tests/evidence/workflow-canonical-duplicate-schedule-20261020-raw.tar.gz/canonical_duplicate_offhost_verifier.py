"""Read-only offhost verification; writes only a separate result file."""
import hashlib,json,re,subprocess,sys,tarfile
from pathlib import Path
archive,repo,output=map(Path,sys.argv[1:])
def sha(b):return hashlib.sha256(b).hexdigest()
with tarfile.open(archive,'r:gz') as tar:
    names=[m.name for m in tar.getmembers() if m.isfile()]
    assert len(names)==len(set(names))
    def raw(name):return tar.extractfile(name).read()
    def data(name):return json.loads(raw(name))
    inventory=data('archive-members.json')
    assert set(names)==set(inventory)|{'archive-members.json'}
    for name,pin in inventory.items():
        b=raw(name);assert sha(b)==pin['sha256'] and len(b)==pin['bytes'],name
    summary=data('qualification.json');assert summary['complete']
    objects=data('source-objects.json')
    for key,pin in objects.items():assert sha(raw(pin['member']))==pin['sha256'] and len(raw(pin['member']))==pin['bytes'],key
    manifests={stage:data(stage+'-source-inputs.json') for stage in ['redfinal','green']}
    local_checked=[]
    for key,pin in manifests['green'].items():
        if key.startswith('source/'):
            p=repo/key.removeprefix('source/');assert p.is_file() and sha(p.read_bytes())==pin,key;local_checked.append(key)
        if key in ['tools/native-database-reused','tools/legacy-rust-app']:continue
        assert objects['green/'+key]['sha256']==pin,key
    differences=[k for k,v in manifests['green'].items() if v!=manifests['redfinal'].get(k)]
    assert differences==['source/reboot/rust/src/workflow_spawn.rs']
    old=subprocess.check_output(['git','show','25dcf84eb5afbb5e7613f1275ccf7cdee14c521a:reboot/rust/src/workflow_spawn.rs'],cwd=repo)
    assert raw('mutation/workflow_spawn.old.rs')==old
    assert raw('mutation/workflow_spawn.fixed.rs')==(repo/'reboot/rust/src/workflow_spawn.rs').read_bytes()
    native={}
    for folder in ['canonical','migration','lifecycle','spawn']:
        r=data('green-'+folder+'-raw/receipt.json');assert r['complete'] and all(c['waited_by_parent'] for c in r['children'])
        assert r['binary_sha256']==summary['fixture_binary_sha256']
        if folder=='canonical':
            expected={
                'schedule-empty-future':['','2030-01-01T00:00:00+00:00'],
                'schedule-future-empty':['2030-01-01T00:00:00+00:00',''],
                'schedule-empty-single':[''],
                'schedule-empty-repeated':['',''],
                'schedule-future-repeated':['2030-01-01T00:00:00+00:00']*2,
            }
            found={c['case']:c for c in r['cases'] if c['case'] in expected}
            assert set(found)==set(expected)
            for name,values in expected.items():
                c=found[name];assert len(c['rpc_records'])==3
                ids=[]
                for rpc in c['rpc_records']:
                    assert rpc['code']=='OK'
                    assert [v for k,v in rpc['metadata'] if k=='x-reboot-task-schedule']==values
                    ids.append([v for k,v in rpc['trailing_metadata'] if k=='x-reboot-task-id-uuid'])
                assert ids[0]==ids[1]==ids[2] and len(ids[0])==1
                assert c['snapshot']['first']==(7 if values[-1]=='' else 0)
                assert c['events'].count('child-body')==(1 if values[-1]=='' else 0)
        native[folder]={'cases':len(r['cases']),'original_child_waits':len(r['children']),'case_names':[c['case'] for c in r['cases']]}
        assert native[folder]['cases']==summary['native'][folder]['cases']
        assert native[folder]['original_child_waits']==summary['native'][folder]['original_child_waits']
    red={}
    for case in ['schedule-empty-future','schedule-future-empty','schedule-empty-single','schedule-empty-repeated','schedule-future-repeated']:
        r=data('redfinal-'+case+'-raw/receipt.json');assert r['all_original_children_waited']
        failure=case in ['schedule-empty-future','schedule-future-empty'];assert r['complete']!=failure
        red[case]={'complete':r['complete'],'error':r.get('error'),'waits':len(r['children'])}
    assert 'last future schedule dispatched immediately' in red['schedule-empty-future']['error']
    reverse=data('redfinal-schedule-future-empty-raw/receipt.json')['active_schedule_probe']
    assert reverse['rpc_records'][-1]['code']=='FAILED_PRECONDITION'
    assert [v for k,v in reverse['rpc_records'][0]['metadata'] if k=='x-reboot-task-schedule']==['2030-01-01T00:00:00+00:00','']
    for stage in ['redfinal','green']:
        parent=data(stage+'-parent.json');owner=data(stage+'.json');gates=data(stage+'-gates.json')
        assert parent['owner_waited'] and parent['owner_wait_returncode']==0
        assert owner['complete'] and owner['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
        assert gates['complete'] and gates['source_unchanged'] and all(g['accepted'] and g['waited_by_original_parent'] for g in gates['gates'])
    for fault in ['error','signal']:
        r=data('green-parent-'+fault+'-raw/receipt.json');assert not r['complete'] and r['all_original_children_waited'] and r.get('error')
    matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw('green-all-targets.log').decode())
    assert all(m[0]=='ok' and int(m[2])==0 for m in matches)
    assert matches==summary['all_targets']['suite_results'] or [list(m) for m in matches]==summary['all_targets']['suite_results']
    total_cases=sum(r['cases'] for r in native.values());total_waits=sum(r['original_child_waits'] for r in native.values())
    assert total_cases==summary['native_case_total'] and total_waits==summary['native_original_wait_total']
    assert data('prior-1208-retirement.json')['original_native_wait_total']==1208
    assert not data('prior-1208-retirement.json')['old_pids_still_present']
    result=dict(verified=True,archive_sha256=sha(archive.read_bytes()),file_members=len(names),inventory_verified=True,source_objects_verified=True,local_source_inputs_checked=len(local_checked),red_to_green_differences=differences,old_source_matches_reviewed_commit=True,native=native,native_case_total=total_cases,native_original_wait_total=total_waits,red=red,all_targets=summary['all_targets'],cleanup_drills_verified=True,original_parents_verified=True,historical_prior_waits_verified=1208,large_executables_included=False)
output.write_text(json.dumps(result,indent=2,sort_keys=True));print(json.dumps(result,indent=2))
