import datetime,json,subprocess
from pathlib import Path
OLD=Path('/home/benchbuild/.cache/canonical-admission-20261020-evidence')
OUT=Path('/home/benchbuild/.cache/canonical-duplicate-20261020-evidence')
record={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owners':{},'native':{},'retired_pids':[]}
for stage in ['final5']:
    for suffix in ['-parent','']:
        r=json.loads((OLD/(stage+suffix+'.json')).read_text());record['owners'][stage+suffix]=r
        assert r['complete']
        if suffix:assert r['owner_waited'] and r['owner_wait_returncode']==0
        else:assert r['source_unchanged'] and all(c['waited_by_owner'] for c in r['children'])
        for key in ['parent_pid','owner_pid']:
            if key in r:record['retired_pids'].append(r[key])
for folder in ['canonical','migration','lifecycle','spawn']:
    r=json.loads((OLD/('final5-'+folder+'-raw/receipt.json')).read_text());assert r['complete']
    assert all(c['waited_by_parent'] for c in r['children'])
    record['native'][folder]={'original_waits':len(r['children']),'parent_pid':r['parent_pid']}
    record['retired_pids'].append(r['parent_pid']);record['retired_pids'] += [c['pid'] for c in r['children']]
record['original_native_wait_total']=sum(r['original_waits'] for r in record['native'].values())
assert record['original_native_wait_total']==1208
record['old_pids_still_present']=[pid for pid in set(record['retired_pids']) if Path('/proc/'+str(pid)).exists()]
assert not record['old_pids_still_present']
record['systemd']=subprocess.run(['systemctl','show','canonical-admission-final5','-p','MainPID','-p','ActiveState','-p','Result'],capture_output=True,text=True,check=True).stdout
assert 'MainPID=0' in record['systemd'] and 'ActiveState=inactive' in record['systemd']
(OUT/'prior-1208-retirement.json').write_text(json.dumps(record,indent=2))
print(record['original_native_wait_total'],record['old_pids_still_present'])
