import os, subprocess, json, hashlib
from pathlib import Path
src=Path('/home/benchbuild/.cache/crossactor-transitive-src')
evidence=Path('/home/benchbuild/.cache/crossactor-transitive-evidence')
env=os.environ.copy();env.update(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database')
fixture=src/'reboot/rust/tests/fixtures/reactive_app/Cargo.toml'
manifest=src/'reboot/rust/Cargo.toml'
rows=[]
def run(label,args,extra=None,expected=0):
 e=env| (extra or {})
 with (evidence/(label+'.log')).open('w') as f:
  p=subprocess.Popen(args,env=e,stdout=f,stderr=subprocess.STDOUT)
  rc=p.wait(timeout=600)
 rows.append(dict(label=label,pid=p.pid,parent_pid=os.getpid(),wait_returncode=rc,args=list(map(str,args))))
 (evidence/'qualification-owner.json').write_text(json.dumps(dict(pid=os.getpid(),complete=False,children=rows),indent=2))
 assert rc==expected,(label,rc,expected)
source=src/'reboot/rust/src/reactive.rs'
original=source.read_text()
try:
 assert original.count('self.binding.read_with_context(request, context).await')==1
 source.write_text(original.replace('self.binding.read_with_context(request, context).await','let _ = context; self.binding.read(request).await'))
 run('red-build',['/usr/sbin/runuser','-u','benchbuild','--','env',*[f'{k}={v}' for k,v in env.items() if k in ['PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']],'cargo','build','--locked','--manifest-path',str(fixture)])
 run('red-native',['python3',str(fixture.parent/'prove_transitive.py'),env['CARGO_TARGET_DIR']+'/debug/generated-reactive-app'],{'TRANSITIVE_EVIDENCE':str(evidence/'native-red')},expected=1)
finally:
 source.write_text(original)
run('clippy',['/usr/sbin/runuser','-u','benchbuild','--','env',*[f'{k}={v}' for k,v in env.items() if k in ['PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']],'cargo','clippy','--locked','--all-targets','--manifest-path',str(manifest),'--','-D','warnings'])
run('green-generated-native',['/usr/sbin/runuser','-u','benchbuild','--','env',*[f'{k}={v}' for k,v in (env|{'TRANSITIVE_EVIDENCE':str(evidence/'native-green')}).items() if k in ['PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','REBOOT_NATIVE2PC_CXX_DATABASE','TRANSITIVE_EVIDENCE']],'cargo','test','--locked','--manifest-path',str(manifest),'--test','reactive_native_restart','generated_transitive_readers_track_leaf_writers_and_rebuild_after_restart','--','--ignored','--exact','--nocapture'])
(evidence/'qualification-owner.json').write_text(json.dumps(dict(pid=os.getpid(),complete=True,children=rows),indent=2))
print(json.dumps(dict(complete=True,children=rows),indent=2))
