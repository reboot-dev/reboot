"""Bounded registration-race qualification; reuse the existing custody driver."""
import os
from pathlib import Path
MODE=os.environ['REGISTRATION_MODE']
assert MODE in ['red','green']
source=Path('/home/benchbuild/.cache/ordinary_green5.py').read_text()
source=source.replace("ordinary-running-final5-20261020-src",f"registration-race-{MODE}-20261020-src")
source=source.replace("ordinary-running-20261020-evidence","registration-race-20261020-evidence")
source=source.replace("PREFIX='greenfinal5'",f"PREFIX='registration-{MODE}1'")
source=source.replace("base_commit='837c7e1f6ad1a50408b1ef41424d768759249f09'","base_commit='500a418833c95a49858547ced1e1a0566e0c7098'")
if MODE=='red':
    a=source.index("    run('native-running'")
    b=source.index("    receipt['complete']=True",a)
    source=source[:a]+'''    folder=OUT/(PREFIX+'-running-raw')
    run('native-registration-old',[PY,str(ROOT/'reboot/rust/tests/fixtures/workflow_app/prove_generic_tasks.py'),str(BIN),str(folder)],{'GENERIC_NATIVE_CASES':'running-absent-owner'},expected=1)
    raw=json.loads((folder/'receipt.json').read_text())
    assert not raw['complete'] and raw['all_original_children_waited'] and raw.get('error')
    race=folder/'running-absent-owner/race'
    assert (race/'before-registration').exists() and (race/'intent-published').exists() and (race/'shared-queued').exists() and not (race/'suppressed').exists()
    receipt['negative_control_observed']=True
'''+source[b:]
exec(compile(source,__file__+':'+MODE,'exec'))
