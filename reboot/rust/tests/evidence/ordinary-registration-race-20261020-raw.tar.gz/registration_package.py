"""Read terminal receipts, freeze new evidence without modifying old archives."""
import datetime,hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
HOME=Path('/home/benchbuild');OUT=HOME/'.cache/registration-race-20261020-evidence'
OLD=HOME/'.cache/ordinary-running-20261020-evidence'
ROOT=HOME/'.cache/registration-race-green2-20261020-src'
RUN=HOME/'reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot'
ARCHIVE=HOME/'.cache/ordinary-registration-race-20261020-raw.tar.gz'
assert not ARCHIVE.exists()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
summary=dict(base_commit='500a418833c95a49858547ced1e1a0566e0c7098',complete=False,owners={},native={},negative_control={},cleanup_drills={},independent_review='BLOCKED: standalone Codex CLI authentication refresh failed (401); parent independent review required',fresh_cpp_build=False,native_artifact_reused=True)
pids=[]
for stage,unit in [('registration-red2','registration-red2-20261020'),('registration-green2','registration-green2-20261020')]:
    p=OLD/(stage+'.json');r=load(p)
    assert r['complete'] and r['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in r['children'])
    status=subprocess.check_output(['systemctl','show',unit,'-p','MainPID','-p','ActiveState','-p','Result','-p','ExecMainStatus'],text=True)
    assert 'MainPID=0' in status and 'Result=success' in status and 'ActiveState=inactive' in status
    (OUT/p.name).write_bytes(p.read_bytes());summary['owners'][stage]=dict(systemd=status,owner_receipt_sha256=digest(p),owner_pid=r['owner_pid'],children=r['children'],outer_retirement='systemd terminal status and timestamped /proc absence observation; not a caller waitpid receipt')
    pids += [r['owner_pid']]+[c['pid'] for c in r['children']]
for mode in ['red','green']:
    prefix='registration-'+mode+('1' if mode=='red' else '2');g=load(OUT/(prefix+'-gates.json'))
    assert g['complete'] and g['source_unchanged'] and all(x['accepted'] and x['waited_by_original_parent'] for x in g['gates'])
    pids += [g['parent_pid']]+[x['pid'] for x in g['gates']]
    summary[mode+'_gates']=g
    if mode=='red':assert g['negative_control_observed']
    for p in (OUT/(prefix+'-running-raw')).rglob('receipt.json'):
        r=load(p);assert all(c['waited_by_parent'] for c in r['children'])
red=load(OUT/'registration-red1-source-inputs.json');green=load(OUT/'registration-green2-source-inputs.json')
diff=sorted(k for k in set(red)|set(green) if red.get(k)!=green.get(k))
assert diff==['source/reboot/rust/src/one_shot_tasks.rs','source/reboot/rust/src/task_cancellation.rs'],diff
summary['negative_control']['source_differences']=diff
for folder in ['running','generic','workflow-writer','canonical','migration','lifecycle','spawn','parent-error','parent-signal']:
    p=OUT/('registration-green2-'+folder+'-raw/receipt.json');r=load(p)
    assert r['children'] and all(c['waited_by_parent'] for c in r['children']) and r.get('all_original_children_waited',True)
    assert r['binary_sha256']==summary['green_gates']['fixture_binary_sha256']
    assert len({(c['parent_pid'],c['pid']) for c in r['children']})==len(r['children'])
    pids += [r['parent_pid']]+[c['pid'] for c in r['children']]
    if folder.startswith('parent-'):
        assert not r['complete'] and r.get('error');summary['cleanup_drills'][folder]=dict(receipt_sha256=digest(p),original_child_waits=len(r['children']),error=r['error'])
    else:
        assert r['complete'];summary['native'][folder]=dict(cases=len(r['cases']),case_names=[c['case'] for c in r['cases']],original_child_waits=len(r['children']),receipt_sha256=digest(p))
p=OUT/'registration-red1-running-raw/receipt.json';r=load(p)
assert not r['complete'] and r.get('error') and r['all_original_children_waited']
pids += [r['parent_pid']]+[c['pid'] for c in r['children']]
summary['negative_control'].update(receipt_sha256=digest(p),error=r['error'],original_child_waits=len(r['children']))
# Preserve every failed attempt and verify its original children as well.
summary['attempt_retirement']=[]
for p in OUT.rglob('receipt.json'):
    r=load(p)
    if 'children' not in r or 'parent_pid' not in r:continue
    assert r['children'] and all(c['waited_by_parent'] for c in r['children']) and r.get('all_original_children_waited',True),p
    pids += [r['parent_pid']]+[c['pid'] for c in r['children']]
    summary['attempt_retirement'].append(dict(receipt=str(p.relative_to(OUT)),complete=r.get('complete'),original_child_waits=len(r['children'])))
p=OLD/'registration-green1.json';r=load(p)
assert r['complete'] and r['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']!=0 for c in r['children'])
(OUT/p.name).write_bytes(p.read_bytes());pids += [r['owner_pid']]+[c['pid'] for c in r['children']]
g=load(OUT/'registration-green1-gates.json');assert not g['complete'] and g['source_unchanged'] and all(c['waited_by_original_parent'] for c in g['gates'])
pids += [g['parent_pid']]+[c['pid'] for c in g['gates']]
summary['rejected_green1']=dict(reason='strict Clippy collapsible_if in test-only observation helper',owner_receipt_sha256=digest(p),gates=g)
for unit in ['registration-red1-20261020','registration-green1-20261020']:
    data=subprocess.check_output(['journalctl','-u',unit,'--no-pager'],text=True);(OUT/(unit+'-journal.log')).write_text(data)
assert not [p for p in pids if (Path('/proc')/str(p)).exists()]
summary['retired_owned_pids']=sorted(set(pids));summary['absence_observed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
summary['all_targets']={}
for name in ['all-targets','sdk-doctests','fixture-tests']:
    matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/('registration-green2-'+name+'.log')).read_text())
    assert matches and all(m[0]=='ok' and int(m[2])==0 for m in matches)
    summary['all_targets'][name]=dict(passed=sum(int(m[1]) for m in matches),ignored=sum(int(m[3]) for m in matches),suite_results=matches)
objects={}
for mode,manifest in [('red',red),('green',green)]:
    root=HOME/('.cache/registration-race-'+mode+('' if mode=='red' else '2')+'-20261020-src')
    for key,expected in manifest.items():
        if key.startswith('source/'):p=root/key.removeprefix('source/')
        elif key.startswith('python-runfiles/'):p=RUN/key.removeprefix('python-runfiles/')
        elif key=='tools/python-generator-launcher':p=HOME/'reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python'
        else:continue
        assert digest(p)==expected,(mode,key)
        target=OUT/'objects'/expected;target.parent.mkdir(exist_ok=True)
        if not target.exists():target.write_bytes(p.read_bytes())
        objects[mode+'/'+key]=dict(sha256=expected,member='objects/'+expected,bytes=p.stat().st_size)
for name in ['ordinary_owner.py','ordinary_green5.py','registration_batch.py','registration_batch2.py','registration_package.py']:
    p=HOME/'.cache'/name;(OUT/name).write_bytes(p.read_bytes())
for name in ['registration-race-overlay.tar','registration-race-overlay2.tar','registration-red-inputs.tar']:
    p=HOME/'.cache'/name;(OUT/name).write_bytes(p.read_bytes())
# Preserve generator outputs associated with the fresh GREEN fixture build.
summary['generated_rust_outputs']={}
for line in (OUT/'registration-green2-fixture-build.log').read_text().splitlines():
    try:v=json.loads(line)
    except json.JSONDecodeError:continue
    if v.get('reason')=='compiler-artifact' and v.get('executable') and v.get('target',{}).get('name')=='generated-workflow-app':summary['fixture_cargo_artifact']=v
    if v.get('reason')!='build-script-executed' or not any(n in v.get('package_id','') for n in ['reboot-rust-schema','generated-workflow-app']):continue
    root=Path(v['out_dir'])
    for p in root.rglob('*.rs'):
        target=OUT/'generated-rust'/root.parent.name/p.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());summary['generated_rust_outputs'][str(target.relative_to(OUT))]=dict(sha256=digest(target),observed_build_output=str(p))
assert summary['generated_rust_outputs'] and summary['fixture_cargo_artifact']
summary['native_case_total']=sum(v['cases'] for v in summary['native'].values())
summary['native_original_wait_total']=sum(v['original_child_waits'] for v in summary['native'].values())
summary['source_manifest_sha256']=digest(OUT/'registration-green2-source-inputs.json')
summary['source_input_count']=len(green);summary['native_database_sha256']=green['tools/native-database-reused']
summary['complete']=True
(OUT/'source-objects.json').write_text(json.dumps(objects,indent=2,sort_keys=True))
(OUT/'qualification.json').write_text(json.dumps(summary,indent=2,sort_keys=True))
files=[]
for directory,dirs,names in os.walk(OUT):
    dirs[:]=[n for n in dirs if n!='tmp' and '__pycache__' not in n and not n.endswith('rocks')]
    for name in names:
        p=Path(directory)/name
        if p.is_symlink() or name in ['archive-members.json','archive-receipt.json'] or name.endswith('.tmp'):continue
        with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
        if elf:continue
        assert p.stat().st_size<20*1024**2,(p,'unexpected large nonbinary')
        files.append(p)
files.sort();inventory={str(p.relative_to(OUT)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in files}
(OUT/'archive-members.json').write_text(json.dumps(inventory,indent=2,sort_keys=True))
with tarfile.open(ARCHIVE,'w:gz') as t:
    for p in files:t.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
    t.add(OUT/'archive-members.json',arcname='archive-members.json',recursive=False)
record=dict(archive_sha256=digest(ARCHIVE),bytes=ARCHIVE.stat().st_size,file_members=len(files)+1,qualification_sha256=digest(OUT/'qualification.json'),source_manifest_sha256=summary['source_manifest_sha256'],large_executables_included=False)
(OUT/'archive-receipt.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print(json.dumps({k:summary[k] for k in ['native_case_total','native_original_wait_total','all_targets']}))
