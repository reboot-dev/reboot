"""Final immutable GREEN source revision after strict-Clippy fixture repair."""
import os
from pathlib import Path
assert os.environ['REGISTRATION_MODE']=='green'
script=Path('/home/benchbuild/.cache/registration_batch.py').read_text()
script=script.replace('registration-race-{MODE}-20261020-src','registration-race-{MODE}2-20261020-src')
script=script.replace("f\"PREFIX='registration-{MODE}1'\"","f\"PREFIX='registration-{MODE}2'\"")
exec(compile(script,__file__,'exec'))
