"""Finite native source-mutant parent; copies leave GREEN source untouched."""
import difflib,hashlib,json,os,shutil,signal,subprocess,time
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/generic-writer-20261020-src');OUT=Path('/home/benchbuild/.cache/generic-writer-20261020-evidence')
PY='/home/benchbuild/reboot-rust/.venv-acceptance/bin/python'
ENV=os.environ.copy()|dict(CANONICAL_PYTHON_RUNFILES='/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot',CANONICAL_PYTHON_PLUGIN='/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python')
record=dict(complete=False,parent_pid=os.getpid(),mutants=[],children=[])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs(root):
    return {str(p.relative_to(root)):digest(p) for p in (root/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
def save():
    p=OUT/'mutants-final-controller.json.tmp';p.write_text(json.dumps(record,indent=2))
    with p.open('rb') as f:os.fsync(f.fileno())
    os.replace(p,OUT/'mutants-final-controller.json');fd=os.open(OUT,os.O_RDONLY);os.fsync(fd);os.close(fd)
def interrupted(*_):raise InterruptedError('source mutant parent terminated')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,interrupted)
def run(name,command,cwd,env=None):
    child=dict(name=name,command=command,parent_pid=os.getpid(),waited_by_original_parent=False);record['children'].append(child);save()
    log=OUT/(name+'.log')
    with log.open('wb') as output:
        p=subprocess.Popen(command,cwd=cwd,env=ENV|(env or {}),stdout=output,stderr=subprocess.STDOUT);child['pid']=p.pid;save()
        try:p.wait(timeout=600)
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=40)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            child.update(waited_by_original_parent=True,exit=p.returncode,log_sha256=digest(log));save()
    return p.returncode
try:
    for name,relative,case in [('final-workflow-only-admission','src/workflow_spawn.rs','success'),('final-skip-writer-checkpoint','src/runtime.rs','checkpoint-restart')]:
        root=ROOT.parent/('generic-writer-mutant-'+name);assert not root.exists();shutil.copytree(ROOT,root,symlinks=True,ignore=shutil.ignore_patterns('__pycache__'))
        p=root/'reboot/rust'/relative;before=p.read_text()
        if name=='final-workflow-only-admission':
            old='d.method == body.method && (d.workflow || canonical_callable)';new='d.method == body.method && d.workflow'
            assert before.count(old)==1;after=before.replace(old,new)
        else:
            begin=before.index('pub async fn execute_scheduling_outcome_with_precheck<')
            start=before.index('if let Some(response)',begin);end=before.index('// A checkpoint miss',start)
            block=before[start:end];old='.await?\n        {';assert block.count(old)==1
            after=before[:start]+block.replace(old,'.await?.filter(|_| false)\n        {')+before[end:]
        p.write_text(after)
        retained=OUT/('mutant-'+name);retained.mkdir()
        (retained/'before.rs').write_text(before);(retained/'after.rs').write_text(after)
        (retained/'mutation.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='green/'+relative,tofile='mutant/'+relative)))
        green_inputs=inputs(ROOT);mutant_inputs=inputs(root)
        differences=sorted(k for k in set(green_inputs)|set(mutant_inputs) if green_inputs.get(k)!=mutant_inputs.get(k))
        assert differences==['reboot/rust/'+relative],differences
        (retained/'source-inputs.json').write_text(json.dumps({'green':green_inputs,'mutant':mutant_inputs,'differences':differences},indent=2,sort_keys=True))
        mutant=dict(name=name,relative=relative,source_root=str(root),before_sha256=digest(retained/'before.rs'),after_sha256=digest(p),diff_sha256=digest(retained/'mutation.diff'),native_case=case)
        record['mutants'].append(mutant);save()
        assert run(name+'-build',['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'],root/'reboot/rust')==0
        binary=retained/'app';shutil.copy2(Path(ENV['CARGO_TARGET_DIR'])/'debug/generated-workflow-app',binary);mutant['binary_sha256']=digest(binary);save()
        evidence=retained/'native-raw'
        status=run(name+'-native',[PY,str(root/'reboot/rust/tests/fixtures/workflow_app/prove_generic_tasks.py'),str(binary),str(evidence)],root/'reboot/rust',{'GENERIC_NATIVE_CASES':case})
        raw=json.loads((evidence/'receipt.json').read_text());assert status!=0 and not raw['complete'] and raw['all_original_children_waited'] and raw.get('error')
        if name=='final-workflow-only-admission':assert 'not a registered workflow' in raw['error']
        else:
            events=(evidence/case/'events').read_text().splitlines();assert events.count('remote-handler')==3
            samples=[]
            for child in raw['children']:
                if 'generic-inspect' in child['args'] and child.get('wait_returncode')==0:
                    samples.append(json.loads(Path(child['log']).read_text()))
            assert any(sample['value']==17 for sample in samples),samples
            mutant['observed_reexecutions']=3;mutant['observed_wrong_state']=17
        mutant.update(accepted_red=True,native_parent_pid=raw['parent_pid'],original_waits=len(raw['children']),native_receipt_sha256=digest(evidence/'receipt.json'));save()
    record['complete']=True
finally:
    record['all_original_children_waited']=all(c['waited_by_original_parent'] for c in record['children']);save()
assert record['complete'] and record['all_original_children_waited']
