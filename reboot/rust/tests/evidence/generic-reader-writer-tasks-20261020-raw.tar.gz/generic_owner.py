import datetime, fcntl, hashlib, json, os, pathlib, signal, subprocess, sys
HOME=pathlib.Path('/home/benchbuild')
ROOT=pathlib.Path(os.environ.get('TASK_LIFECYCLE_SOURCE', str(HOME/'.cache/generic-writer-20261020-src')))
OUT=HOME/'.cache/generic-writer-20261020-evidence'; OUT.mkdir(exist_ok=True)
stage=sys.argv[1]; command=sys.argv[2:]; locks=[]
for path in [HOME/'reboot-rust/.cargo-target-acceptance/.workflow-spawn-owner.lock', HOME/'.cargo/.workflow-spawn-owner.lock', HOME/'.cache/crosswriter-cache.lock', OUT/'owner.lock']:
    handle=path.open('a+'); fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(handle)
if os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize < 30*1024**3: raise RuntimeError('disk budget <30GiB')
env=os.environ.copy(); env.update(RUSTUP_HOME=str(HOME/'.rustup'),CARGO_HOME=str(HOME/'.cargo'),CARGO_TARGET_DIR=str(HOME/'reboot-rust/.cargo-target-acceptance'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',PATH=str(HOME/'.cargo/bin')+':'+env['PATH'],REBOOT_NATIVE2PC_CXX_DATABASE=str(HOME/'.cache/hello-image-evidence/rust-context/database'))
temp=OUT/'tmp'; temp.mkdir(exist_ok=True); env['TMPDIR']=str(temp)
def inputs():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
record=dict(stage=stage,owner_pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,source=str(ROOT),source_inputs=inputs(),children=[],complete=False,
    owner_script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
def save():
    tmp=OUT/(stage+'.json.tmp'); tmp.write_text(json.dumps(record,indent=2))
    with tmp.open('rb') as f: os.fsync(f.fileno())
    os.replace(tmp,OUT/(stage+'.json')); fd=os.open(OUT,os.O_RDONLY); os.fsync(fd); os.close(fd)
def stop(*_): raise InterruptedError('owner termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,stop)
p=None
try:
    save()
    with (OUT/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen(command,cwd=ROOT/'reboot/rust',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        record['children'].append(dict(pid=p.pid,parent_pid=os.getpid(),waited_by_owner=False)); save()
        try: p.wait(timeout=3600)
        finally:
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try: p.wait(timeout=30)
                except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
            record['children'][0].update(wait_returncode=p.returncode,waited_by_owner=True); save()
        record['complete']=True
finally:
    record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat(); record['source_unchanged']=inputs()==record['source_inputs']; save()
    print(json.dumps({k:v for k,v in record.items() if k!='source_inputs'}),flush=True)
sys.exit(0 if record['complete'] and p.returncode==0 and record['source_unchanged'] else 1)
