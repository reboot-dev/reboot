import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess

SRC = Path('/home/benchbuild/.cache/crosswriter-src')
EVIDENCE = Path('/home/benchbuild/.cache/crosswriter-evidence')
lease = open('/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock', 'r')
fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
env = os.environ.copy()
env.update(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin', CARGO_HOME='/home/benchbuild/.cargo', CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance', CARGO_BUILD_JOBS='2', REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database', CARGO_NET_OFFLINE='true')
rows = []
owner = dict(pid=os.getpid(), complete=False, children=rows)
def persist():
    (EVIDENCE/'qualification-final-owner.json').write_text(json.dumps(owner, indent=2))
def run(label, args, extra=None, expected=0):
    with (EVIDENCE/(label+'.log')).open('w') as log:
        p = subprocess.Popen(args, cwd=SRC/'reboot/rust', env=env | (extra or {}), stdout=log, stderr=subprocess.STDOUT)
        row = dict(label=label, pid=p.pid, parent_pid=os.getpid(), args=list(map(str,args)))
        rows.append(row)
        persist()
        try:
            code = p.wait(timeout=1200)
        finally:
            if p.poll() is None:
                p.kill()
            p.wait()
            row.update(wait_returncode=p.returncode, waited_by_parent=True)
            row['log_sha256'] = hashlib.sha256((EVIDENCE/(label+'.log')).read_bytes()).hexdigest()
            persist()
    assert code == expected, (label, code, expected)
    print(label, code, flush=True)

manifest = str(SRC/'reboot/rust/tests/fixtures/workflow_app/Cargo.toml')
source = SRC/'reboot/rust/src/workflow_outbound_writer.rs'
original = source.read_text()
try:
    run('all-targets-final', ['cargo','test','--locked','--offline','--all-targets'])
    run('clippy-final', ['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings'])
    run('generated-clippy-final', ['cargo','clippy','--locked','--offline','--manifest-path',manifest,'--','-D','warnings'])
    # A fresh per-dispatch target key must remutate after acknowledged target
    # commit/host crash. This falsifies the actual native replay proof.
    before = '.headers(key, seed, iteration)'
    assert original.count(before) == 1
    source.write_text(original.replace(before, '.headers(uuid::Uuid::new_v4(), seed, iteration)'))
    try:
        run('red-build', ['cargo','build','--locked','--offline','--manifest-path',manifest])
        run('red-native', ['python3','tests/fixtures/workflow_app/prove_outbound.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(EVIDENCE/'native-red-final')], expected=1)
    finally:
        source.write_text(original)
    run('native-final', ['cargo','test','--locked','--offline','--test','workflow_outbound_native','generated_cross_actor_writer_ack_replay_and_fail_closed_native_restart','--','--ignored','--exact','--nocapture'], {'WORKFLOW_OUTBOUND_EVIDENCE':str(EVIDENCE/'native-final')})
    owner['complete'] = True
finally:
    assert source.read_text() == original, 'production source restoration failed'
    persist()
print(json.dumps(owner))
