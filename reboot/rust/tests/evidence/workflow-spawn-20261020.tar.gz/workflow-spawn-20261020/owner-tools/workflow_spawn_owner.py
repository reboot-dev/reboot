import datetime, fcntl, hashlib, json, os, pathlib, signal, subprocess, sys, time
root=pathlib.Path(os.environ.get('WORKFLOW_SPAWN_SOURCE','/home/benchbuild/.cache/workflow-spawn-20261020-src'))
evidence=pathlib.Path('/home/benchbuild/.cache/workflow-spawn-20261020-evidence'); evidence.mkdir(exist_ok=True)
stage=sys.argv[1]; command=sys.argv[2:]
locks=[]
for path in ['/home/benchbuild/reboot-rust/.cargo-target-acceptance/.workflow-spawn-owner.lock','/home/benchbuild/.cargo/.workflow-spawn-owner.lock']:
 h=open(path,'a+'); fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(h)
if os.statvfs(root).f_bavail*os.statvfs(root).f_frsize < 30*1024**3: raise RuntimeError('disk budget <30GiB')
env=os.environ.copy(); env.update(RUSTUP_HOME='/home/benchbuild/.rustup',CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',PATH='/home/benchbuild/.cargo/bin:'+env['PATH'],REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database')
temp=evidence/'tmp'; temp.mkdir(exist_ok=True); env['TMPDIR']=str(temp)
def inputs():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
record={'stage':stage,'owner_pid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'source_inputs':inputs(),'children':[],'complete':False}
def save():
 tmp=evidence/(stage+'.json.tmp'); tmp.write_text(json.dumps(record,indent=2));
 with tmp.open('rb') as f: os.fsync(f.fileno())
 os.replace(tmp,evidence/(stage+'.json'))
 fd=os.open(evidence,os.O_RDONLY); os.fsync(fd); os.close(fd)
def terminate(signum,frame): raise InterruptedError('owner termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,terminate)
p=None
try:
 save()
 with (evidence/(stage+'.log')).open('wb') as out:
  p=subprocess.Popen(command,cwd=root/'reboot/rust',env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  record['children'].append({'pid':p.pid,'parent_pid':os.getpid(),'waited_by_owner':False}); save()
  try: p.wait(timeout=480)
  finally:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try: p.wait(timeout=15)
    except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
   record['children'][0].update(wait_returncode=p.returncode,waited_by_owner=True); save()
  record['complete']=True
finally:
 record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat(); record['source_unchanged']=inputs()==record['source_inputs']; save()
 print(json.dumps({k:v for k,v in record.items() if k!='source_inputs'})); print((evidence/(stage+'.log')).read_text()[-14000:])
sys.exit(0 if record['complete'] and p.returncode==0 else 1)
