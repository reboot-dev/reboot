import hashlib, importlib.util, json, os, pathlib, re, shutil, tarfile
root=pathlib.Path('/home/benchbuild/.cache/workflow-spawn-20261020-evidence')
source=pathlib.Path('/home/benchbuild/.cache/workflow-spawn-20261020-src')
final=['final-all-targets','final-sdk-clippy','final-fixture-clippy','final-fixture-build','final-native']
records={stage:json.loads((root/(stage+'.json')).read_text()) for stage in final}
manifest=records['final-native']['source_inputs']
for stage,r in records.items():
 p=json.loads((root/(stage+'-parent.json')).read_text())
 assert r['complete'] and r['source_unchanged'] and r['source_inputs']==manifest
 assert r['children'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in r['children'])
 assert p['complete'] and p['owner_waited'] and p['owner_wait_returncode']==0 and p['original_owner_pid']==r['owner_pid']
 assert not pathlib.Path('/proc/'+str(r['owner_pid'])).exists()
for name,digest in manifest.items(): assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest,name
n=json.loads((root/'final-native/receipt.json').read_text())
assert n['complete'] and len(n['cases'])==16 and len(n['children'])==397
assert len({c['pid'] for c in n['children']})==397 and all(c['waited_by_parent'] for c in n['children'])
for c in n['children']:
 assert hashlib.sha256(pathlib.Path(c['log']).read_bytes()).hexdigest()==c['log_sha256']
 assert not pathlib.Path('/proc/'+str(c['pid'])).exists()
spec=importlib.util.spec_from_file_location('wire',source/'reboot/rust/tests/fixtures/workflow_app/database_ack_proxy.py'); wire=importlib.util.module_from_spec(spec); spec.loader.exec_module(wire)
loss=[]
for boundary in ['spawn','started','stored']:
 work=root/'final-native'/('unknown-'+boundary)
 observed=json.loads((work/'ack-observed.json').read_text()); body=(work/'store-request.pb').read_bytes(); response=(work/'store-response.pb').read_bytes()
 assert observed['real_store_ack_observed'] and not observed['downstream_success_delivered']
 assert hashlib.sha256(body).hexdigest()==observed['request_sha256'] and hashlib.sha256(response).hexdigest()==observed['response_sha256']
 assert wire.boundary(body)==boundary
 store=wire.fields(body); mutation=wire.fields(store[4][0]); envelope=wire.fields(mutation[2][0])
 phase=envelope[3][0] if boundary=='spawn' else wire.fields(envelope[2][0])[2][0]
 assert phase==({'spawn':1,'started':1,'stored':2}[boundary])
 loss.append({'boundary':boundary,'phase':phase,'actual_upstream_ack_sha256':observed['response_sha256']})
red=json.loads((root/'red-native/receipt.json').read_text()); snapshot=red['failure_target_snapshot']
assert not red['complete'] and snapshot['first']==21 and len(snapshot['tasks'])==3 and all(c['waited_by_parent'] for c in red['children'])
log=(root/'final-all-targets.log').read_text(); results=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
ignored=sum(r[2] for r in results)
review={'qualified':True,'full_parity':False,'published_base':'091b42d093bc2a92026322053227f81196e34f85','source_input_count':len(manifest),'qualified_stages':final,'native_cases':16,'native_original_parent_waited_children':397,'native_binary_sha256':n['binary_sha256'],'database_binary_sha256':n['database_sha256'],'library_passed':842,'library_ignored':7,'downstream_generated_tests':55,'all_targets_ignored_entries':ignored,'separately_exercised_ignored_gate':'workflow_spawn_native: 1 passed; sixteen cases','other_ignored_gates_not_requalified':True,'loss_boundaries':loss,'red':{'expected_failure':True,'actual_target_first':snapshot['first'],'actual_distinct_tasks':len(snapshot['tasks']),'waited_children':len(red['children'])},'historical_evidence_and_benchmark_modified':False,'source_unchanged_across_final_stages':True,'raw_archive_exclusions':['RocksDB directory contents (serialized exact task/receipt snapshots retained in receipts)','Cargo caches and build trees','large compiled executables (hash-pinned)','temporary downstream compile trees'],'preliminary_stages_are_not_final_source_qualification':True}
(root/'qualification-review.json').write_text(json.dumps(review,indent=2))
tools=root/'owner-tools'; tools.mkdir(exist_ok=True)
for name in ['workflow_spawn_owner.py','workflow_spawn_parent.py','workflow_spawn_package.py']: shutil.copy2('/home/benchbuild/.cache/'+name,tools/name)
raw=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or 'tmp' in p.relative_to(root).parts or any(x in p.parts for x in ['source-rocks','target-rocks','rocksdb']): continue
 if p.suffix in ['.json','.log','.pb','.jsonl','.py'] or p.name=='events': raw.append(p)
raw_manifest={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in raw}
(root/'raw-manifest.json').write_text(json.dumps(raw_manifest,indent=2)); raw.append(root/'raw-manifest.json')
archive=root.with_name('workflow-spawn-20261020-raw.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in raw: tar.add(p,arcname='workflow-spawn-20261020/'+str(p.relative_to(root)),recursive=False)
print(json.dumps(review)); print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'raw_files':len(raw)}))
