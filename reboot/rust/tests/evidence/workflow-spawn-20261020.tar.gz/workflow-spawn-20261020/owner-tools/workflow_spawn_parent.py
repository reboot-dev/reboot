import datetime, hashlib, json, os, pathlib, signal, subprocess, sys
root=pathlib.Path('/home/benchbuild/.cache/workflow-spawn-20261020-evidence'); root.mkdir(exist_ok=True)
stage=sys.argv[1]
command=[sys.executable,'/home/benchbuild/.cache/workflow_spawn_owner.py',*sys.argv[1:]]
record={'stage':stage,'durable_parent_pid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'owner_waited':False,'complete':False,'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'owner_script_sha256':hashlib.sha256(pathlib.Path(command[1]).read_bytes()).hexdigest()}
def save():
 p=root/(stage+'-parent.json.tmp'); p.write_text(json.dumps(record,indent=2))
 with p.open('rb') as f: os.fsync(f.fileno())
 os.replace(p,root/(stage+'-parent.json')); fd=os.open(root,os.O_RDONLY); os.fsync(fd); os.close(fd)
def terminate(*_): raise InterruptedError('outer parent termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,terminate)
p=None
try:
 save()
 with (root/(stage+'-parent.log')).open('wb') as log:
  p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
  record['original_owner_pid']=p.pid; save()
  try: p.wait(timeout=515)
  finally:
   if p.poll() is None:
    p.terminate()
    try: p.wait(timeout=30)
    except subprocess.TimeoutExpired: p.kill(); p.wait()
   record.update(owner_waited=True,owner_wait_returncode=p.returncode); save()
  record['complete']=True
finally:
 record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
 print(json.dumps(record)); print((root/(stage+'-parent.log')).read_text()[-17000:])
sys.exit(0 if record['complete'] and p.returncode==0 else 1)
