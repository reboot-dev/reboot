"""Verify finite owners, freeze compact native evidence and source objects."""
import datetime,hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/ordinary-running-final4-20261020-src');OUT=Path('/home/benchbuild/.cache/ordinary-running-20261020-evidence')
RUN=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot');PREFIX='greenfinal4'
ARCHIVE=OUT.parent/'ordinary-running-cancellation-20261020-raw.tar.gz'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=dict(base_commit='837c7e1f6ad1a50408b1ef41424d768759249f09',complete=False,fresh_cpp_build=False,native_artifact_reused=True,compile_receipts_reused=False,native={},cleanup_drills={},owners={},limits=['explicit registered existing actors','DatabaseAdapter generic reader/writer; workflow-bearing ordinary writers','no transaction-adapter/task integration','cooperative local ordinary body interruption only; synchronous code and submitted remote effects not revoked','typed protobuf declared variants only; unary DeclaredStatus not a task outcome','no dynamic placement, cursor admission/GC or Python-hosted UUID allocation'])
for stage,unit in [('greenfinal4','ordinary-running-greenfinal4-20261020'),('mutants4','ordinary-running-mutants4-20261020')]:
    owner=json.loads((OUT/(stage+'.json')).read_text());assert owner['complete'] and owner['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
    sd=subprocess.run(['systemctl','show',unit,'-p','MainPID','-p','ActiveState','-p','Result','-p','ExecMainStatus'],capture_output=True,text=True,check=True).stdout
    assert 'MainPID=0' in sd and 'ActiveState=inactive' in sd and 'Result=success' in sd
    summary['owners'][stage]=dict(systemd=sd,receipt_sha256=digest(OUT/(stage+'.json')),owner_pid=owner['owner_pid'],children=owner['children'])
gates=json.loads((OUT/(PREFIX+'-gates.json')).read_text());assert gates['complete'] and gates['source_unchanged'] and all(g.get('accepted') and g['waited_by_original_parent'] for g in gates['gates']);summary['gates']=gates
all_pids=[]
for folder in ['running','generic','workflow-writer','canonical','migration','lifecycle','spawn']:
    path=OUT/(PREFIX+'-'+folder+'-raw/receipt.json');raw=json.loads(path.read_text());assert raw['complete'] and raw['children'] and all(c['waited_by_parent'] for c in raw['children'])
    assert raw.get('all_original_children_waited',True)
    assert raw['binary_sha256']==gates['fixture_binary_sha256'];assert len({(c['parent_pid'],c['pid']) for c in raw['children']})==len(raw['children'])
    summary['native'][folder]=dict(cases=len(raw['cases']),case_names=[c['case'] for c in raw['cases']],original_child_waits=len(raw['children']),receipt_sha256=digest(path),parent_pid=raw['parent_pid'])
    all_pids += [c['pid'] for c in raw['children']]+[raw['parent_pid']]
for fault in ['error','signal']:
    path=OUT/(PREFIX+'-parent-'+fault+'-raw/receipt.json');raw=json.loads(path.read_text());assert not raw['complete'] and raw['all_original_children_waited'] and raw.get('error')
    summary['cleanup_drills'][fault]=dict(original_child_waits=len(raw['children']),receipt_sha256=digest(path),error=raw['error']);all_pids += [c['pid'] for c in raw['children']]+[raw['parent_pid']]
mutants=json.loads((OUT/'mutants-final4-controller.json').read_text());assert mutants['complete'] and mutants['all_original_children_waited'] and all(m['accepted_red'] for m in mutants['mutants']);summary['mutants']=mutants
for mutant in mutants['mutants']:
    retained=OUT/('mutant-'+mutant['name'])
    for change in mutant['changes']:
        relative=change['relative'];key=relative.replace('/','-')
        assert digest(retained/(key+'.green'))==digest(ROOT/'reboot/rust'/relative)==change['green_sha256']
        assert digest(retained/(key+'.parent'))==change['parent_sha256']
        assert digest(retained/(key+'.diff'))==change['diff_sha256']
    root=Path(mutant['source_root'])
    def source_inputs(source):
        return {str(p.relative_to(source)):digest(p) for p in (source/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
    green_inputs=source_inputs(ROOT);mutant_inputs=source_inputs(root)
    differences=sorted(k for k in set(green_inputs)|set(mutant_inputs) if green_inputs.get(k)!=mutant_inputs.get(k))
    assert differences==sorted('reboot/rust/'+c['relative'] for c in mutant['changes'])
    (retained/'source-inputs.json').write_text(json.dumps(dict(green=green_inputs,mutant=mutant_inputs,differences=differences),indent=2,sort_keys=True))
    mutant['source_differences']=differences
    for case in mutant['cases']:
        raw=json.loads((retained/(case['case']+'-raw/receipt.json')).read_text())
        assert not raw['complete'] and raw['all_original_children_waited'] and case['accepted_red']
        all_pids += [c['pid'] for c in raw['children']]+[raw['parent_pid']]
summary['attempt_retirement']=[]
for path in OUT.rglob('receipt.json'):
    raw=json.loads(path.read_text())
    if 'children' not in raw or 'parent_pid' not in raw:continue
    assert raw.get('all_original_children_waited',True) and raw['children'] and all(c['waited_by_parent'] for c in raw['children']),path
    all_pids += [c['pid'] for c in raw['children']]+[raw['parent_pid']]
    summary['attempt_retirement'].append(dict(receipt=str(path.relative_to(OUT)),complete=raw.get('complete'),original_child_waits=len(raw['children']),all_waited=True))
for path in OUT.glob('*.json'):
    if path.name in ['qualification.json','archive-members.json','archive-receipt.json']:continue
    value=json.loads(path.read_text())
    if 'owner_pid' in value:all_pids.append(value['owner_pid']);all_pids += [c['pid'] for c in value.get('children',[]) if isinstance(c,dict) and 'pid' in c]
    if 'parent_pid' in value:all_pids.append(value['parent_pid'])
    if path.name.endswith('-gates.json'):all_pids += [g['pid'] for g in value.get('gates',[]) if 'pid' in g]
alive=[pid for pid in set(all_pids) if Path('/proc')/str(pid) != Path('/proc')/str(os.getpid()) and (Path('/proc')/str(pid)).exists()]
assert not alive,alive
summary['retired_owned_pids']=sorted(set(all_pids));summary['all_original_children_retired']=True
log=(OUT/(PREFIX+'-all-targets.log')).read_text();matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log);assert matches and all(v[0]=='ok' and int(v[2])==0 for v in matches)
summary['all_targets']=dict(library_passed=int(matches[0][1]),library_ignored=int(matches[0][3]),total_passed=sum(int(v[1]) for v in matches),total_ignored=sum(int(v[3]) for v in matches),suite_results=matches)
consumer=re.search(r'Running unittests src/lib\.rs \([^\n]*reboot_rust_build_fixture[^\n]*\)\n(.*?)\n\s*Doc-tests reboot_rust_build_fixture',log,re.S);assert consumer;summary['all_targets']['generated_consumer_passed']=int(re.findall(r'test result: ok\. (\d+) passed;',consumer.group(1))[-1])
summary['additional_test_suites']={}
for name in ['sdk-doctests','fixture-tests']:
    results=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(PREFIX+'-'+name+'.log')).read_text())
    assert results and all(v[0]=='ok' and int(v[2])==0 for v in results)
    summary['additional_test_suites'][name]=dict(passed=sum(int(v[1]) for v in results),ignored=sum(int(v[3]) for v in results),results=results)
summary['native_case_total']=sum(v['cases'] for v in summary['native'].values());summary['native_original_wait_total']=sum(v['original_child_waits'] for v in summary['native'].values())
manifest=json.loads((OUT/(PREFIX+'-source-inputs.json')).read_text());objects={}
summary['legacy_artifact_reused']=True;summary['legacy_binary_sha256']=manifest['tools/legacy-rust-app']
for key,expected in manifest.items():
    if key.startswith('source/'):p=ROOT/key.removeprefix('source/')
    elif key.startswith('python-runfiles/'):p=RUN/key.removeprefix('python-runfiles/')
    elif key=='tools/python-generator-launcher':p=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python')
    else:continue
    assert digest(p)==expected,(key,'changed')
    target=OUT/'objects'/expected;target.parent.mkdir(exist_ok=True)
    if not target.exists():target.write_bytes(p.read_bytes())
    objects[key]=dict(sha256=expected,member='objects/'+expected,bytes=p.stat().st_size)
summary['source_input_count']=len(manifest);summary['source_object_count']=len({v['sha256'] for v in objects.values()});summary['source_manifest_sha256']=digest(OUT/(PREFIX+'-source-inputs.json'));summary['fixture_binary_sha256']=gates['fixture_binary_sha256'];summary['native_database_sha256']=manifest['tools/native-database-reused'];summary['generated_rust_outputs']={}
for line in (OUT/(PREFIX+'-fixture-build.log')).read_text().splitlines():
    try:value=json.loads(line)
    except json.JSONDecodeError:continue
    if value.get('reason')=='compiler-artifact' and value.get('executable') and value.get('target',{}).get('name')=='generated-workflow-app':summary['fixture_cargo_artifact']=value
    if value.get('reason')!='build-script-executed' or not any(name in value.get('package_id','') for name in ['reboot-rust-schema','generated-workflow-app']):continue
    source=Path(value['out_dir'])
    for original in source.rglob('*.rs'):
        target=OUT/'generated-rust'/source.parent.name/original.relative_to(source);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes());summary['generated_rust_outputs'][str(target.relative_to(OUT))]=dict(sha256=digest(target),observed_build_output=str(original),cargo_package_id=value['package_id'])
assert summary['generated_rust_outputs'] and summary['fixture_cargo_artifact']
for p in OUT.parent.glob('ordinary_*.py'):(OUT/p.name).write_bytes(p.read_bytes())
(OUT/'source-objects.json').write_text(json.dumps(objects,indent=2,sort_keys=True));summary['complete']=True
(OUT/'qualification.json').write_text(json.dumps(summary,indent=2,sort_keys=True))
files=[]
for directory,dirs,names in os.walk(OUT):
    dirs[:]=[n for n in dirs if n!='tmp' and '__pycache__' not in n and not n.endswith('rocks')]
    for name in names:
        p=Path(directory)/name
        if p.is_symlink() or name in ['archive-members.json','archive-receipt.json'] or name.endswith('.tmp'):continue
        with p.open('rb') as stream:elf=stream.read(4)==b'\x7fELF'
        if elf:continue
        assert p.stat().st_size<20*1024**2,(p,'unexpected large nonbinary')
        files.append(p)
files.sort();inventory={str(p.relative_to(OUT)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in files};(OUT/'archive-members.json').write_text(json.dumps(inventory,indent=2,sort_keys=True))
with tarfile.open(ARCHIVE,'w:gz') as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
    tar.add(OUT/'archive-members.json',arcname='archive-members.json',recursive=False)
record=dict(archive_sha256=digest(ARCHIVE),bytes=ARCHIVE.stat().st_size,file_members=len(inventory)+1,qualification_sha256=digest(OUT/'qualification.json'),source_manifest_sha256=summary['source_manifest_sha256'],large_executables_included=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(OUT/'archive-receipt.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print(json.dumps({k:summary[k] for k in ['all_targets','native_case_total','native_original_wait_total','fixture_binary_sha256','native']}))
