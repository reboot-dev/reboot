import os, subprocess, pathlib
H=pathlib.Path('/home/benchbuild'); R=H/'.cache/ordinary-running-20261020-src'; O=H/'.cache/ordinary-running-20261020-evidence'
B=O/'probe-app'; B.write_bytes((H/'reboot-rust/.cargo-target-acceptance/debug/generated-workflow-app').read_bytes());B.chmod(0o755)
run=H/'reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot'
env=os.environ.copy()|dict(CANONICAL_PYTHON_RUNFILES=str(run),CANONICAL_PYTHON_PLUGIN=str(H/'reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python'),GENERIC_NATIVE_CASES='running-writer,running-reader,running-cancel-ack-loss,running-after-store,running-cancel-drop')
subprocess.run([str(H/'reboot-rust/.venv-acceptance/bin/python'),str(R/'reboot/rust/tests/fixtures/workflow_app/prove_generic_tasks.py'),str(B),str(O/'probe2-raw')],env=env,check=True,timeout=240)
