import difflib,hashlib,json,os,shutil,signal,subprocess
from pathlib import Path
H=Path('/home/benchbuild');ROOT=H/'.cache/ordinary-running-final5-20261020-src';OUT=H/'.cache/ordinary-running-20261020-evidence';PY=str(H/'reboot-rust/.venv-acceptance/bin/python')
ENV=os.environ.copy()|dict(CANONICAL_PYTHON_RUNFILES=str(H/'reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot'),CANONICAL_PYTHON_PLUGIN=str(H/'reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python'))
record=dict(complete=False,parent_pid=os.getpid(),mutants=[],children=[])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
    tmp=OUT/'mutants-final5-controller.json.tmp';tmp.write_text(json.dumps(record,indent=2))
    with tmp.open('rb') as f:os.fsync(f.fileno())
    os.replace(tmp,OUT/'mutants-final5-controller.json');fd=os.open(OUT,os.O_RDONLY);os.fsync(fd);os.close(fd)
def stop(*_):raise InterruptedError('ordinary mutant owner stopped')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,stop)
def run(name,cmd,root,env=None):
    child=dict(name=name,command=cmd,parent_pid=os.getpid(),waited_by_original_parent=False);record['children'].append(child);save()
    with (OUT/(name+'.log')).open('wb') as log:
        p=subprocess.Popen(cmd,cwd=root/'reboot/rust',env=ENV|(env or {}),stdout=log,stderr=subprocess.STDOUT);child['pid']=p.pid;save()
        try:p.wait(timeout=600)
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=40)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            child.update(waited_by_original_parent=True,exit=p.returncode);save()
    return p.returncode
try:
    name='old-parked-body5';root=ROOT.parent/('ordinary-running-mutant-'+name);shutil.copytree(ROOT,root,symlinks=True,ignore=shutil.ignore_patterns('__pycache__'))
    # Reproduce the actual reviewed parent SDK, while retaining the exact new
    # generated application fixture/proof. No test-only runtime flag is used.
    changes=[];retained=OUT/('mutant-'+name);retained.mkdir()
    parent=H/'.cache/generic-writer-20261020-src'
    for relative in ['src/one_shot_tasks.rs','src/task_cancellation.rs','src/task_cancellation_tests.rs','src/local_retry_tests.rs']:
        green=ROOT/'reboot/rust'/relative;old=parent/'reboot/rust'/relative;target=root/'reboot/rust'/relative
        before=green.read_bytes();after=old.read_bytes();target.write_bytes(after)
        key=relative.replace('/','-');(retained/(key+'.green')).write_bytes(before);(retained/(key+'.parent')).write_bytes(after)
        patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='green/'+relative,tofile='parent/'+relative));(retained/(key+'.diff')).write_text(patch)
        changes.append(dict(relative=relative,green_sha256=digest(green),parent_sha256=digest(old),diff_sha256=digest(retained/(key+'.diff'))))
    mutant=dict(name=name,source_root=str(root),parent_commit='837c7e1f6ad1a50408b1ef41424d768759249f09',changes=changes,cases=[]);record['mutants'].append(mutant);save()
    assert run(name+'-build',['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'],root)==0
    binary=retained/'app';shutil.copy2(Path(ENV['CARGO_TARGET_DIR'])/'debug/generated-workflow-app',binary);mutant['binary_sha256']=digest(binary);save()
    for case in ['running-writer','running-reader']:
        evidence=retained/(case+'-raw')
        status=run(name+'-'+case,[PY,str(root/'reboot/rust/tests/fixtures/workflow_app/prove_generic_tasks.py'),str(binary),str(evidence)],root,{'GENERIC_NATIVE_CASES':case})
        raw=json.loads((evidence/'receipt.json').read_text());assert status!=0 and not raw['complete'] and raw['all_original_children_waited'] and 'FutureTimeoutError' in raw['error'],raw.get('error')
        assert (evidence/case/'body').exists()
        mutant['cases'].append(dict(case=case,accepted_red=True,native_receipt_sha256=digest(evidence/'receipt.json'),original_waits=len(raw['children']),error=raw['error']));save()
    mutant['accepted_red']=True;record['complete']=True
finally:
    record['all_original_children_waited']=all(c['waited_by_original_parent'] for c in record['children']);save()
assert record['complete'] and record['all_original_children_waited']
