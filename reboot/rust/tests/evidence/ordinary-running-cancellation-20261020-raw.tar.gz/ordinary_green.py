import datetime,hashlib,json,os,signal,subprocess
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/ordinary-running-20261020-src');OUT=Path('/home/benchbuild/.cache/ordinary-running-20261020-evidence')
PREFIX='greenfinal'
BIN=OUT/(PREFIX+'-app');PY='/home/benchbuild/reboot-rust/.venv-acceptance/bin/python'
RUN=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot')
ENV=os.environ.copy()|dict(CANONICAL_TASK_BIN=str(BIN),CANONICAL_TASK_PYTHON=PY,CANONICAL_TASK_EVIDENCE=str(OUT/(PREFIX+'-canonical-raw')),GENERIC_TASK_EVIDENCE=str(OUT/(PREFIX+'-generic-raw')),CANONICAL_MIGRATION_EVIDENCE=str(OUT/(PREFIX+'-migration-raw')),CANONICAL_LEGACY_BIN='/home/benchbuild/.cache/canonical-admission-20261020-evidence/legacy-app',CANONICAL_LEGACY_SOURCE_COMMIT='18175834a9df99aeda94786e6d804570c25f6083',CANONICAL_PYTHON_PLUGIN='/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python',CANONICAL_PYTHON_RUNFILES=str(RUN),WORKFLOW_TASK_BIN=str(BIN),WORKFLOW_TASK_PYTHON=PY,WORKFLOW_TASK_EVIDENCE=str(OUT/(PREFIX+'-lifecycle-raw')),WORKFLOW_SPAWN_BIN=str(BIN),WORKFLOW_SPAWN_PYTHON=PY,WORKFLOW_SPAWN_EVIDENCE=str(OUT/(PREFIX+'-spawn-raw')))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
    paths=[p for p in (ROOT/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts]
    paths+=list((ROOT/'rbt').rglob('*.proto'))
    paths += [ROOT/'reboot/templates/reboot.py.j2',ROOT/'reboot/protoc_gen_reboot_python.py',ROOT/'reboot/protoc_gen_reboot_generic.py',ROOT/'reboot/server/database.cc']
    result={'source/'+str(p.relative_to(ROOT)):digest(p) for p in paths}
    for package in ['reboot','rbt']:
        for p in (RUN/package).rglob('*'):
            if p.is_file() and p.suffix in ['.py','.j2'] and '__pycache__' not in p.parts:result['python-runfiles/'+str(p.relative_to(RUN))]=digest(p)
    result['tools/python-generator-launcher']=digest(Path(ENV['CANONICAL_PYTHON_PLUGIN']));result['tools/native-database-reused']=digest(Path(ENV['REBOOT_NATIVE2PC_CXX_DATABASE']))
    result['tools/legacy-rust-app']=digest(Path(ENV['CANONICAL_LEGACY_BIN']))
    return result
for relative in ['reboot/templates/reboot.py.j2','reboot/protoc_gen_reboot_python.py','reboot/protoc_gen_reboot_generic.py']:assert digest(ROOT/relative)==digest(RUN/relative)
assert digest(Path(ENV['REBOOT_NATIVE2PC_CXX_DATABASE']))=='619002c569e9841144a8bbedf4f2ce6a753bb0e6b103af71883d91d43f413803'
manifest=inputs();(OUT/(PREFIX+'-source-inputs.json')).write_text(json.dumps(manifest,indent=2,sort_keys=True))
receipt=dict(complete=False,parent_pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit='837c7e1f6ad1a50408b1ef41424d768759249f09',gates=[],source_manifest_sha256=digest(OUT/(PREFIX+'-source-inputs.json')),native_artifact_reused=True,fresh_cpp_build=False)
def save():
    p=OUT/(PREFIX+'-gates.json.tmp');p.write_text(json.dumps(receipt,indent=2))
    with p.open('rb') as f:os.fsync(f.fileno())
    os.replace(p,OUT/(PREFIX+'-gates.json'));fd=os.open(OUT,os.O_RDONLY);os.fsync(fd);os.close(fd)
def interrupted(*_):raise InterruptedError('generic qualification controller termination')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,interrupted)
def run(name,command,env=None,expected=0,timeout=1200):
    log=OUT/(PREFIX+'-'+name+'.log');gate=dict(name=name,command=command,expected_exit=expected,waited_by_original_parent=False);receipt['gates'].append(gate);save()
    with log.open('wb') as out:
        p=subprocess.Popen(command,cwd=ROOT/'reboot/rust',env=ENV|(env or {}),stdout=out,stderr=subprocess.STDOUT);gate['pid']=p.pid;save()
        try:p.wait(timeout=timeout)
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=40)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            gate.update(waited_by_original_parent=True,exit=p.returncode,log_sha256=digest(log));save()
    assert (p.returncode==0 if expected==0 else p.returncode!=0),(name,p.returncode,log)
    gate['accepted']=True;save()
save()
try:
    if PREFIX=='greenfinal':
        run('sdk-package-clean',['cargo','clean','--locked','--offline','-p','reboot-rust-schema'])
    run('fixture-build',['cargo','build','--locked','--offline','--message-format=json','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'])
    BIN.write_bytes((Path(os.environ['CARGO_TARGET_DIR'])/'debug/generated-workflow-app').read_bytes());BIN.chmod(0o755);receipt['fixture_binary_sha256']=digest(BIN);save()
    run('native-running',['cargo','test','--locked','--offline','--features','build,test-support','--test','canonical_task_admission_native','canonical_python_running_ordinary_cancellation_native','--','--ignored'],{'RUNNING_TASK_EVIDENCE':str(OUT/(PREFIX+'-running-raw'))})
    run('native-generic',['cargo','test','--locked','--offline','--features','build,test-support','--test','canonical_task_admission_native','canonical_python_generic_reader_writer_tasks_native','--','--ignored'])
    run('native-workflow-writer',['cargo','test','--locked','--offline','--features','build,test-support','--test','canonical_task_admission_native','canonical_python_workflow_bearing_writer_tasks_native','--','--ignored'],{'WORKFLOW_WRITER_TASK_EVIDENCE':str(OUT/(PREFIX+'-workflow-writer-raw'))})
    run('all-targets',['cargo','test','--locked','--offline','--all-targets','--features','build,test-support'])
    run('sdk-clippy',['cargo','clippy','--locked','--offline','--all-targets','--features','build,test-support','--','-D','warnings'])
    run('fixture-clippy',['cargo','clippy','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml','--all-targets','--','-D','warnings'])
    run('native-canonical',['cargo','test','--locked','--offline','--features','build,test-support','--test','canonical_task_admission_native','canonical_python_generated_spawn_and_typed_task_retained_replay','--','--ignored'])
    run('native-migration',['cargo','test','--locked','--offline','--features','build,test-support','--test','canonical_task_admission_native','legacy_started_intent_migrates_without_new_identity_or_unverified_uuid','--','--ignored'])
    run('native-lifecycle',['cargo','test','--locked','--offline','--features','build,test-support','--test','workflow_task_native','--','--ignored'])
    run('native-spawn',['cargo','test','--locked','--offline','--features','build,test-support','--test','workflow_spawn_native','--','--ignored'])
    for fault in ['error','signal']:
        folder=OUT/(PREFIX+'-parent-'+fault+'-raw')
        run('parent-'+fault,[PY,str(ROOT/'reboot/rust/tests/fixtures/workflow_app/prove_generic_tasks.py'),str(BIN),str(folder)],{'GENERIC_NATIVE_FAULT_AFTER_START':fault,'GENERIC_NATIVE_CASES':'success'},expected=1)
        raw=json.loads((folder/'receipt.json').read_text());assert not raw['complete'] and raw['all_original_children_waited'] and raw.get('error')
    for folder in ['running','generic','workflow-writer','canonical','migration','lifecycle','spawn']:
        raw=json.loads((OUT/(PREFIX+'-'+folder+'-raw/receipt.json')).read_text());assert raw['complete'] and all(c['waited_by_parent'] for c in raw['children'])
    receipt['complete']=True
finally:
    receipt['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['source_unchanged']=inputs()==manifest;save()
assert receipt['complete'] and receipt['source_unchanged']
print(json.dumps(receipt),flush=True)
