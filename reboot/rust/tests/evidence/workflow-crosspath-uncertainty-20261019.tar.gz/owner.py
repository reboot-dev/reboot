import fcntl, hashlib, json, os, subprocess
from pathlib import Path
SRC=Path('/home/benchbuild/.cache/ackloss-crosspath-src/reboot/rust')
ROOT=Path('/home/benchbuild/.cache/ackloss-crosspath-evidence/run1')
ROOT.mkdir(exist_ok=False)
locks=[]
for name in ['/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock','/home/benchbuild/.cache/crosswriter-cache.lock']:
    lock=open(name,'r'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(lock)
env=os.environ.copy()|dict(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database',TMPDIR=str(ROOT/'tmp'))
(ROOT/'tmp').mkdir(exist_ok=True)
rows=[]
owner=dict(pid=os.getpid(),complete=False,children=rows)
def persist(): (ROOT/'owner.json').write_text(json.dumps(owner,indent=2))
def run(label,args,expected=0):
    with (ROOT/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,cwd=SRC,env=env,stdout=log,stderr=subprocess.STDOUT)
        record=dict(label=label,pid=child.pid,parent_pid=os.getpid(),args=args);rows.append(record);persist()
        code=child.wait()
        record.update(wait_returncode=code,waited_by_parent=True,log_sha256=hashlib.sha256((ROOT/(label+'.log')).read_bytes()).hexdigest());persist()
    print(label,code,flush=True)
    assert code==expected,(label,code)
def hashes():
    return {str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.rglob('*')) if p.is_file() and 'target' not in p.parts and '__pycache__' not in p.parts and p.suffix in ['.rs','.py','.proto','.toml','.lock']}
manifest=str(SRC/'tests/fixtures/workflow_app/Cargo.toml')
proof=['/home/benchbuild/.cache/ackloss-venv/bin/python','tests/fixtures/workflow_app/prove_ack_loss.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app']
source=SRC/'src/workflow_store.rs'
red=source.read_bytes()
green=Path('/home/benchbuild/.cache/ackloss-crosspath-evidence/workflow_store.green.rs').read_bytes()
try:
    run('fixture-fmt',['rustfmt','--edition','2024','--config','skip_children=true','tests/fixtures/workflow_app/src/crosspath.rs','tests/fixtures/workflow_app/src/main.rs'])
    run('red-build',['cargo','build','--locked','--offline','--manifest-path',manifest])
    env['WORKFLOW_ACK_CROSSPATH_ONLY']='1'
    run('native-red',proof+[str(ROOT/'native-red')],expected=1)
    assert 'called `Result::unwrap_err()` on an `Ok` value' in (ROOT/'native-red/005.log').read_text()
    source.write_bytes(green)
    frozen=hashes(); (ROOT/'source-sha256.json').write_text(json.dumps(frozen,indent=2))
    run('fmt',['rustfmt','--check','--edition','2024','--config','skip_children=true','src/workflow_store.rs','tests/fixtures/workflow_app/src/crosspath.rs','tests/fixtures/workflow_app/src/main.rs'])
    run('build',['cargo','build','--locked','--offline','--manifest-path',manifest])
    run('native-green',proof+[str(ROOT/'native-green')])
    run('all-targets',['cargo','test','--locked','--offline','--all-targets'])
    run('clippy',['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings'])
    run('fixture-clippy',['cargo','clippy','--locked','--offline','--manifest-path',manifest,'--','-D','warnings'])
    env.pop('WORKFLOW_ACK_CROSSPATH_ONLY')
    run('native-full',proof+[str(ROOT/'native-full')])
    assert hashes()==frozen,'source changed across acceptance'
    owner.update(source_freeze_verified=True,complete=True)
finally:
    persist()
