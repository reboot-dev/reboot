import fcntl, hashlib, json, pathlib, re, tarfile, os
R=pathlib.Path('/home/benchbuild/.cache/ackloss-crosspath-evidence')
S=pathlib.Path('/home/benchbuild/.cache/ackloss-crosspath-src/reboot/rust')
final=R/'run2'
owner=json.loads((final/'owner.json').read_text())
assert owner['complete'] and owner['source_freeze_verified']
locks=[open(p) for p in ['/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock','/home/benchbuild/.cache/crosswriter-cache.lock']]
for f in locks: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
receipts={str(p.relative_to(R)):json.loads(p.read_text()) for p in R.rglob('receipt.json')}
all_rows=owner['children']+[r for key,d in receipts.items() if key.startswith('run2/') for r in d['children']]
for r in all_rows:
 assert r['waited_by_parent']
 assert not pathlib.Path('/proc',str(r['pid'])).exists(),r
 assert hashlib.sha256(pathlib.Path(r.get('log',final/(r['label']+'.log'))).read_bytes()).hexdigest()==r['log_sha256'] if 'label' in r else hashlib.sha256(pathlib.Path(r['log']).read_bytes()).hexdigest()==r['log_sha256']
for d in receipts.values():
 for r in d['children']: assert not pathlib.Path('/proc',str(r['pid'])).exists()
inputs=json.loads((final/'source-sha256.json').read_text())
assert all(hashlib.sha256((S/k).read_bytes()).hexdigest()==v for k,v in inputs.items())
text=(final/'all-targets.log').read_text()
results=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
assert all(r[0]=='ok' and r[2]=='0' for r in results)
name='workflow-crosspath-uncertainty-20261019'
archive=R/(name+'.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(R.rglob('*')):
  if p.is_file() and p!=archive and p.suffix not in ['.tar','.gz'] and 'rocksdb' not in p.parts and 'tmp' not in p.parts:
   tf.add(p,arcname=str(p.relative_to(R)),recursive=False)
 for rel in ['src/workflow_store.rs','tests/fixtures/workflow_app/src/crosspath.rs','tests/fixtures/workflow_app/src/main.rs','tests/fixtures/workflow_app/prove_ack_loss.py','tests/fixtures/workflow_app/database_ack_proxy.py']:
  tf.add(S/rel,arcname='qualified-source/'+rel,recursive=False)
summary=dict(candidate_base='81c22d912733f5dbf82ed3c8bef1da5c0dfd8f4a',publication_base='bf83f08f2a5660030e62cec68c7d2bbd04c7645d',
 scope='Post-exclusive actor uncertainty admission in workflow_scheduling_writer; taskless unknown real Store ACK to fresh generated workflow-capable ordinary writer',
 qualification_host='2.29.27.53',isolated_source=str(S),evidence_root=str(R),
 source_inputs=inputs,source_input_count=len(inputs),final_owner=owner,native_receipts=receipts,
 all_targets=dict(passed=sum(int(r[1]) for r in results),failed=sum(int(r[2]) for r in results),ignored=sum(int(r[3]) for r in results),binaries=len(results)),
 final_recorded_child_rows=len(all_rows),final_native_child_rows=sum(len(d['children']) for key,d in receipts.items() if key.startswith('run2/')),
 all_recorded_processes_retired=True,approved_cache_locks_free=True,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
 red='Real withheld Store ACK committed first=7; dropped taskless handles; fresh generated ordinary First illicitly returned 8 without repair',
 green='Same actor rejects before handler/Store; other actor and independent native store both commit value=1; retained poisoned actor remains value=7',
 limitations=['Reuses pinned native C++ Database binary; no fresh C++ compile','Existing prior 291 native joins / three loss boundaries / seven regression receipts remain separate valid bounded evidence','Uncertain gate retention is per identity until restart; clean gates are weak; no hard global memory cap','No declared-error memoization, broader parity work, push, deployment, new capacity or retention changes'],
 disposition='Committed checkpoint for parent review; PAUSE unpublished')
(R/(name+'.json')).write_text(json.dumps(summary,indent=2))
print(json.dumps({k:summary[k] for k in ['source_input_count','all_targets','final_recorded_child_rows','final_native_child_rows','archive_sha256']}))
