import datetime, hashlib, json, os, re, subprocess, tarfile
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/canonical-admission-20261020-src')
OUT=Path('/home/benchbuild/.cache/canonical-admission-20261020-evidence')
RUN=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot')
ARCHIVE=Path('/home/benchbuild/.cache/workflow-canonical-admission-20261020-raw.tar.gz')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
gates=json.loads((OUT/'final5-gates.json').read_text());owner=json.loads((OUT/'final5.json').read_text());parent=json.loads((OUT/'final5-parent.json').read_text())
assert gates['complete'] and gates['source_unchanged'] and all(g.get('accepted') and g['waited_by_original_parent'] for g in gates['gates'])
assert owner['complete'] and owner['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
assert parent['complete'] and parent['owner_waited'] and parent['owner_wait_returncode']==0
systemd=subprocess.run(['systemctl','show','canonical-admission-final5','-p','MainPID','-p','ActiveState','-p','Result','-p','ExecMainStatus'],capture_output=True,text=True,check=True).stdout
assert 'MainPID=0' in systemd and 'ActiveState=inactive' in systemd and 'Result=success' in systemd
summary=dict(base_commit=gates['base_commit'],complete=True,source_unchanged=True,started=gates['started'],finished=gates['finished'],fresh_cpp_build=False,native_artifact_reused=True,fixture_binary_sha256=gates['fixture_binary_sha256'],legacy_binary_sha256=digest(OUT/'legacy-app'),native_database_sha256=digest(Path('/home/benchbuild/.cache/hello-image-evidence/rust-context/database')),gates=gates['gates'],systemd=systemd,compile_receipts_reused_from=gates.get('compile_receipts_reused_from'),only_source_delta_from_compile_qualification=gates.get('only_source_delta_from_compile_qualification'),original_remote_owner_waited=True,original_native_children_waited=True,native={},mutants={},cleanup_drills={},ignored_gates_requalified=False)
for folder in ['canonical','migration','lifecycle','spawn']:
    r=json.loads((OUT/f'final5-{folder}-raw/receipt.json').read_text());assert r['complete'] and all(c['waited_by_parent'] for c in r['children'])
    ids=[(c['parent_pid'],c['pid']) for c in r['children']];assert len(ids)==len(set(ids))
    summary['native'][folder]=dict(cases=len(r['cases']),case_names=[c['case'] for c in r['cases']],original_child_waits=len(r['children']),receipt_sha256=digest(OUT/f'final5-{folder}-raw/receipt.json'))
for p in (OUT/'mutants-final5').glob('*/result.json'):
    r=json.loads(p.read_text());assert r['rejected'] and r['expected_failure_observed'] and r['all_original_children_waited'];summary['mutants'][r['name']]=r
assert len(summary['mutants'])==3
for fault in ['error','signal']:
    r=json.loads((OUT/f'final5-parent-{fault}-raw/receipt.json').read_text());assert not r['complete'] and r['all_original_children_waited']
    summary['cleanup_drills'][fault]=dict(expected_failure=True,original_child_waits=len(r['children']),all_waited=True,error=r['error'])
log=(OUT/'final5-all-targets.log').read_text();matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
assert matches and all(v[0]=='ok' and int(v[2])==0 for v in matches)
summary['all_targets']=dict(library_passed=int(matches[0][1]),library_ignored=int(matches[0][3]),total_passed=sum(int(v[1]) for v in matches),total_ignored=sum(int(v[3]) for v in matches),suite_results=matches)
consumer=re.search(r'Running unittests src/lib\.rs \([^\n]*reboot_rust_build_fixture[^\n]*\)\n(.*?)\n\s*Doc-tests reboot_rust_build_fixture',log,re.S);assert consumer
cm=re.findall(r'test result: ok\. (\d+) passed;',consumer.group(1));assert cm;summary['all_targets']['generated_consumer_passed']=int(cm[-1])
summary['native_case_total']=sum(r['cases'] for r in summary['native'].values());summary['native_original_wait_total']=sum(r['original_child_waits'] for r in summary['native'].values())
# Retain source objects once by content hash, including real Python runtime and
# generated-module runfiles. Executables are explicitly hash-pinned, not smuggled
# into a small raw-evidence archive.
manifest=json.loads((OUT/'final5-source-inputs.json').read_text());objects={}
for key,expected in manifest.items():
    if key.startswith('source/'):p=ROOT/key.removeprefix('source/')
    elif key.startswith('python-runfiles/'):p=RUN/key.removeprefix('python-runfiles/')
    elif key=='tools/python-generator-launcher':p=Path('/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python')
    else:continue
    assert digest(p)==expected,(key,'source changed during packaging')
    target=OUT/'objects'/expected;target.parent.mkdir(exist_ok=True)
    if not target.exists():target.write_bytes(p.read_bytes())
    objects[key]=dict(sha256=expected,member='objects/'+expected,bytes=p.stat().st_size)
(OUT/'source-objects.json').write_text(json.dumps(objects,indent=2,sort_keys=True))
summary['source_manifest_sha256']=digest(OUT/'final5-source-inputs.json');summary['source_input_count']=len(manifest);summary['source_object_count']=len(set(r['sha256'] for r in objects.values()))
summary['generated_rust_outputs']={}
for output in Path('/home/benchbuild/reboot-rust/.cargo-target-acceptance/debug/build').glob('generated-workflow-app-*/out'):
    adapter=output/'workflow/v1/workflow.reboot.rs'
    if not adapter.exists() or 'spawn_workflow_canonical::<proto::Step,proto::Value>' not in adapter.read_text():continue
    for original in output.rglob('*.rs'):
        target=OUT/'generated-rust'/output.parent.name/original.relative_to(output)
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
        summary['generated_rust_outputs'][str(target.relative_to(OUT))]=dict(sha256=digest(target),observed_build_output=str(original))
assert summary['generated_rust_outputs']
for name in ['canonical_admission_parent.py','canonical_admission_owner.py','canonical_admission_mutants.py','canonical_admission_green.py','canonical_admission_green2.py','canonical_admission_green3.py','canonical_admission_green4.py','canonical_admission_green5.py','canonical_admission_package5.py']:
    p=OUT/name;p.write_bytes((OUT.parent/name).read_bytes())
(OUT/'qualification.json').write_text(json.dumps(summary,indent=2,sort_keys=True))
files=[]
for directory,dirs,names in os.walk(OUT):
    dirs[:]=[n for n in dirs if n!='tmp' and '__pycache__' not in n and not n.endswith('rocks')]
    for name in names:
        p=Path(directory)/name
        if p.is_symlink() or name in ['qualified-current-app','legacy-app','final-good-app','archive-members.json','archive-receipt.json']:continue
        if name.endswith('.tmp'):continue
        files.append(p)
files.sort();inventory={str(p.relative_to(OUT)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in files}
(OUT/'archive-members.json').write_text(json.dumps(inventory,indent=2,sort_keys=True))
with tarfile.open(ARCHIVE,'w:gz') as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
    tar.add(OUT/'archive-members.json',arcname='archive-members.json',recursive=False)
record=dict(archive_sha256=digest(ARCHIVE),bytes=ARCHIVE.stat().st_size,file_members=len(inventory)+1,qualification_sha256=digest(OUT/'qualification.json'),source_manifest_sha256=summary['source_manifest_sha256'],large_executables_included=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'archive-receipt.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));print(json.dumps({k:v for k,v in summary.items() if k in ['all_targets','native_case_total','native_original_wait_total','source_input_count','source_object_count','fixture_binary_sha256']}))
