import difflib, hashlib, json, os, signal, shutil, subprocess
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/canonical-admission-20261020-src')
TAG=os.environ.get('CANONICAL_MUTATION_TAG','v2')
OUT=Path('/home/benchbuild/.cache/canonical-admission-20261020-evidence'); DEST=OUT/('mutants-'+TAG); DEST.mkdir(exist_ok=True)
PY='/home/benchbuild/reboot-rust/.venv-acceptance/bin/python'
BASEENV=os.environ.copy()|dict(CANONICAL_PYTHON_PLUGIN='/home/benchbuild/reboot-rust/bazel-bin/reboot/protoc-gen-reboot_python',CANONICAL_PYTHON_RUNFILES='/home/benchbuild/reboot-rust/bazel-bin/reboot/cli/rbt.runfiles/com_github_reboot_dev_reboot',CANONICAL_LEGACY_BIN=str(OUT/'legacy-app'),CANONICAL_LEGACY_SOURCE_COMMIT='18175834a9df99aeda94786e6d804570c25f6083')
controls=[
 ('omit-task-trailer','reboot/rust/src/workflow_spawn.rs','        crate::successful_trailers::stage_successful_task(&mut response, uuid);','        let _ = uuid;', 'success','Trailing metadata missing for task schedule'),
 ('ignore-explicit-schedule','reboot/rust/src/workflow_spawn.rs','            request: request.get_ref().encode_to_vec(),\n            timestamp,','            request: request.get_ref().encode_to_vec(),\n            timestamp: None,','future-cancel','explicit absolute schedule was not preserved'),
 ('accept-changed-uuid','reboot/rust/src/workflow_spawn_client.rs','                    || id.as_bytes().as_slice()\n                        != initializer_uuid("reboot.workflow-spawn.task.v1", &key.to_string())','',None,'changed target UUID was acknowledged by source'),
]
records=[]
def save():
    p=DEST/'receipt.json.tmp';p.write_text(json.dumps({'children':records,'complete':len(records)==6 and all(r['waited'] for r in records)},indent=2))
    with p.open('rb') as f:os.fsync(f.fileno())
    os.replace(p,DEST/'receipt.json')
def run(cmd,log,cwd,env):
    with log.open('wb') as out:
        p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
        record=dict(pid=p.pid,parent_pid=os.getpid(),command=cmd,log=str(log),waited=False);records.append(record);save()
        try:p.wait(timeout=240)
        finally:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=30)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            record.update(waited=True,returncode=p.returncode);save()
    return p.returncode
for name,file,old,new,case,expected in controls:
    tree=ROOT.with_name('canonical-admission-mutant-'+TAG+'-'+name);shutil.copytree(ROOT,tree,symlinks=True)
    evidence=DEST/name;evidence.mkdir()
    path=tree/file;original=path.read_text();assert original.count(old)==1,(name,original.count(old));changed=original.replace(old,new,1);path.write_text(changed)
    (evidence/'source').mkdir();(evidence/'source'/Path(file).name).write_text(changed)
    (evidence/'mutation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='a/'+file,tofile='b/'+file)))
    manifest={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.py','.proto','.toml','.lock'] and 'evidence' not in p.parts}
    (evidence/'source-inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
    assert run(['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'],evidence/'build.log',tree/'reboot/rust',BASEENV)==0
    binary=Path(os.environ['CARGO_TARGET_DIR'])/'debug/generated-workflow-app'
    binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
    script='prove_canonical_admission.py' if case else 'prove_canonical_migration.py'
    env=BASEENV|({'CANONICAL_NATIVE_CASES':case} if case else {})
    code=run([PY,str(tree/'reboot/rust/tests/fixtures/workflow_app'/script),str(binary),str(evidence/'raw')],evidence/'native.log',tree/'reboot/rust',env)
    log=(evidence/'native.log').read_text();raw=json.loads((evidence/'raw/receipt.json').read_text())
    result=dict(name=name,rejected=code!=0,expected_failure_observed=expected in log,all_original_children_waited=raw['all_original_children_waited'],binary_sha256=binary_hash,mutated_source_sha256=hashlib.sha256(changed.encode()).hexdigest(),diff_sha256=hashlib.sha256((evidence/'mutation.patch').read_bytes()).hexdigest())
    (evidence/'result.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
    assert result['rejected'] and result['expected_failure_observed'] and result['all_original_children_waited'],result
save()
