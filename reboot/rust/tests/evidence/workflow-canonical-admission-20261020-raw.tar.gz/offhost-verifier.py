"""Read-only offhost verification of retained canonical-admission evidence."""
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

archive,receipt_path,repository=map(Path,sys.argv[1:])
record=json.loads(receipt_path.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(archive.read_bytes())==record['archive_sha256']
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames();assert len(names)==len(set(names))==record['file_members']
    def data(name):
        p=Path(name);assert not p.is_absolute() and '..' not in p.parts
        member=tar.getmember(name);assert member.isfile(),name
        return tar.extractfile(member).read()
    def obj(name):return json.loads(data(name))
    inventory=obj('archive-members.json');assert set(names)==set(inventory)|{'archive-members.json'}
    for name,item in inventory.items():
        value=data(name);assert len(value)==item['bytes'] and sha(value)==item['sha256'],name
    qualification=obj('qualification.json');assert sha(data('qualification.json'))==record['qualification_sha256']
    assert qualification['complete'] and qualification['source_unchanged'] and qualification['original_remote_owner_waited']
    for gate in qualification['gates']:
        assert gate['accepted'] and gate['waited_by_original_parent']
        assert sha(data(gate['name']+'.log'))==gate['log_sha256']
    manifest=obj('final5-source-inputs.json');assert sha(data('final5-source-inputs.json'))==record['source_manifest_sha256']
    old_manifest=obj('final3-source-inputs.json')
    compile_receipt=obj('final3-gates.json');assert compile_receipt['source_unchanged']
    for gate in qualification['gates']:
        if 'reused_from' not in gate:continue
        original=next(g for g in compile_receipt['gates'] if g['name']==gate['reused_from'])
        assert original['accepted'] and original['exit']==0 and original['command']==gate['command'] and original['log_sha256']==gate['log_sha256']
    delta=sorted(k for k in manifest if manifest[k]!=old_manifest.get(k))
    assert delta==qualification['only_source_delta_from_compile_qualification']==['source/reboot/rust/tests/fixtures/workflow_app/prove_canonical_admission.py','source/reboot/rust/tests/fixtures/workflow_app/tasks_terminal_proxy.py']
    source_objects=obj('source-objects.json')
    for key,item in source_objects.items():
        assert manifest[key]==item['sha256']==sha(data(item['member']))
        if key.startswith('source/'):
            local=repository/key.removeprefix('source/')
            assert sha(local.read_bytes())==item['sha256'],('publication source differs',str(local))
    native={}
    for label in ['canonical','migration','lifecycle','spawn']:
        raw=obj(f'final5-{label}-raw/receipt.json');assert raw['complete']
        assert all(c['parent_pid']==raw['parent_pid'] and c['waited_by_parent'] and 'wait_returncode' in c for c in raw['children'])
        ids=[(c['parent_pid'],c['pid']) for c in raw['children']];assert len(ids)==len(set(ids))
        native[label]={'cases':len(raw['cases']),'original_child_waits':len(raw['children'])}
        for key,value in native[label].items():assert value==qualification['native'][label][key]
        assert raw['binary_sha256']==qualification['fixture_binary_sha256']
        assert raw['database_sha256']==qualification['native_database_sha256']
    assert sum(r['cases'] for r in native.values())==qualification['native_case_total']
    assert sum(r['original_child_waits'] for r in native.values())==qualification['native_original_wait_total']
    for name,mutant in qualification['mutants'].items():
        prefix=f'mutants-final5/{name}/'
        mutant_inputs=obj(prefix+'source-inputs.json')
        different=[key for key,value in mutant_inputs.items() if manifest['source/'+key]!=value]
        assert len(different)==1,(name,different)
        key=different[0];original=data(source_objects['source/'+key]['member']);changed=data(prefix+'source/'+Path(key).name)
        assert sha(changed)==mutant_inputs[key]==mutant['mutated_source_sha256']
        diff=''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile='a/'+key,tofile='b/'+key)).encode()
        assert diff==data(prefix+'mutation.patch') and sha(diff)==mutant['diff_sha256']
        raw=obj(prefix+'raw/receipt.json');assert not raw['complete'] and raw['all_original_children_waited']
        assert all(c['waited_by_parent'] for c in raw['children'])
    for fault in ['error','signal']:
        raw=obj(f'final5-parent-{fault}-raw/receipt.json')
        assert not raw['complete'] and raw['all_original_children_waited'] and all(c['waited_by_parent'] for c in raw['children'])
    prior=obj('prior-retirement-and-stage-readback.json')
    assert prior['old_parent']['complete'] and prior['old_parent']['owner_waited'] and prior['old_parent']['owner_wait_returncode']==0
    assert all(r['complete'] and r['all_waited'] for r in prior['old_native'].values())
    assert datetime.datetime.fromisoformat(prior['old_parent']['finished'])<datetime.datetime.fromisoformat(obj('check2.json')['started'])
    log=data('final5-all-targets.log').decode();matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert int(matches[0][1])==qualification['all_targets']['library_passed'] and sum(int(r[3]) for r in matches)==qualification['all_targets']['total_ignored']
    block=re.search(r'Running unittests src/lib\.rs \([^\n]*reboot_rust_build_fixture[^\n]*\)\n(.*?)\n\s*Doc-tests reboot_rust_build_fixture',log,re.S).group(1)
    assert int(re.findall(r'test result: ok\. (\d+) passed;',block)[-1])==qualification['all_targets']['generated_consumer_passed']
result=dict(verified=True,archive_sha256=record['archive_sha256'],file_members=len(names),source_manifest_sha256=record['source_manifest_sha256'],source_input_count=len(manifest),native=native,native_cases=qualification['native_case_total'],original_native_waits=qualification['native_original_wait_total'],mutants_verified=len(qualification['mutants']),library_passed=qualification['all_targets']['library_passed'],generated_consumer_passed=qualification['all_targets']['generated_consumer_passed'],ignored=qualification['all_targets']['total_ignored'])
print(json.dumps(result,indent=2))
