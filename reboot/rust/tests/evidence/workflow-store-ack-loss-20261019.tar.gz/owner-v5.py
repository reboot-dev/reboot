import fcntl, hashlib, json, os, subprocess
from pathlib import Path
SRC=Path('/home/benchbuild/.cache/ackloss-src/reboot/rust')
ROOT=Path('/home/benchbuild/.cache/ackloss-evidence/suite-v5')
ROOT.mkdir(exist_ok=False)
locks=[]
for name in ['/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock','/home/benchbuild/.cache/crosswriter-cache.lock']:
    lock=open(name,'r'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(lock)
env=os.environ.copy()|dict(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database',TMPDIR=str(ROOT/'tmp'))
(ROOT/'tmp').mkdir(exist_ok=True)
rows=[]
owner=dict(pid=os.getpid(),complete=False,children=rows)
def persist(): (ROOT/'owner.json').write_text(json.dumps(owner,indent=2))
def run(label,args,expected=0):
    with (ROOT/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,cwd=SRC,env=env,stdout=log,stderr=subprocess.STDOUT)
        record=dict(label=label,pid=child.pid,parent_pid=os.getpid(),args=args);rows.append(record);persist()
        code=child.wait()
        record.update(wait_returncode=code,waited_by_parent=True,log_sha256=hashlib.sha256((ROOT/(label+'.log')).read_bytes()).hexdigest());persist()
    print(label,code,flush=True)
    assert code==expected,(label,code)
manifest=str(SRC/'tests/fixtures/workflow_app/Cargo.toml')
try:
    run('fmt',['cargo','fmt','--all'])
    run('fixture-fmt',['cargo','fmt','--manifest-path',manifest])
    run('build',['cargo','build','--locked','--offline','--manifest-path',manifest])
    run('native-initial',['/home/benchbuild/.cache/ackloss-venv/bin/python','tests/fixtures/workflow_app/prove_ack_loss.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(ROOT/'native-initial')])
    owner['complete']=True
finally: persist()
