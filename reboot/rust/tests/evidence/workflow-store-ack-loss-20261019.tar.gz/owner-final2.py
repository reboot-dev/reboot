import fcntl, hashlib, json, os, subprocess
from pathlib import Path
SRC=Path('/home/benchbuild/.cache/ackloss-src/reboot/rust')
ROOT=Path('/home/benchbuild/.cache/ackloss-evidence/suite-final2')
ROOT.mkdir(exist_ok=False)
locks=[]
for name in ['/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock','/home/benchbuild/.cache/crosswriter-cache.lock']:
    lock=open(name,'r'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(lock)
env=os.environ.copy()|dict(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database',TMPDIR=str(ROOT/'tmp'))
(ROOT/'tmp').mkdir(exist_ok=True)
rows=[]
owner=dict(pid=os.getpid(),complete=False,children=rows)
def persist(): (ROOT/'owner.json').write_text(json.dumps(owner,indent=2))
def run(label,args,expected=0):
    with (ROOT/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,cwd=SRC,env=env,stdout=log,stderr=subprocess.STDOUT)
        record=dict(label=label,pid=child.pid,parent_pid=os.getpid(),args=args);rows.append(record);persist()
        code=child.wait()
        record.update(wait_returncode=code,waited_by_parent=True,log_sha256=hashlib.sha256((ROOT/(label+'.log')).read_bytes()).hexdigest());persist()
    print(label,code,flush=True)
    assert code==expected,(label,code)
manifest=str(SRC/'tests/fixtures/workflow_app/Cargo.toml')
try:
    run('fmt',['rustfmt','--edition','2021','--config','skip_children=true','src/runtime.rs','src/ordinary_writer_store.rs','src/actor_uncertainty_retention_tests.rs','tests/workflow_outbound_native.rs','tests/fixtures/workflow_app/src/main.rs','tests/fixtures/workflow_app/src/outbound.rs'])
    def hashes():
        return {str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.rglob('*')) if p.is_file() and 'target' not in p.parts and '__pycache__' not in p.parts and p.suffix in ['.rs','.py','.proto','.toml','.lock']}
    frozen=hashes(); (ROOT/'source-sha256.json').write_text(json.dumps(frozen,indent=2))
    run('all-targets',['cargo','test','--locked','--offline','--all-targets'])
    run('clippy',['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings'])
    run('fixture-clippy',['cargo','clippy','--locked','--offline','--manifest-path',manifest,'--','-D','warnings'])
    source=SRC/'src/runtime.rs'; original=source.read_text()
    start=original.index('            // Weak registrations normally retire idle actor gates.')
    end=original.index('\n        }\n    }\n}',start)
    source.write_text(original[:start]+original[end:])
    try:
        run('red-build',['cargo','build','--locked','--offline','--manifest-path',manifest])
        run('native-red',['/home/benchbuild/.cache/ackloss-venv/bin/python','tests/fixtures/workflow_app/prove_ack_loss.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(ROOT/'native-red')],expected=1)
        assert 'AssertionError: 8' in (ROOT/'native-red.log').read_text()
    finally:
        source.write_text(original)
    run('build',['cargo','build','--locked','--offline','--manifest-path',manifest])
    run('native-green',['/home/benchbuild/.cache/ackloss-venv/bin/python','tests/fixtures/workflow_app/prove_ack_loss.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(ROOT/'native-green')])
    run('native-regression',['python3','tests/fixtures/workflow_app/prove_outbound.py',env['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(ROOT/'native-regression')])
    env.update(WORKFLOW_ACK_PROXY_PYTHON='/home/benchbuild/.cache/ackloss-venv/bin/python',WORKFLOW_OUTBOUND_EVIDENCE=str(ROOT/'native-wrapper'))
    run('native-wrapper',['cargo','test','--locked','--offline','--test','workflow_outbound_native','generated_writer_real_store_ack_loss_target_started_stored','--','--ignored','--exact','--nocapture'])
    assert hashes()==frozen,'source changed across acceptance'
    owner['source_freeze_verified']=True
    owner['complete']=True
finally: persist()
