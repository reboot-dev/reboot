import hashlib,json,os,re,tarfile
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/ackloss-evidence')
SRC=Path('/home/benchbuild/.cache/ackloss-src/reboot/rust')
final=ROOT/'suite-final3'
owner=json.loads((final/'owner.json').read_text())
assert owner['complete'] and owner['source_freeze_verified']
pins=json.loads((final/'source-sha256.json').read_text())
assert all(hashlib.sha256((SRC/k).read_bytes()).hexdigest()==v for k,v in pins.items())
native={label:json.loads((final/label/'receipt.json').read_text()) for label in ['native-red','native-green','native-regression']}
wrapper=json.loads((final/'native-wrapper/receipt.json').read_text())
assert native['native-green']['complete'] and native['native-regression']['complete'] and wrapper['complete']
assert not native['native-red']['complete']
assert 'AssertionError: 8' in (final/'native-red.log').read_text()
rows=[]
for r in [*native.values(),wrapper]:
    assert all(c['waited_by_parent'] and 'wait_returncode' in c for c in r['children'])
    for c in r['children']:
        assert hashlib.sha256(Path(c['log']).read_bytes()).hexdigest()==c['log_sha256']
    rows+=r['children']
assert all(c['waited_by_parent'] for c in owner['children'])
# Decode canonical wire envelopes independently from the retained hex records.
def fields(data):
    out={};pos=0
    def vint(pos):
        n=0;shift=0
        while True:
            b=data[pos];pos+=1;n|=(b&127)<<shift
            if not b&128:return n,pos
            shift+=7
    while pos<len(data):
        tag,pos=vint(pos);wire=tag&7;tag>>=3
        if wire==0:value,pos=vint(pos)
        elif wire==2:
            length,pos=vint(pos);value=data[pos:pos+length];pos+=length
        else:raise AssertionError(wire)
        out.setdefault(tag,[]).append(value)
    return out
for r in [native['native-green'],wrapper]:
    for case in r['cases']:
        record=bytes.fromhex(case['before_restart']['checkpoints'][0]['record'])
        checkpoint=fields(fields(fields(record)[2][0])[2][0])
        assert checkpoint[2]==[2 if case['boundary']=='stored' else 1]
        assert case['events'].count('remote-handler')==1
        assert case['final_target']['value']==7
        if case['boundary']!='started':assert case['retained_target']==case['final_target']
wrapper_owner=json.loads((ROOT/'wrapper/owner.json').read_text())
assert wrapper_owner['complete'] and all(c['waited_by_parent'] for c in wrapper_owner['children'])
allpids={c['pid'] for c in rows+owner['children']+wrapper_owner['children']}|{owner['pid'],wrapper_owner['pid']}|{r['parent_pid'] for r in [*native.values(),wrapper]}
failed_attempts=[]
for path in ROOT.rglob('receipt.json'):
    if path.parent in [final/k for k in native] or path.parent==final/'native-wrapper':continue
    attempt=json.loads(path.read_text())
    assert all(c['waited_by_parent'] for c in attempt['children'])
    allpids.update(c['pid'] for c in attempt['children'])
    allpids.add(attempt['parent_pid'])
    failed_attempts.append(dict(path=str(path.relative_to(ROOT)),complete=attempt['complete'],children=len(attempt['children'])))
# Wait receipts are the custody authority; absence is a fresh extra observation.
alive=[pid for pid in allpids if Path('/proc',str(pid)).exists()]
assert not alive,alive
summary=dict(base='bf83f08f2a5660030e62cec68c7d2bbd04c7645d',complete=True,source_sha256=pins,
    host='2.29.27.53',remote_source=str(SRC),remote_evidence=str(ROOT),
    library_passed=829,protoc_passed=55,strict_clippy=True,generated_fixture_strict_clippy=True,
    native_ack_loss_cases=3,native_regression_cases=7,wrapper_ack_loss_cases=3,
    native_red_expected='without uncertain-gate retention fresh mutation returned 8 instead of fail-closed',
    native_receipts={k:dict(complete=v['complete'],children=len(v['children']),sha256=hashlib.sha256((final/k/'receipt.json').read_bytes()).hexdigest()) for k,v in native.items()},
    wrapper_receipt_sha256=hashlib.sha256((final/'native-wrapper/receipt.json').read_bytes()).hexdigest(),
    failed_or_initial_attempts=failed_attempts,
    all_native_children_exact_parent_waited=True,native_children_including_red_and_wrapper=len(rows),
    source_checkpoint_phases_independently_decoded=True,all_recorded_pids_absent=True,
    native_binary_sha256=native['native-green']['binary_sha256'],database_sha256=native['native-green']['database_sha256'],
    limits=['No declared target-error memoization: all Status failures still poison an attempt and leave source intent unresolved.',
            'No network error converted to typed declared error; durable status/detail fidelity for declared target errors remains unimplemented.',
            'Fixed channels and explicit service credentials, ordinary non-constructor writers only; canonical cursor calls fail closed.',
            'No atomic multi-actor commit, automatic routing, transactions, distributed ownership or full parity claim.',
            'Reused pinned C++ Database binary; no fresh C++ compile.',
            'Uncertain registered actor gates stay process-retained until restart; clean idle gates remain weak.',
            'Prior initial crosswriter native1 remains historically unqualified; this evidence does not reconstruct its custody.',
            'No capacity/deployment/registry/expiry changes; expiry remains 2026-10-20 20:46 CEST.'])
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
archive=ROOT.parent/'workflow-store-ack-loss-20261019.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
print(json.dumps(dict(archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,native_children=len(rows),sourcepins=len(pins))))
