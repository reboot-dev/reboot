import fcntl, hashlib, json, os, subprocess
from pathlib import Path
ROOT=Path('/home/benchbuild/.cache/ackloss-evidence/wrapper')
ROOT.mkdir(exist_ok=False)
locks=[]
for path in ['/home/benchbuild/.cache/crossactor-transitive-evidence/qualification.lock','/home/benchbuild/.cache/crosswriter-cache.lock']:
    f=open(path,'r');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
env=os.environ.copy()|dict(PATH='/home/benchbuild/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database',WORKFLOW_ACK_PROXY_PYTHON='/home/benchbuild/.cache/ackloss-venv/bin/python',WORKFLOW_OUTBOUND_EVIDENCE=str(ROOT/'native'),TMPDIR=str(ROOT))
args=['cargo','test','--locked','--offline','--test','workflow_outbound_native','generated_writer_real_store_ack_loss_target_started_stored','--','--ignored','--exact','--nocapture']
with (ROOT/'test.log').open('w') as out:
    p=subprocess.Popen(args,cwd='/home/benchbuild/.cache/ackloss-src/reboot/rust',env=env,stdout=out,stderr=subprocess.STDOUT)
    code=p.wait()
(ROOT/'owner.json').write_text(json.dumps(dict(pid=os.getpid(),complete=code==0,children=[dict(pid=p.pid,parent_pid=os.getpid(),args=args,wait_returncode=code,waited_by_parent=True)],log_sha256=hashlib.sha256((ROOT/'test.log').read_bytes()).hexdigest()),indent=2))
assert code==0,code
print('wrapper PASS')
