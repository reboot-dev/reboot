import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/home/benchbuild/.cache/task-lifecycle-20261020-evidence')
source=Path('/home/benchbuild/.cache/task-lifecycle-20261020-src')
unit='task-lifecycle-final2-mutants'
end=time.monotonic()+600
while True:
    text=subprocess.check_output(['systemctl','show',unit,'-p','ActiveState','-p','MainPID','-p','Result'],text=True)
    fields=dict(line.split('=',1) for line in text.strip().splitlines())
    if fields['MainPID']=='0':
        assert fields['ActiveState']=='inactive' and fields['Result']=='success',fields
        break
    assert time.monotonic()<end,'owner still active; no competing stage launched'
    time.sleep(3)
parent=json.loads((root/'final2-mutants-parent.json').read_text())
owner=json.loads((root/'final2-mutants.json').read_text())
batch=json.loads((root/'mutations-batch-final2.json').read_text())
assert parent['complete'] and parent['owner_waited'] and parent['owner_wait_returncode']==0
assert owner['complete'] and owner['source_unchanged'] and all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
assert batch['complete'] and all(c['waited_by_parent'] and c['returncode']==0 for c in batch['children'])
inputs={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
assert inputs==json.loads((root/'final-source-inputs.json').read_text())
mutated={m['name']:m['file'] for m in batch['mutations']}
for child in batch['children']:
    record=json.loads((root/'mutants'/child['name']/'mutation.json').read_text())
    assert record['complete'] and record['expected_failure_detected'] and record['source_unchanged'] and record['all_original_native_children_waited']
    differences={name for name in inputs if inputs[name]!=record['source_inputs'][name]}
    assert differences==({mutated[child['name']]} if child['name'] in mutated else set()),(child['name'],differences)
    assert all((root/'source-objects'/digest).is_file() for digest in record['source_inputs'].values())
record=dict(previous_unit=fields,original_owner_joined=True,original_batch_children_joined=True,exact_mutant_bytes_retained=True,mutants_differ_only_at_intended_runtime_file=True,source_input_count=len(inputs),source_manifest_sha256=hashlib.sha256((json.dumps(inputs,indent=2,sort_keys=True)+'\n').encode()).hexdigest(),green_driver_sha256=hashlib.sha256(Path('/home/benchbuild/.cache/task_lifecycle_green.sh').read_bytes()).hexdigest())
(root/'final-green-admission.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
subprocess.check_call(['systemd-run','--unit=task-lifecycle-final-green','--property=KillMode=mixed','--property=TimeoutStopSec=90','/usr/bin/python3','/home/benchbuild/.cache/task_lifecycle_parent.py','final-green','/bin/bash','/home/benchbuild/.cache/task_lifecycle_green.sh'])
