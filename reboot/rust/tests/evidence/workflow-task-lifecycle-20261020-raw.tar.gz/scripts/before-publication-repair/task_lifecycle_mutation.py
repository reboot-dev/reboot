"""Run a retained source mutant against an actual native acceptance case."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import signal

def terminate(*_): raise InterruptedError('mutation owner termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,terminate)

name,case,needle=sys.argv[1:]
source=Path.cwd().parents[1]
out=Path('/home/benchbuild/.cache/task-lifecycle-20261020-evidence')/'mutants'/name
out.mkdir(parents=True,exist_ok=False)
record=dict(name=name,case=case,expected_failure_text=needle,source=str(source),complete=False)
def inputs():
    return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'reboot/rust').rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts and 'evidence' not in p.parts}
record['source_inputs']=inputs()
record['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
objects=out.parent.parent/'source-objects'; objects.mkdir(exist_ok=True)
for relative,digest in record['source_inputs'].items():
    data=(source/relative).read_bytes(); assert hashlib.sha256(data).hexdigest()==digest
    target=objects/digest
    if target.exists(): assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
    else: target.write_bytes(data)
def save():
    tmp=out/'mutation.json.tmp'; tmp.write_text(json.dumps(record,indent=2))
    with tmp.open('rb') as f: os.fsync(f.fileno())
    os.replace(tmp,out/'mutation.json')
# Preserve exact mutant bytes before any compilation/execution, not only a diff.
for relative in ['reboot/rust/src/task_cancellation.rs','reboot/rust/src/one_shot_tasks.rs','reboot/rust/src/workflow_spawn_client.rs','reboot/rust/src/workflow_spawn.rs']:
    data=(source/relative).read_bytes(); target=out/'source'/relative; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
record['mutated_source_sha256']={str(p.relative_to(out/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'source').rglob('*.rs')}; save()
def run(command,log,env=None):
    with (out/log).open('wb') as output:
        p=subprocess.Popen(command,env=env,stdout=output,stderr=subprocess.STDOUT)
        record.setdefault('children',[]).append(dict(pid=p.pid,parent_pid=os.getpid(),command=command,waited_by_parent=False)); save()
        try: p.wait(timeout=300)
        finally:
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=30)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
            record['children'][-1].update(waited_by_parent=True,returncode=p.returncode); save()
    return p.returncode
assert run(['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'],'build.log')==0
binary=Path(os.environ['CARGO_TARGET_DIR'])/'debug/generated-workflow-app'
record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest(); save()
python='/home/benchbuild/reboot-rust/.venv-acceptance/bin/python'
code=run([python,str(source/'reboot/rust/tests/fixtures/workflow_app/prove_tasks.py'),str(binary),str(out/'native')], 'native.log',os.environ.copy()|{'TASK_NATIVE_CASES':case})
raw=json.loads((out/'native/receipt.json').read_text())
assert code!=0 and needle in raw.get('failure',''), (code,raw.get('failure'))
assert raw['all_original_children_waited'] and all(c['waited_by_parent'] for c in raw['children'])
record.update(complete=True,negative_native_gate_returncode=code,expected_failure_detected=True,all_original_native_children_waited=True,actual_failure=raw['failure'],source_unchanged=inputs()==record['source_inputs']); save()
assert record['source_unchanged']
