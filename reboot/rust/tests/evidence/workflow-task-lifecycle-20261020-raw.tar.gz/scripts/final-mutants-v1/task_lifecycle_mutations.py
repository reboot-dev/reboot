"""Sequential isolated mutants plus real-parent failure/signal cleanup drills."""
import hashlib,json,os
from pathlib import Path
import shutil,signal,subprocess,sys
source=Path.cwd().parents[1]
out=Path('/home/benchbuild/.cache/task-lifecycle-20261020-evidence')
record=dict(complete=False,parent_pid=os.getpid(),children=[],mutations=[])
tag=os.environ.get('TASK_MUTATIONS_TAG','')
batch_name='mutations-batch'+tag
def save():
    tmp=out/(batch_name+'.json.tmp'); tmp.write_text(json.dumps(record,indent=2))
    with tmp.open('rb') as f: os.fsync(f.fileno())
    os.replace(tmp,out/(batch_name+'.json'))
def terminate(*_): raise InterruptedError('mutation batch termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,terminate)
def run(name,case,needle,root,env=None):
    command=[sys.executable,'/home/benchbuild/.cache/task_lifecycle_mutation.py',name,case,needle]
    with (out/(name+'-batch.log')).open('wb') as log:
        p=subprocess.Popen(command,cwd=root/'reboot/rust',env=env,stdout=log,stderr=subprocess.STDOUT)
        record['children'].append(dict(pid=p.pid,parent_pid=os.getpid(),name=name,waited_by_parent=False)); save()
        try: p.wait(timeout=650)
        finally:
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=40)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
            record['children'][-1].update(waited_by_parent=True,returncode=p.returncode); save()
    assert p.returncode==0,(name,(out/(name+'-batch.log')).read_text())
old_clock='''                    let saved = db::Task::decode(record.response.as_slice())
                        .map_err(|_| Status::data_loss("malformed relative scheduling receipt"))?;
                    task.timestamp =
                        Some(saved.timestamp.ok_or_else(|| {
                            Status::data_loss("relative receipt omitted timestamp")
                        })?);'''
mutations=[
    ('skip-notification','running-cancel','bounded observation timeout','reboot/rust/src/task_cancellation.rs','signal.send_replace(true);','// MUTANT: omit notification of the original supervised body.'),
    ('poison-catch','running-cancel','failed framework operation fences workflow scope','reboot/rust/src/workflow_spawn_client.rs','return Ok(Err(cancelled));','return Err(cancelled); // MUTANT: validated durable cancellation is misclassified as framework failure.'),
    ('leak-pending-ack','cancel-ack-loss','RPC unexpectedly succeeded','reboot/rust/src/one_shot_tasks.rs','''                if tasks.inner.cancellation_in_flight.load(std::sync::atomic::Ordering::Acquire) {
                    return Err(Status::unavailable("task cancellation ACK is pending"));
                }''','// MUTANT: disclose a cancellation terminal before its actual ACK.'),
    ('recompute-relative-clock','relative-replay','spawn key reused with changed task/payload/schedule/schema contract','reboot/rust/src/workflow_spawn.rs',old_clock,'''                    // MUTANT: recompute rather than adopt the retained admission clock.
                    task.timestamp = Some(relative_workflow_timestamp(body.relative_delay.as_ref().unwrap(),
                        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap())?);'''),
]
save()
for name,case,needle,relative,old,new in mutations:
    name+=tag
    root=source.parent/('task-lifecycle-mutant-'+name)
    shutil.copytree(source,root,symlinks=True,ignore=shutil.ignore_patterns('target','__pycache__'))
    path=root/relative; original=path.read_text(); assert original.count(old)==1,(name,original.count(old))
    path.write_text(original.replace(old,new))
    record['mutations'].append(dict(name=name,file=relative,original_sha256=hashlib.sha256(original.encode()).hexdigest(),mutant_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),root=str(root))); save()
    run(name,case,needle,root)
for fault,needle in [('error','injected lifecycle parent failure after real hosts started'),('signal','native lifecycle parent termination')]:
    run('cleanup-'+fault+tag,'running-cancel',needle,source,os.environ.copy()|{'TASK_NATIVE_FAULT_AFTER_START':fault})
record['complete']=True; save()
