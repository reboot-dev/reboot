import datetime,json,os,pathlib,signal,subprocess,sys
out=pathlib.Path('/home/benchbuild/.cache/task-lifecycle-20261020-evidence'); out.mkdir(exist_ok=True)
stage=sys.argv[1]; command=[sys.executable,'/home/benchbuild/.cache/task_lifecycle_owner.py',*sys.argv[1:]]
record=dict(stage=stage,parent_pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,owner_waited=False,complete=False)
def save():
    tmp=out/(stage+'-parent.json.tmp'); tmp.write_text(json.dumps(record,indent=2))
    with tmp.open('rb') as f: os.fsync(f.fileno())
    os.replace(tmp,out/(stage+'-parent.json')); fd=os.open(out,os.O_RDONLY); os.fsync(fd); os.close(fd)
def stop(*_): raise InterruptedError('parent termination requested')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]: signal.signal(sig,stop)
p=None
try:
    save()
    with (out/(stage+'-parent.log')).open('wb') as log:
        p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
        record['owner_pid']=p.pid; save()
        try: p.wait(timeout=1250)
        finally:
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=40)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
            record.update(owner_waited=True,owner_wait_returncode=p.returncode); save()
    record['complete']=True
finally:
    record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
sys.exit(0 if record['complete'] and p.returncode==0 else 1)
