#!/bin/bash
set -euo pipefail
printf '\nGATE all-targets\n'
cargo test --locked --offline --all-targets --features build,test-support
printf '\nGATE sdk-clippy\n'
cargo clippy --locked --offline --all-targets --features build,test-support -- -D warnings
printf '\nGATE fixture-clippy\n'
cargo clippy --locked --offline --manifest-path tests/fixtures/workflow_app/Cargo.toml --all-targets -- -D warnings
printf '\nGATE fixture-build\n'
cargo build --locked --offline --manifest-path tests/fixtures/workflow_app/Cargo.toml
printf '\nGATE native-tasks\n'
env WORKFLOW_TASK_BIN="$CARGO_TARGET_DIR/debug/generated-workflow-app" WORKFLOW_TASK_PYTHON=/home/benchbuild/reboot-rust/.venv-acceptance/bin/python WORKFLOW_TASK_EVIDENCE=/home/benchbuild/.cache/task-lifecycle-20261020-evidence/final-green-tasks-raw cargo test --locked --offline --features build,test-support --test workflow_task_native -- --ignored
printf '\nGATE native-spawn\n'
env WORKFLOW_SPAWN_BIN="$CARGO_TARGET_DIR/debug/generated-workflow-app" WORKFLOW_SPAWN_PYTHON=/home/benchbuild/reboot-rust/.venv-acceptance/bin/python WORKFLOW_SPAWN_EVIDENCE=/home/benchbuild/.cache/task-lifecycle-20261020-evidence/final-green-spawn-raw cargo test --locked --offline --features build,test-support --test workflow_spawn_native -- --ignored
printf '\nGATE all-complete\n'
