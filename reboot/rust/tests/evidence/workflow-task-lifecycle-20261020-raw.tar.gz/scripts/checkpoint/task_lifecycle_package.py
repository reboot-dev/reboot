"""Read back final owners/proofs, retain exact source objects, package raw evidence."""
import ast
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path('/home/benchbuild/.cache/task-lifecycle-20261020-evidence')
SOURCE=Path('/home/benchbuild/.cache/task-lifecycle-20261020-src')
OLD=Path('/home/benchbuild/.cache/workflow-spawn-20261020-evidence')
def load(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def state(unit):
    value=dict(line.split('=',1) for line in subprocess.check_output(['systemctl','show',unit,'-p','MainPID','-p','ActiveState','-p','Result','-p','ExecMainStatus'],text=True).strip().splitlines())
    assert value==dict(MainPID='0',ActiveState='inactive',Result='success',ExecMainStatus='0'),value
    return value
states={unit:state(unit) for unit in ['task-lifecycle-final-green3','task-lifecycle-final3-mutants']}
owner=load(ROOT/'final-green3.json'); parent=load(ROOT/'final-green3-parent.json')
assert owner['complete'] and owner['source_unchanged'] and parent['complete'] and parent['owner_waited'] and parent['owner_wait_returncode']==0
assert all(c['waited_by_owner'] and c['wait_returncode']==0 for c in owner['children'])
inputs=load(ROOT/'final-source-inputs3.json')
assert owner['source_inputs']==inputs
for relative,digest in inputs.items(): assert sha((SOURCE/relative).read_bytes())==digest,relative
objects=ROOT/'source-objects'; objects.mkdir(exist_ok=True)
def retain(data):
    digest=sha(data); path=objects/digest
    if path.exists(): assert sha(path.read_bytes())==digest
    else: path.write_bytes(data)
    return digest
for relative in inputs: retain((SOURCE/relative).read_bytes())
contracts={}
for relative in ['rbt/v1alpha1/tasks.proto','rbt/v1alpha1/errors.proto','rbt/v1alpha1/database.proto',
                 'reboot/templates/reboot.py.j2','reboot/aio/internals/tasks_servicer.py',
                 'reboot/aio/internals/tasks_dispatcher.py','reboot/aio/tasks.py','reboot/aio/contexts.py',
                 'reboot/server/database.cc','reboot/server/database.h']:
    contracts[relative]=retain((SOURCE/relative).read_bytes())
(ROOT/'mapped-contract-source-pins.json').write_text(json.dumps(contracts,indent=2,sort_keys=True)+'\n')
log=(ROOT/'final-green3.log').read_text()
parts=re.split(r'^GATE ([a-z-]+)\n',log,flags=re.M)
names=parts[1::2]; sections=dict(zip(names,parts[2::2]))
assert names==['package-clean','all-targets','sdk-clippy','fixture-clippy','fixture-build','native-tasks','native-spawn','all-complete'],names
summaries=[tuple(map(int,match)) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',sections['all-targets'])]
assert summaries and all(failed==0 for _,failed,_ in summaries)
for name in ['sdk-clippy','fixture-clippy','fixture-build']:
    assert 'Finished `dev` profile' in sections[name] and not re.search(r'^error',sections[name],re.M),name
for name in ['native-tasks','native-spawn']:
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in sections[name],name

def expected_cases(file,key):
    tree=ast.parse(file.read_text())
    found=[node.args[1].value for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='get' and len(node.args)>=2 and isinstance(node.args[0],ast.Constant) and node.args[0].value==key and isinstance(node.args[1],ast.Constant)]
    assert len(found)==1
    return found[0].split(',')
proofs={}
for label,directory,script,key in [('tasks','final-green3-tasks-raw','prove_tasks.py','TASK_NATIVE_CASES'),('spawn','final-green3-spawn-raw','prove_spawn.py','SPAWN_NATIVE_CASES')]:
    proof=load(ROOT/directory/'receipt.json')
    assert proof['complete'] and all(c['waited_by_parent'] and isinstance(c['wait_returncode'],int) and c['parent_pid']==proof['parent_pid'] for c in proof['children'])
    actual=[case['case'] for case in proof['cases']]
    assert actual==expected_cases(SOURCE/'reboot/rust/tests/fixtures/workflow_app'/script,key)
    assert len(set(actual))==len(actual)
    proofs[label]=dict(cases=actual,original_parent_waited_children=len(proof['children']),parent_pid=proof['parent_pid'],binary_sha256=proof['binary_sha256'],database_sha256=proof['database_sha256'])
assert proofs['tasks']['binary_sha256']==proofs['spawn']['binary_sha256']
assert proofs['tasks']['database_sha256']==proofs['spawn']['database_sha256']
assert sha(Path('/home/benchbuild/reboot-rust/.cargo-target-acceptance/debug/generated-workflow-app').read_bytes())==proofs['tasks']['binary_sha256']
assert sha(Path('/home/benchbuild/.cache/hello-image-evidence/rust-context/database').read_bytes())==proofs['tasks']['database_sha256']

# Independently verify retained bytes at every lost-real-ACK boundary.
acks=[]
for directory in [ROOT/'final-green3-tasks-raw',ROOT/'final-green3-spawn-raw']:
    for path in directory.glob('*/ack-observed.json'):
        observed=load(path); method=observed['method']
        assert observed['real_native_ack_observed'] and not observed['downstream_success_delivered']
        prefix='complete-task' if method=='CompleteTask' else 'store'
        request=(path.parent/(prefix+'-request.pb')).read_bytes(); response=(path.parent/(prefix+'-response.pb')).read_bytes()
        assert sha(request)==observed['request_sha256'] and sha(response)==observed['response_sha256']
        assert observed['real_store_ack_observed']==(method=='Store')
        acks.append(dict(case=path.parent.name,method=method,request_sha256=sha(request),response_sha256=sha(response)))
assert any(a['method']=='CompleteTask' for a in acks)
assert {'unknown-spawn','unknown-started','unknown-stored','relative-ack-loss'} <= {a['case'] for a in acks}

batch=load(ROOT/'mutations-batch-final3.json')
assert batch['complete'] and all(c['waited_by_parent'] and c['returncode']==0 for c in batch['children'])
mutant_files={m['name']:m['file'] for m in batch['mutations']}
mutants=[]; drills=[]
for child in batch['children']:
    if child['name']=='nonlinear-ack-fence-final3': continue
    record=load(ROOT/'mutants'/child['name']/'mutation.json')
    assert record['complete'] and record['expected_failure_detected'] and record['source_unchanged']
    differences={name for name in inputs if inputs[name]!=record['source_inputs'][name]}
    # The only follow-up to these native controls is a corrected non-native
    # contention fixture startup handshake. Every native/runtime input is exact.
    allowed={mutant_files[child['name']]} if child['name'] in mutant_files else set()
    assert differences-{'reboot/rust/src/task_cancellation_tests.rs'}==allowed
    for relative,digest in record['source_inputs'].items():
        assert (objects/digest).is_file() and sha((objects/digest).read_bytes())==digest,(child['name'],relative)
    value=dict(name=child['name'],source_unchanged=True,exact_source_objects_retained=True,
               final_native_and_runtime_inputs_match=True,unit_fixture_only_followup='reboot/rust/src/task_cancellation_tests.rs')
    if record.get('unit_red'):
        value.update(kind='unit-red',returncode=record['negative_unit_gate_returncode'])
        assert record['negative_unit_gate_returncode']!=0
    else:
        raw=load(ROOT/'mutants'/child['name']/'native/receipt.json')
        assert raw['all_original_children_waited'] and all(c['waited_by_parent'] for c in raw['children'])
        value.update(kind='native-red' if child['name'] in mutant_files else 'native-cleanup-drill',returncode=record['negative_native_gate_returncode'],original_parent_waited_children=len(raw['children']),failure=raw['failure'])
    (mutants if child['name'] in mutant_files else drills).append(value)
unit_batch=load(ROOT/'mutations-batch-final4.json')
assert unit_batch['complete'] and len(unit_batch['children'])==1 and all(c['waited_by_parent'] and c['returncode']==0 for c in unit_batch['children'])
unit_record=load(ROOT/'mutants/nonlinear-ack-fence-final4/mutation.json')
assert unit_record['complete'] and unit_record['unit_red'] and unit_record['expected_failure_detected'] and unit_record['source_unchanged']
assert {name for name in inputs if inputs[name]!=unit_record['source_inputs'][name]}=={'reboot/rust/src/task_cancellation.rs'}
for digest in unit_record['source_inputs'].values(): assert (objects/digest).is_file() and sha((objects/digest).read_bytes())==digest
mutants.append(dict(name='nonlinear-ack-fence-final4',kind='unit-red',returncode=unit_record['negative_unit_gate_returncode'],source_unchanged=True,exact_source_objects_retained=True,final_source_differs_only_at_intended_mutation=True))
assert len(mutants)==5 and sum(m['kind']=='native-red' for m in mutants)==4 and len(drills)==2

old_owner=load(OLD/'final-native.json'); old_parent=load(OLD/'final-native-parent.json'); old_proof=load(OLD/'final-native/receipt.json')
assert old_owner['complete'] and old_parent['owner_waited'] and old_parent['owner_wait_returncode']==0
assert all(c['waited_by_owner'] for c in old_owner['children']) and all(c['waited_by_parent'] for c in old_proof['children'])
assert len(old_proof['children'])==397
first=load(ROOT/'check1-parent.json')
assert datetime.datetime.fromisoformat(old_owner['finished'])<datetime.datetime.fromisoformat(first['started'])
assert datetime.datetime.fromisoformat(load(ROOT/'final3-mutants.json')['finished'])<datetime.datetime.fromisoformat(owner['started'])

live=[]
needles=['/debug/generated-workflow-app','/hello-image-evidence/rust-context/database','/prove_tasks.py','/prove_spawn.py','/database_ack_proxy.py','/tasks_terminal_proxy.py','/task_lifecycle_owner.py','/task_lifecycle_parent.py']
for path in Path('/proc').iterdir():
    if not path.name.isdigit() or int(path.name)==os.getpid(): continue
    try: command=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
    except (FileNotFoundError,PermissionError,ProcessLookupError): continue
    if any(needle in command for needle in needles): live.append(dict(pid=int(path.name),command=command))
assert not live,live
versions={}
for package in ['grpcio','grpcio-tools','protobuf']:
    versions[package]=importlib.metadata.version(package)
report=dict(qualified=True,full_python_parity=False,base_commit='151c358616341203de7dfbd2809563ea704a72e8',
    source_input_count=len(inputs),source_manifest_sha256=sha((json.dumps(inputs,indent=2,sort_keys=True)+'\n').encode()),
    ordered_gates=names,library_passed=summaries[0][0],library_ignored=summaries[0][2],all_target_reported_ignored_entries=sum(row[2] for row in summaries),
    other_ignored_gates_not_requalified=True,explicitly_exercised_ignored_gates=['workflow_task_native','workflow_spawn_native'],
    native=proofs,actual_lost_ack_bytes=acks,mutation_controls=mutants,real_parent_failure_and_signal_cleanup=drills,
    final_source_unchanged=True,original_owner_joined=True,final_systemd_readback=states,no_remaining_owned_native_processes=True,
    previous_spawn_original_children_waited=397,previous_spawn_retired_before_first_new_owner=True,
    native_artifact_reused=True,fresh_cpp_build=False,native_artifact_source_build_attestation=False,
    mapped_python_and_native_source_pins=contracts,python_runtime=sys.version,python_packages=versions,
    authorized_existing_host=dict(server_id=171072439,address='2.29.27.53',authorized_class='CCX43',expires='2026-10-20T20:46:13+02:00',extension=False),
    new_vm_install_registry_or_deploy=False,parent_heavy_cargo=False,
    preliminary_green_superseded_by='atomic cancellation ACK publication repair and healthy pending Wait',
    exclusions=['RocksDB directories; exact task/receipt snapshots retained in receipts','Cargo caches, generated temporary compile trees and large binaries; executables hash-pinned'],
    remaining_boundaries=['Rust-only spawn admission; canonical Python Tasks has no Spawn RPC','no transaction integration or arbitrary reader/writer targets','no running cursor cancellation, cursor spawn/receipt GC or dynamic placement','nonnegative target-admission-clock relative scheduling, not Python caller-clock/negative-timedelta equivalence','administrative CancelTask status timing is not Python async-CANCELLING equivalence; raw admin responses are not journaled workflow decisions','no Python-hosted application or full middleware interoperability claim'])
(ROOT/'qualification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')

# Archive every retained raw input, including exact source mutants and source objects.
files=[]
for path in ROOT.rglob('*'):
    relative=path.relative_to(ROOT)
    if any(part in ['tmp','source-rocks','target-rocks','__pycache__'] for part in relative.parts): continue
    if path.is_file() and relative.as_posix()!='archive-manifest.json':
        assert not path.is_symlink(),relative
        files.append(path)
manifest={str(path.relative_to(ROOT)):sha(path.read_bytes()) for path in sorted(files)}
(ROOT/'archive-manifest.json').write_text(json.dumps(dict(files=manifest,exclusions=report['exclusions']),indent=2,sort_keys=True)+'\n')
archive=ROOT.parent/'workflow-task-lifecycle-20261020-raw.tar.gz'
assert not archive.exists(),archive
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for path in sorted(files+[ROOT/'archive-manifest.json']): tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
result=dict(archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,retained_files=len(manifest)+1,qualification_sha256=sha((ROOT/'qualification.json').read_bytes()))
(ROOT/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result)); print(json.dumps({k:report[k] for k in ['source_input_count','library_passed','library_ignored','all_target_reported_ignored_entries','native']}))
