#[path = "workflow_identity665.rs"]
mod workflow_identity665;

#[derive(Clone, Copy)]
pub(crate) enum WorkflowReaderCheckpoint {
    Decision(&'static str),
    Outcome(&'static str),
}
#[derive(prost::Message)]
struct WorkflowSchedulingCheckpoint {
    #[prost(bytes = "vec", tag = "1")]
    response: Vec<u8>,
    #[prost(message, repeated, tag = "2")]
    tasks: Vec<database::Task>,
    #[prost(string, tag = "3")]
    response_type: String,
    #[prost(uint32, tag = "4")]
    version: u32,
}

#[cfg(test)]
fn decode_workflow_checkpoint<R: Message + Default>(
    mutation: &database::IdempotentMutation,
    id: &database::TaskId,
    key: Uuid,
    fingerprint: &[u8],
    response_type: &str,
    iteration: Option<u64>,
) -> Result<R, Status> {
    let any = decode_workflow_checkpoint_envelope(
        mutation,
        id,
        key,
        fingerprint,
        response_type,
        iteration,
    )?;
    if any.type_url != response_type {
        return Err(Status::data_loss("workflow step result type collision"));
    }
    R::decode(any.value.as_slice()).map_err(|_| Status::data_loss("malformed workflow step result"))
}
fn decode_workflow_checkpoint_envelope(
    mutation: &database::IdempotentMutation,
    id: &database::TaskId,
    key: Uuid,
    fingerprint: &[u8],
    response_type: &str,
    iteration: Option<u64>,
) -> Result<prost_types::Any, Status> {
    if mutation.state_type != id.state_type
        || mutation.state_ref != id.state_ref
        || mutation.key != key.as_bytes()
        || mutation.workflow_id.as_deref() != Some(id.task_uuid.as_slice())
        || mutation.workflow_iteration != iteration
        || !mutation.task_ids.is_empty()
        || fingerprint.is_empty()
        || mutation.request_fingerprint.as_deref() != Some(fingerprint)
    {
        return Err(Status::failed_precondition(
            "workflow step checkpoint identity/provenance collision",
        ));
    }
    let any = prost_types::Any::decode(mutation.response.as_slice())
        .map_err(|_| Status::data_loss("malformed workflow step envelope"))?;
    let _ = response_type;
    Ok(any)
}
#[cfg(test)]
mod workflow_checkpoint_tests {
    use super::*;
    #[test]
    fn workflow_typed_checkpoint_rejects_legacy_scope_and_every_identity_collision() {
        let id = database::TaskId {
            state_type: "tests.reboot.protoc.Counter".into(),
            state_ref: "actor".into(),
            task_uuid: Uuid::new_v4().as_bytes().to_vec(),
        };
        let key = Uuid::new_v5(&Uuid::from_slice(&id.task_uuid).unwrap(), b"first");
        let record = database::IdempotentMutation {
            state_type: id.state_type.clone(),
            state_ref: id.state_ref.clone(),
            key: key.as_bytes().to_vec(),
            workflow_id: Some(id.task_uuid.clone()),
            workflow_iteration: None,
            request_fingerprint: Some(vec![1, 2]),
            task_ids: vec![],
            response: prost_types::Any {
                type_url: "type.googleapis.com/Counter".into(),
                value: proto::Counter { value: 7 }.encode_to_vec(),
            }
            .encode_to_vec(),
        };
        assert_eq!(
            decode_workflow_checkpoint::<proto::Counter>(
                &record,
                &id,
                key,
                &[1, 2],
                "type.googleapis.com/Counter",
                None
            )
            .unwrap()
            .value,
            7
        );
        let mut scoped = record.clone();
        scoped.workflow_iteration = Some(0);
        assert_eq!(
            decode_workflow_checkpoint::<proto::Counter>(
                &scoped,
                &id,
                key,
                &[1, 2],
                "type.googleapis.com/Counter",
                Some(0)
            )
            .unwrap()
            .value,
            7
        );
        assert!(
            decode_workflow_checkpoint::<proto::Counter>(
                &scoped,
                &id,
                key,
                &[1, 2],
                "type.googleapis.com/Counter",
                Some(1)
            )
            .is_err()
        );
        assert!(
            decode_workflow_checkpoint::<proto::Counter>(
                &scoped,
                &id,
                key,
                &[1, 2],
                "type.googleapis.com/Counter",
                None
            )
            .is_err()
        );
        for vector in 0..10 {
            let mut bad = record.clone();
            match vector {
                0 => bad.state_type = "other".into(),
                1 => bad.state_ref = "other".into(),
                2 => bad.key = vec![1; 16],
                3 => bad.workflow_id = None,
                4 => bad.workflow_id = Some(vec![1; 16]),
                5 => bad.workflow_iteration = Some(0),
                6 => bad.request_fingerprint = None,
                7 => bad.request_fingerprint = Some(vec![3]),
                8 => bad.task_ids.push(id.clone()),
                _ => bad.response = vec![255],
            }
            assert!(
                decode_workflow_checkpoint::<proto::Counter>(
                    &bad,
                    &id,
                    key,
                    &[1, 2],
                    "type.googleapis.com/Counter",
                    None
                )
                .is_err(),
                "vector {vector}"
            );
        }
        assert!(
            decode_workflow_checkpoint::<proto::Counter>(
                &record,
                &id,
                key,
                &[],
                "type.googleapis.com/Counter",
                None
            )
            .is_err()
        );
        assert!(
            decode_workflow_checkpoint::<proto::Counter>(
                &record,
                &id,
                key,
                &[1, 2],
                "type.googleapis.com/Other",
                None
            )
            .is_err()
        );
    }
    #[test]
    fn explicit_named_key_matches_python_external_helper_not_typed_rpc_manager() {
        let seed = Uuid::parse_str("40000000-0000-4000-8000-000000000001").unwrap();
        assert_eq!(
            Uuid::new_v5(&seed, b"first").to_string(),
            "7e07973c-03ea-5cf8-8d96-1965823f5201"
        );
        assert_eq!(
            Uuid::new_v5(&seed, b"second").to_string(),
            "50ce4053-2412-5835-80c7-d25cab17dced"
        );
        assert_ne!(
            Uuid::new_v5(&seed, b"first"),
            Uuid::new_v5(&seed, b"first (iteration #0)")
        );
    }
}

impl DatabaseActorStore {
    // Caller holds the actor gate and retains dispatcher-minted scope authority.
    // Canonical Store is unconditional: singleton owner + gate is arbitration.
    pub(crate) async fn workflow_at_most_once_load(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        key: Uuid,
        contract: &crate::one_shot_tasks::AtMostOnceUnitContract,
    ) -> Result<Option<crate::one_shot_tasks::AtMostOnceUnitCheckpoint>, Status> {
        use crate::one_shot_tasks::{AT_MOST_ONCE_UNIT_TYPE, AtMostOnceUnitCheckpoint};
        let id = scope
            .task()
            .task_id
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("missing workflow identity"))?;
        let fingerprint = request_fingerprint("reboot.workflow.at-most-once.unit.v1", contract);
        let mut saved = None;
        // Match existing workflow recovery: exact scoped replay first; reject
        // legacy unscoped records before any first Start.
        for scoped in [true, false] {
            if !scoped && saved.is_some() {
                break;
            }
            let mut stream = self
                .database
                .clone()
                .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    idempotency_key: Some(key.as_bytes().to_vec()),
                    workflow_id: scoped.then(|| id.task_uuid.clone()),
                    workflow_iteration: if scoped {
                        scope.checkpoint_iteration()
                    } else {
                        None
                    },
                })
                .await?
                .into_inner();
            scope.validate_scope().await?;
            while let Some(batch) = stream.message().await? {
                scope.validate_scope().await?;
                for mutation in batch.idempotent_mutations {
                    if !scoped || saved.is_some() {
                        return Err(Status::failed_precondition(
                            "duplicate/unscoped at-most-once checkpoint",
                        ));
                    }
                    let any = decode_workflow_checkpoint_envelope(
                        &mutation,
                        id,
                        key,
                        &fingerprint,
                        AT_MOST_ONCE_UNIT_TYPE,
                        scope.checkpoint_iteration(),
                    )?;
                    if any.type_url != AT_MOST_ONCE_UNIT_TYPE {
                        return Err(Status::data_loss("at-most-once checkpoint type collision"));
                    }
                    let checkpoint = AtMostOnceUnitCheckpoint::decode(any.value.as_slice())
                        .map_err(|_| Status::data_loss("malformed at-most-once checkpoint"))?;
                    checkpoint.validate()?;
                    saved = Some(checkpoint);
                }
            }
        }
        scope.validate_scope().await?;
        Ok(saved)
    }
    pub(crate) async fn workflow_at_most_once_save(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        key: Uuid,
        contract: &crate::one_shot_tasks::AtMostOnceUnitContract,
        checkpoint: crate::one_shot_tasks::AtMostOnceUnitCheckpoint,
    ) -> Result<(), Status> {
        use crate::one_shot_tasks::AT_MOST_ONCE_UNIT_TYPE;
        checkpoint.validate()?;
        scope.validate_scope().await?;
        let id = scope
            .task()
            .task_id
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("missing workflow identity"))?;
        let fingerprint = request_fingerprint("reboot.workflow.at-most-once.unit.v1", contract);
        // These guards must drop before the caller's actor lease on unknown ACK.
        let mut operation = scope.durable();
        let commit_attempt = self
            .actor_gate(&id.state_type, &id.state_ref)
            .commit_attempt();
        self.database
            .clone()
            .store(database::StoreRequest {
                actor_upserts: vec![],
                task_upserts: vec![],
                colocated_upserts: vec![],
                transaction: None,
                ensure_state_types_created: vec![],
                sync: true,
                idempotent_mutation: Some(database::IdempotentMutation {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    key: key.as_bytes().to_vec(),
                    response: prost_types::Any {
                        type_url: AT_MOST_ONCE_UNIT_TYPE.into(),
                        value: checkpoint.encode_to_vec(),
                    }
                    .encode_to_vec(),
                    workflow_id: Some(id.task_uuid.clone()),
                    workflow_iteration: scope.checkpoint_iteration(),
                    request_fingerprint: Some(fingerprint),
                    task_ids: vec![],
                }),
            })
            .await?;
        commit_attempt.checkpoint_acknowledged();
        operation.acknowledged();
        Ok(())
    }
    pub(crate) async fn workflow_at_most_once_result_load(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        key: Uuid,
        contract: &crate::one_shot_tasks::AtMostOnceResultContract,
    ) -> Result<Option<crate::one_shot_tasks::AtMostOnceResultCheckpoint>, Status> {
        use crate::one_shot_tasks::{AT_MOST_ONCE_RESULT_TYPE, AtMostOnceResultCheckpoint};
        let id = scope
            .task()
            .task_id
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("missing workflow identity"))?;
        let fingerprint = request_fingerprint("reboot.workflow.at-most-once.result.v1", contract);
        let mut saved = None;
        // Match existing workflow recovery: exact scoped replay first; reject
        // legacy unscoped records before any first Start.
        for scoped in [true, false] {
            if !scoped && saved.is_some() {
                break;
            }
            let mut stream = self
                .database
                .clone()
                .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    idempotency_key: Some(key.as_bytes().to_vec()),
                    workflow_id: scoped.then(|| id.task_uuid.clone()),
                    workflow_iteration: if scoped {
                        scope.checkpoint_iteration()
                    } else {
                        None
                    },
                })
                .await?
                .into_inner();
            scope.validate_scope().await?;
            while let Some(batch) = stream.message().await? {
                scope.validate_scope().await?;
                for mutation in batch.idempotent_mutations {
                    if !scoped || saved.is_some() {
                        return Err(Status::failed_precondition(
                            "duplicate/unscoped at-most-once checkpoint",
                        ));
                    }
                    let any = decode_workflow_checkpoint_envelope(
                        &mutation,
                        id,
                        key,
                        &fingerprint,
                        AT_MOST_ONCE_RESULT_TYPE,
                        scope.checkpoint_iteration(),
                    )?;
                    if any.type_url != AT_MOST_ONCE_RESULT_TYPE {
                        return Err(Status::data_loss("at-most-once checkpoint type collision"));
                    }
                    let checkpoint = AtMostOnceResultCheckpoint::decode(any.value.as_slice())
                        .map_err(|_| Status::data_loss("malformed at-most-once checkpoint"))?;
                    checkpoint.validate()?;
                    if checkpoint.declared_writer_error && !contract.declared_writer_errors {
                        return Err(Status::data_loss("declared error outside outbound writer"));
                    }
                    if checkpoint
                        .result
                        .as_ref()
                        .is_some_and(|r| r.type_url != contract.result_type)
                    {
                        return Err(Status::data_loss("typed result contract mismatch"));
                    }
                    saved = Some(checkpoint);
                }
            }
        }
        scope.validate_scope().await?;
        Ok(saved)
    }
    pub(crate) async fn workflow_at_most_once_result_save(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        key: Uuid,
        contract: &crate::one_shot_tasks::AtMostOnceResultContract,
        checkpoint: crate::one_shot_tasks::AtMostOnceResultCheckpoint,
    ) -> Result<(), Status> {
        use crate::one_shot_tasks::AT_MOST_ONCE_RESULT_TYPE;
        checkpoint.validate()?;
        scope.validate_scope().await?;
        let id = scope
            .task()
            .task_id
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("missing workflow identity"))?;
        let fingerprint = request_fingerprint("reboot.workflow.at-most-once.result.v1", contract);
        // These guards must drop before the caller's actor lease on unknown ACK.
        let mut operation = scope.durable();
        let commit_attempt = self
            .actor_gate(&id.state_type, &id.state_ref)
            .commit_attempt();
        self.database
            .clone()
            .store(database::StoreRequest {
                actor_upserts: vec![],
                task_upserts: vec![],
                colocated_upserts: vec![],
                transaction: None,
                ensure_state_types_created: vec![],
                sync: true,
                idempotent_mutation: Some(database::IdempotentMutation {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    key: key.as_bytes().to_vec(),
                    response: prost_types::Any {
                        type_url: AT_MOST_ONCE_RESULT_TYPE.into(),
                        value: checkpoint.encode_to_vec(),
                    }
                    .encode_to_vec(),
                    workflow_id: Some(id.task_uuid.clone()),
                    workflow_iteration: scope.checkpoint_iteration(),
                    request_fingerprint: Some(fingerprint),
                    task_ids: vec![],
                }),
            })
            .await?;
        commit_attempt.checkpoint_acknowledged();
        operation.acknowledged();
        Ok(())
    }
    pub(crate) async fn workflow_writer_step<D, Q, R, F>(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        (alias, condition): (&str, Option<&str>),
        method: &'static str,
        response_type: &'static str,
        request: Q,
        invoke: F,
    ) -> Result<Option<R>, Status>
    where
        D: DurableStateDeclaration + 'static,
        Q: Message + Default + Send + 'static,
        R: Message + Default + Clone + Send + 'static,
        F: for<'a> FnOnce(
            &'a mut D::State,
            Q,
        )
            -> Pin<Box<dyn Future<Output = Result<Option<R>, Status>> + Send + 'a>>,
    {
        let result = self
            .workflow_step_outcome::<D, Q, R, _>(
                scope,
                (alias, condition, None),
                method,
                response_type,
                request,
                move |state, request| {
                    let future = invoke(state, request);
                    Box::pin(async move { future.await.map(|response| response.map(Ok)) })
                },
            )
            .await?;
        match result {
            Some(Ok(response)) => Ok(Some(response)),
            None => Ok(None),
            Some(Err(_)) => Err(Status::failed_precondition(
                "declared checkpoint requires typed writer step",
            )),
        }
    }
    pub(crate) async fn workflow_reader_decision_step<D, Q, R, F>(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        (alias, condition): (&str, Option<&str>),
        method: &'static str,
        (response_type, reader_response_type): (&'static str, &'static str),
        request: Q,
        invoke: F,
    ) -> Result<Option<R>, Status>
    where
        D: DurableStateDeclaration + 'static,
        Q: Message + Default + Send + 'static,
        R: Message + Default + Clone + Send + 'static,
        F: for<'a> FnOnce(
            &'a mut D::State,
            Q,
        )
            -> Pin<Box<dyn Future<Output = Result<Option<R>, Status>> + Send + 'a>>,
    {
        let result = self
            .workflow_step_outcome::<D, Q, R, _>(
                scope,
                (
                    alias,
                    condition,
                    Some(WorkflowReaderCheckpoint::Decision(reader_response_type)),
                ),
                method,
                response_type,
                request,
                move |state, request| {
                    let future = invoke(state, request);
                    Box::pin(async move { future.await.map(|response| response.map(Ok)) })
                },
            )
            .await?;
        match result {
            Some(Ok(response)) => Ok(Some(response)),
            None => Ok(None),
            Some(Err(_)) => Err(Status::failed_precondition(
                "declared checkpoint requires typed writer step",
            )),
        }
    }
    pub(crate) async fn workflow_reader_outcome_step<D, Q, R, F>(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        (alias, condition): (&str, Option<&str>),
        method: &'static str,
        (response_type, reader_response_type): (&'static str, &'static str),
        request: Q,
        invoke: F,
    ) -> Result<Option<R>, Status>
    where
        D: DurableStateDeclaration + 'static,
        Q: Message + Default + Send + 'static,
        R: Message + Default + Clone + Send + 'static,
        F: for<'a> FnOnce(
            &'a mut D::State,
            Q,
        )
            -> Pin<Box<dyn Future<Output = Result<Option<R>, Status>> + Send + 'a>>,
    {
        let result = self
            .workflow_step_outcome::<D, Q, R, _>(
                scope,
                (
                    alias,
                    condition,
                    Some(WorkflowReaderCheckpoint::Outcome(reader_response_type)),
                ),
                method,
                response_type,
                request,
                move |state, request| {
                    let future = invoke(state, request);
                    Box::pin(async move { future.await.map(|response| response.map(Ok)) })
                },
            )
            .await?;
        match result {
            Some(Ok(response)) => Ok(Some(response)),
            None => Ok(None),
            Some(Err(_)) => Err(Status::failed_precondition(
                "declared checkpoint requires typed writer step",
            )),
        }
    }
    pub(crate) async fn workflow_step_outcome<D, Q, R, F>(
        &self,
        scope: &crate::one_shot_tasks::WorkflowContext<'_>,
        (alias, condition, decision_reader_response_type): (
            &str,
            Option<&str>,
            Option<WorkflowReaderCheckpoint>,
        ),
        method: &'static str,
        response_type: &'static str,
        request: Q,
        invoke: F,
    ) -> Result<Option<Result<R, prost_types::Any>>, Status>
    where
        D: DurableStateDeclaration + 'static,
        Q: Message + Default + Send + 'static,
        R: Message + Default + Clone + Send + 'static,
        F: for<'a> FnOnce(
            &'a mut D::State,
            Q,
        ) -> Pin<
            Box<
                dyn Future<Output = Result<Option<Result<R, prost_types::Any>>, Status>>
                    + Send
                    + 'a,
            >,
        >,
    {
        let task = scope.task();
        let id = task
            .task_id
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("missing workflow task"))?;
        let seed = Uuid::from_slice(&id.task_uuid)
            .map_err(|_| Status::failed_precondition("invalid workflow UUID"))?;
        let iteration = scope.checkpoint_iteration();
        let scoped_alias = scope.checkpoint_alias(alias);
        let key = match decision_reader_response_type {
            Some(WorkflowReaderCheckpoint::Decision(_)) => {
                scope.checkpoint_decision_key(seed, alias)
            }
            Some(WorkflowReaderCheckpoint::Outcome(_)) => {
                scope.checkpoint_reader_outcome_key(seed, alias)
            }
            None => scope.checkpoint_key(seed, alias, condition),
        };
        // Pin workflow method/request, alias, writer method, response type and
        // canonical writer request. No legacy/incomplete record is accepted.
        let mut identity = format!(
            "reboot.workflow.named-step.v1:{}:{}:{}:{}:{}",
            task.method,
            task.request
                .iter()
                .map(|b| format!("{b:02x}"))
                .collect::<String>(),
            scoped_alias,
            method,
            response_type
        );
        if scope.checkpoint_iteration().is_some() {
            identity.push_str(&format!(":finite-bound={}", scope.checkpoint_bound()));
            let parents = scope.checkpoint_parent_bounds();
            if !parents.is_empty() {
                identity.push_str(&format!(":parent-bounds={parents}"));
            }
        }
        if let Some(condition) = condition {
            identity.push_str(&format!(
                ":wait-condition={}:{}",
                condition.len(),
                condition
            ));
        }
        if let Some(mode) = decision_reader_response_type {
            let (kind, reader_response_type) = match mode {
                WorkflowReaderCheckpoint::Decision(url) => ("decision-kind=finite.v1", url),
                WorkflowReaderCheckpoint::Outcome(url) => ("reader-outcome=declared.v1", url),
            };
            identity.push_str(&format!(
                ":{kind}:reader-response={}:{}",
                reader_response_type.len(),
                reader_response_type
            ));
        }
        let fingerprint = request_fingerprint(&identity, &request);
        let mut stream = self
            .database
            .clone()
            .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                state_type: id.state_type.clone(),
                state_ref: id.state_ref.clone(),
                idempotency_key: Some(key.as_bytes().to_vec()),
                workflow_id: Some(id.task_uuid.clone()),
                workflow_iteration: iteration,
            })
            .await?
            .into_inner();
        scope.validate_scope().await?;
        let mut saved = None;
        while let Some(batch) = stream.message().await? {
            scope.validate_scope().await?;
            for mutation in batch.idempotent_mutations {
                if saved.is_some() {
                    return Err(Status::failed_precondition(
                        "duplicate workflow step checkpoint",
                    ));
                }
                let any = decode_workflow_checkpoint_envelope(
                    &mutation,
                    id,
                    key,
                    &fingerprint,
                    response_type,
                    iteration,
                )?;
                if let Some(WorkflowReaderCheckpoint::Outcome(url)) = decision_reader_response_type
                {
                    scope.validate_reader_outcome(method, url, &any.value)?;
                }
                saved = Some(if any.type_url == response_type {
                    Ok(R::decode(any.value.as_slice())
                        .map_err(|_| Status::data_loss("malformed workflow step result"))?)
                } else {
                    if condition.is_some() {
                        return Err(Status::data_loss(
                            "reader checkpoint cannot contain declared error",
                        ));
                    }
                    scope.validate_writer_step_error(method, &any)?;
                    Err(any)
                });
            }
        }
        scope.validate_scope().await?;
        if let Some(saved) = saved {
            return Ok(Some(saved));
        }
        let mut legacy = self
            .database
            .clone()
            .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                state_type: id.state_type.clone(),
                state_ref: id.state_ref.clone(),
                idempotency_key: Some(key.as_bytes().to_vec()),
                workflow_id: None,
                workflow_iteration: None,
            })
            .await?
            .into_inner();
        scope.validate_scope().await?;
        while let Some(batch) = legacy.message().await? {
            scope.validate_scope().await?;
            if !batch.idempotent_mutations.is_empty() {
                return Err(Status::failed_precondition(
                    "legacy unscoped workflow checkpoint",
                ));
            }
        }
        scope.validate_scope().await?;
        let mut state = self
            .load_for_declaration::<D>(&id.state_ref)
            .await?
            .ok_or_else(|| Status::failed_precondition("workflow requires existing actor"))?;
        scope.validate_scope().await?;
        let Some(response) = invoke(&mut state, request).await? else {
            return Ok(None);
        };
        scope.validate_scope().await?;
        if condition.is_some()
            && response
                .as_ref()
                .map(|value| value.encoded_len())
                .unwrap_or(0)
                > 1048576
        {
            return Err(Status::resource_exhausted(
                "workflow wait snapshot exceeds 1MiB",
            ));
        }
        if let Err(error) = &response {
            if condition.is_some() {
                return Err(Status::failed_precondition(
                    "reader cannot save declared writer error",
                ));
            }
            scope.validate_writer_step_error(method, error)?;
        }
        let rejected = response.is_err();
        let saved_response = match &response {
            Ok(response) => prost_types::Any {
                type_url: response_type.to_owned(),
                value: response.encode_to_vec(),
            },
            Err(error) => error.clone(),
        };
        if let Some(WorkflowReaderCheckpoint::Outcome(url)) = decision_reader_response_type {
            scope.validate_reader_outcome(method, url, &saved_response.value)?;
        }
        let mut operation = scope.durable();
        let commit_attempt = self
            .actor_gate(&id.state_type, &id.state_ref)
            .commit_attempt();
        self.database
            .clone()
            .store(database::StoreRequest {
                actor_upserts: if condition.is_some() || rejected {
                    vec![]
                } else {
                    vec![database::Actor {
                        state_type: id.state_type.clone(),
                        state_ref: id.state_ref.clone(),
                        state: Some(state.encode_to_vec()),
                    }]
                },
                idempotent_mutation: Some(database::IdempotentMutation {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    key: key.as_bytes().to_vec(),
                    response: saved_response.encode_to_vec(),
                    workflow_id: Some(id.task_uuid.clone()),
                    workflow_iteration: iteration,
                    request_fingerprint: Some(fingerprint),
                    task_ids: vec![],
                }),
                task_upserts: vec![],
                colocated_upserts: vec![],
                transaction: None,
                ensure_state_types_created: vec![],
                sync: true,
            })
            .await?;
        if condition.is_some() || rejected {
            commit_attempt.checkpoint_acknowledged();
        } else {
            commit_attempt.acknowledged();
        }
        scope.validate_scope().await?;
        operation.acknowledged();
        Ok(Some(response))
    }
    /// Ordinary generated writer plus atomic durable scheduling. Host owner and
    /// canonical actor identity are mandatory; scheduling never calls task RPCs.
    pub async fn workflow_scheduling_writer<D, Q, R, F>(
        &self,
        method: &str,
        authorization: &crate::auth::AuthorizationPolicy,
        owner: Option<&crate::one_shot_tasks::OneShotTasks>,
        request: Request<Q>,
        invoke: F,
    ) -> Result<Response<R>, Status>
    where
        D: DurableStateDeclaration + 'static,
        Q: Message + Send + 'static,
        R: Message + Default + Clone + Send + 'static,
        F: for<'a> FnOnce(
            &'a mut D::State,
            Q,
            String,
        ) -> Pin<
            Box<dyn Future<Output = Result<TransactionExecution<R>, Status>> + Send + 'a>,
        >,
    {
        let (auth_context, auth) = authorization
            .verify(
                crate::RebootHeaders::from_request(&request)
                    .map_err(|e| Status::invalid_argument(e.to_string()))?,
                D::STATE_TYPE,
                method,
            )
            .await?;
        authorization.require_authorizer()?;
        let state_ref = required_metadata(&request, STATE_REF_HEADER)?;
        let key = idempotency_key(&request)?;
        let fingerprint = request_fingerprint(method, request.get_ref());
        let owner = owner.ok_or_else(|| {
            Status::failed_precondition("scheduling requires registered workflow owner")
        })?;
        owner.validate_scheduling_store(self, D::STATE_TYPE, &state_ref)?;
        owner.validate_workflow_writer::<D, Q, R>(method)?;
        let running = owner.workflow_running_admission()?;
        let gate = self.actor_gate(D::STATE_TYPE, &state_ref);
        let _lease = gate.exclusive().await;
        if gate.committed_revisions().borrow().1 {
            return Err(Status::unavailable(
                "actor commit outcome uncertain; restart host before writing",
            ));
        }
        {
            let _owner = running.lock()?;
        }
        // A durable receipt is not an authorization grant. Recheck policy
        // against canonical current state before inspecting or returning replay.
        let snapshot = self
            .load_state_bytes(D::STATE_TYPE, &state_ref)
            .await
            .map_err(|error| {
                if error.code() == tonic::Code::Unavailable {
                    Status::unavailable("authorization state unavailable")
                } else {
                    Status::permission_denied("authorization state unavailable")
                }
            })?;
        {
            let _owner = running.lock()?;
        }
        authorization
            .authorize(
                &auth_context,
                auth.as_ref(),
                snapshot.as_deref(),
                &request.get_ref().encode_to_vec(),
            )
            .await?;
        {
            let _owner = running.lock()?;
        }
        let mut state = D::State::decode(snapshot.as_deref().ok_or_else(|| {
            Status::failed_precondition("scheduling writer requires existing actor")
        })?)
        .map_err(|_| Status::failed_precondition("invalid scheduling actor state"))?;
        let mut stream = self
            .database
            .clone()
            .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                state_type: D::STATE_TYPE.to_owned(),
                state_ref: state_ref.clone(),
                idempotency_key: Some(key.as_bytes().to_vec()),
                workflow_id: None,
                workflow_iteration: None,
            })
            .await?
            .into_inner();
        {
            let _owner = running.lock()?;
        }
        let mut replay = None;
        while let Some(batch) = stream.message().await? {
            {
                let _owner = running.lock()?;
            }
            for mutation in batch.idempotent_mutations {
                if replay.is_some()
                    || mutation.state_type != D::STATE_TYPE
                    || mutation.state_ref != state_ref
                    || mutation.key != key.as_bytes()
                    || mutation.workflow_id.is_some()
                    || mutation.workflow_iteration.is_some()
                    || mutation.request_fingerprint.as_deref() != Some(fingerprint.as_slice())
                {
                    return Err(Status::failed_precondition(
                        "scheduling key method/payload collision",
                    ));
                }
                let checkpoint = WorkflowSchedulingCheckpoint::decode(mutation.response.as_slice())
                    .map_err(|_| Status::data_loss("invalid scheduling checkpoint"))?;
                if checkpoint.version != 1
                    || checkpoint.response_type != owner.workflow_writer_response_type(method)?
                    || checkpoint
                        .tasks
                        .iter()
                        .filter_map(|t| t.task_id.clone())
                        .collect::<Vec<_>>()
                        != mutation.task_ids
                {
                    return Err(Status::failed_precondition(
                        "incomplete scheduling replay metadata",
                    ));
                }
                {
                    let _owner = running.lock()?;
                }
                // Positive canonical identity reads include Completed tasks that
                // Recover.pending_tasks cannot enumerate. The surrounding actor
                // owner is rechecked after this await; this is not adoption or
                // an absence certificate for a provisional identity.
                let loaded = if mutation.task_ids.is_empty() {
                    Vec::new()
                } else {
                    self.load_existing_workflow_tasks(&mutation.task_ids)
                        .await?
                };
                {
                    let _owner = running.lock()?;
                }
                for task in &loaded {
                    if let Some((alias, version)) = owner.cursor_declaration(task) {
                        self.workflow_validate_cursor_binding(
                            task,
                            alias,
                            version,
                            owner
                                .declaration(task)
                                .expect("cursor declaration")
                                .full_method(),
                        )
                        .await?;
                        let _owner = running.lock()?;
                    }
                }
                owner.validate_scheduling_replay(&checkpoint.tasks, &loaded)?;
                replay = Some(
                    R::decode(checkpoint.response.as_slice())
                        .map_err(|_| Status::data_loss("invalid scheduling result"))?,
                );
            }
        }
        {
            let _owner = running.lock()?;
        }
        if let Some(response) = replay {
            return Ok(Response::new(response));
        }
        let execution = invoke(&mut state, request.into_inner(), state_ref.clone()).await?;
        {
            let _owner = running.lock()?;
        }
        if execution.final_state.is_some() || !execution.idempotent_mutations.is_empty() {
            return Err(Status::failed_precondition(
                "workflow scheduling writer supports only local state and tasks",
            ));
        }
        let admission = owner
            .validate_staged_admission(&execution.task_upserts)
            .await?;
        let mut handoff = owner.own_root_handoff();
        {
            let _owner = running.lock()?;
        }
        {
            let _owner = admission.lock()?;
        }
        let commit_attempt = self.actor_gate(D::STATE_TYPE, &state_ref).commit_attempt();
        self.database
            .clone()
            .store(database::StoreRequest {
                actor_upserts: vec![database::Actor {
                    state_type: D::STATE_TYPE.to_owned(),
                    state_ref: state_ref.clone(),
                    state: Some(state.encode_to_vec()),
                }],
                idempotent_mutation: Some(database::IdempotentMutation {
                    state_type: D::STATE_TYPE.to_owned(),
                    state_ref: state_ref.clone(),
                    key: key.as_bytes().to_vec(),
                    response: WorkflowSchedulingCheckpoint {
                        version: 1,
                        response: execution.response.encode_to_vec(),
                        tasks: execution.task_upserts.clone(),
                        response_type: owner.workflow_writer_response_type(method)?.to_owned(),
                    }
                    .encode_to_vec(),
                    task_ids: execution
                        .task_upserts
                        .iter()
                        .filter_map(|t| t.task_id.clone())
                        .collect(),
                    workflow_id: None,
                    workflow_iteration: None,
                    request_fingerprint: Some(fingerprint),
                }),
                task_upserts: execution.task_upserts.clone(),
                colocated_upserts: vec![],
                transaction: None,
                ensure_state_types_created: vec![],
                sync: true,
            })
            .await?;
        commit_attempt.acknowledged();
        {
            let _owner = admission.lock()?;
        }
        {
            let _owner = running.lock()?;
        }
        handoff.completed();
        owner.dispatch_committed(execution.task_upserts);
        Ok(Response::new(execution.response))
    }
}

impl DatabaseActorStore {
    // Recovery and Wait have no dispatcher-minted WorkflowContext. Validate the
    // same immutable root binding directly, without acquiring dispatch authority.
    pub(crate) async fn workflow_validate_cursor_binding(
        &self,
        task: &database::Task,
        alias: &str,
        version: u32,
        method: &str,
    ) -> Result<(), Status> {
        use crate::one_shot_tasks::{
            AT_MOST_ONCE_RESULT_TYPE, AtMostOnceResultCheckpoint, AtMostOnceResultContract,
        };
        let id = task
            .task_id
            .as_ref()
            .ok_or_else(|| Status::data_loss("cursor missing task ID"))?;
        if alias.is_empty()
            || alias.len() > 256
            || alias.chars().any(char::is_control)
            || version == 0
        {
            return Err(Status::failed_precondition(
                "invalid immutable cursor declaration",
            ));
        }
        let seed = Uuid::from_slice(&id.task_uuid)
            .map_err(|_| Status::data_loss("cursor invalid UUID"))?;
        let key = Uuid::new_v5(&seed, b"reboot.workflow.cursor.binding.v1");
        let contract = AtMostOnceResultContract {
            declared_writer_errors: false,
            method: method.into(),
            request: task.request.clone(),
            alias: alias.into(),
            version,
            bound: 0,
            parent_bounds: String::new(),
            result_type: "type.googleapis.com/reboot.rust.workflow.CursorBindingV1".into(),
            call_contract: b"reboot.workflow.cursor.v1".to_vec(),
        };
        let fingerprint = request_fingerprint("reboot.workflow.at-most-once.result.v1", &contract);
        let mut count = 0;
        for scoped in [true, false] {
            if !scoped && count != 0 {
                break;
            }
            let mut stream = self
                .database
                .clone()
                .recover_idempotent_mutations(database::RecoverIdempotentMutationsRequest {
                    state_type: id.state_type.clone(),
                    state_ref: id.state_ref.clone(),
                    idempotency_key: Some(key.as_bytes().to_vec()),
                    workflow_id: scoped.then(|| id.task_uuid.clone()),
                    workflow_iteration: None,
                })
                .await?
                .into_inner();
            while let Some(batch) = stream.message().await? {
                for mutation in batch.idempotent_mutations {
                    if !scoped || count != 0 {
                        return Err(Status::failed_precondition(
                            "duplicate or legacy cursor binding",
                        ));
                    }
                    let any = decode_workflow_checkpoint_envelope(
                        &mutation,
                        id,
                        key,
                        &fingerprint,
                        AT_MOST_ONCE_RESULT_TYPE,
                        None,
                    )?;
                    if any.type_url != AT_MOST_ONCE_RESULT_TYPE {
                        return Err(Status::data_loss("cursor binding envelope type"));
                    }
                    let saved = AtMostOnceResultCheckpoint::decode(any.value.as_slice())
                        .map_err(|_| Status::data_loss("malformed cursor binding"))?;
                    saved.validate()?;
                    if saved.phase != 2
                        || saved.result.as_ref().is_none_or(|r| {
                            r.type_url != contract.result_type
                                || r.value != contract.encode_to_vec()
                        })
                    {
                        return Err(Status::failed_precondition("cursor binding changed"));
                    }
                    count += 1;
                }
            }
        }
        if count == 0 && task.iteration != 0 {
            return Err(Status::failed_precondition(
                "nonzero cursor has no durable binding",
            ));
        }
        Ok(())
    }
}
