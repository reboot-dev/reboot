import enum
import math
import os
import rbt.v1alpha1.database_pb2 as database_pb2
import reboot.portless
from dataclasses import dataclass
from envoy.config.cluster.v3 import circuit_breaker_pb2, cluster_pb2
from envoy.config.core.v3 import address_pb2, base_pb2, protocol_pb2
from envoy.config.endpoint.v3 import endpoint_components_pb2, endpoint_pb2
from envoy.config.listener.v3 import listener_components_pb2, listener_pb2
from envoy.config.route.v3 import route_components_pb2, route_pb2
from envoy.extensions.filters.http.cors.v3 import cors_pb2
from envoy.extensions.filters.http.grpc_json_transcoder.v3 import (
    transcoder_pb2,
)
from envoy.extensions.filters.http.lua.v3 import lua_pb2
from envoy.extensions.filters.http.router.v3 import router_pb2
from envoy.extensions.filters.network.http_connection_manager.v3 import (
    http_connection_manager_pb2,
)
from envoy.extensions.transport_sockets.tls.v3 import common_pb2, tls_pb2
from envoy.extensions.upstreams.http.v3 import http_protocol_options_pb2
from envoy.type.matcher.v3 import regex_pb2, string_pb2
from google.protobuf import any_pb2, struct_pb2
from google.protobuf.descriptor_pb2 import FileDescriptorSet
from google.protobuf.duration_pb2 import Duration
from google.protobuf.message import Message
from google.protobuf.wrappers_pb2 import BoolValue, UInt32Value
from pathlib import Path
from reboot.aio.auth.allowed_origins import DEV_ORIGIN_REGEXES
from reboot.aio.headers import CALLER_ID_HEADER, SERVER_ID_HEADER
from reboot.aio.types import ApplicationId, ServerId
from reboot.helpers import get_path_prefixes_from_file_descriptor_set
from reboot.portless import proxy_port
from reboot.routing.cors_settings import (
    CORS_ALLOW_HEADERS,
    CORS_ALLOW_METHODS,
    CORS_EXPOSE_HEADERS,
    CORS_MAX_AGE_SECONDS,
)
from reboot.routing.filters.lua import (
    ADD_HEADER_X_REBOOT_APPLICATION_ID_TEMPLATE_FILENAME,
    COMPUTE_HEADER_X_REBOOT_SERVER_ID_TEMPLATE_FILENAME,
    MANGLED_HTTP_PATH_FILENAME,
    REMOVE_JSON_TRAILERS_FILENAME,
    load_lua,
    render_lua_template,
)
from reboot.run_environments import is_in_test, on_cloud, running_rbt_dev
from reboot.settings import (
    ENVOY_PER_CONNECTION_BUFFER_LIMIT_BYTES,
    ENVVAR_RBT_DEV,
    ENVVAR_RBT_FRONTEND_URL,
    ENVVAR_RBT_WEB_APP,
    EVERY_LOCAL_NETWORK_ADDRESS,
    LocalEnvoyMode,
)
from typing import Optional
from urllib.parse import urlparse


@dataclass
class ServerAddress:
    host: str
    grpc_port: int
    websocket_port: int
    http_port: int


@dataclass
class ServerInfo:
    server_id: ServerId
    address: ServerAddress
    shards: list[database_pb2.ShardInfo]
    # Whether this server is running on the local replica.
    on_this_replica: bool


class ClusterKind(enum.Enum):
    GRPC = enum.auto()
    WEBSOCKET = enum.auto()
    HTTP = enum.auto()


ZERO_SECONDS = Duration()
ZERO_SECONDS.FromSeconds(0)

# Frontend routing configuration.
FRONTEND_CLUSTER_NAME = "frontend"


@dataclass
class FrontendConfig:
    """Configuration for frontend host routing."""
    host: str
    port: int
    original_url: str
    # Whether the dev server also serves the web app (`--web-app`):
    # `/`, and every path the application doesn't answer, goes to it.
    web_app: bool
    # Whether to reach it over TLS (an `https://` host), which is how
    # a dev server behind the portless proxy, `https://<name>.localhost`,
    # is reached.
    tls: bool


def _get_frontend_config() -> FrontendConfig | None:
    """Get frontend host configuration from environment.

    Parses `RBT_FRONTEND_URL` (e.g., "http://localhost:5173", or
    "https://frontend.<name>.localhost" under `--portless`): the dev server
    serving the MCP Apps, the web app, or both, which Envoy routes
    `/__/frontend/**` to.

    Returns None if not configured or not in dev mode.
    """
    if os.environ.get(ENVVAR_RBT_DEV) != "true":
        return None
    frontend_url = os.environ.get(ENVVAR_RBT_FRONTEND_URL)
    if not frontend_url:
        return None

    parsed = urlparse(frontend_url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            "The frontend dev server must be an http:// or https:// "
            f"URL; got '{frontend_url}'"
        )
    if not parsed.hostname:
        raise ValueError(
            f"RBT_FRONTEND_URL must include a hostname; got '{frontend_url}'"
        )
    tls = parsed.scheme == "https"
    default_port = (proxy_port() if tls else 80)
    return FrontendConfig(
        host=parsed.hostname,
        port=parsed.port or default_port,
        original_url=frontend_url,
        web_app=os.environ.get(ENVVAR_RBT_WEB_APP) == "true",
        tls=tls,
    )


# Helper for packing an `Any`.
#
# TODO: replace with `from google.protobuf.any import pack` once we've
# upgraded to a version of protobuf that includes this.
def any_pack(message: Message) -> any_pb2.Any:
    any = any_pb2.Any()
    any.Pack(message)
    return any


def _shard_keyrange_starts(num_shards: int) -> list[int]:
    NUM_BYTE_VALUES = 256
    if num_shards > NUM_BYTE_VALUES:
        raise ValueError(
            f"'num_shards' must be less than or equal to "
            f"{NUM_BYTE_VALUES}; got {num_shards}."
        )
    if not math.log2(num_shards).is_integer():
        raise ValueError(
            f"'num_shards' must be a power of 2; got {num_shards}."
        )
    shard_size = NUM_BYTE_VALUES // num_shards
    # The first shard always begins at the very beginning of the key range.
    return [i * shard_size for i in range(0, num_shards)]


# Prepended to every Lua filter to turn off LuaJIT's compiler on macOS.
# On Apple Silicon LuaJIT often fails to allocate machine code memory
# within branch range of its interpreter. Every failure flushes all
# compiled traces and raises an error that the macOS unwinder handles
# ~200x slower than Linux's. The resulting retry loop pins Envoy's
# workers for minutes after each start, until they miss HTTP/2
# keepalives. Interpreted, the filters cost tens of microseconds per
# request.
#
# TODO: remove this once Envoy bundles a LuaJIT that includes commit
# 68354f4447 ("Allow mcode allocations outside of the jump range to the
# support code"), which lifts the branch range requirement.
_LUA_JIT_OFF_ON_MACOS = 'if jit and jit.os == "OSX" then jit.off() end\n'


def _lua_any(source_code: str) -> any_pb2.Any:
    return any_pack(
        lua_pb2.Lua(
            default_source_code=base_pb2.DataSource(
                inline_string=_LUA_JIT_OFF_ON_MACOS + source_code,
            ),
        )
    )


# The canonical CORS policy values from `cors_settings`, formatted
# the way Envoy's `CorsPolicy` proto wants them: comma-joined
# strings.
_CORS_ALLOW_METHODS = ", ".join(CORS_ALLOW_METHODS)
_CORS_ALLOW_HEADERS = ",".join(CORS_ALLOW_HEADERS)
_CORS_EXPOSE_HEADERS = ",".join(CORS_EXPOSE_HEADERS)
_CORS_MAX_AGE = str(CORS_MAX_AGE_SECONDS)


def _cors_origin_matchers(
    allowed_origins: list[str],
) -> list[string_pb2.StringMatcher]:
    """Build the CORS `allow_origin_string_match` list — every entry
    in `allowed_origins` as an exact match, plus (under `rbt dev run`
    or in tests) the shared local-development origin regexes, so a
    normal `vite`/`webpack` workflow works without the developer
    enumerating every Vite-defaulted port (5173, 5174, …) in
    `Application(allowed_origins=...)`. Production and Reboot Cloud
    apply the exact-match allow-list verbatim.
    """
    # Exact-match only — never a wildcard — because this list is paired
    # with `Access-Control-Allow-Credentials: true`. A signed-in user's
    # browser attaches the Reboot session cookie automatically, and the
    # SPA can read its access JWT from `/__/oauth/whoami`; so if the
    # CORS policy advertised credentials alongside an open
    # `Access-Control-Allow-Origin` (the natural "just make it work"
    # default, `regex=".*"`), any third-party site the signed-in user
    # visits could:
    #
    #     const r = await fetch(".../__/oauth/whoami",
    #                           { credentials: "include" });
    #     const { access_token } = await r.json();  // portable bearer
    #
    # and replay that bearer against `/__/oauth/refresh` and the unary
    # `/__/reboot/rpc/*` path until it expires. Browsers only ship
    # credentials cross-origin when the response echoes a specific
    # allow-listed origin (not `*`, nor an echoed origin under a
    # permissive policy), so restricting the echoed set to exactly
    # `allowed_origins` is what closes the hole.
    matchers = [
        string_pb2.StringMatcher(exact=origin) for origin in allowed_origins
    ]
    if running_rbt_dev() or is_in_test():
        # RE2 syntax. Envoy's `SafeRegex` matches against the whole
        # origin string (a full-string match, not a substring search).
        matchers.extend(
            string_pb2.StringMatcher(
                safe_regex=regex_pb2.RegexMatcher(regex=regex),
            ) for regex in DEV_ORIGIN_REGEXES
        )
    return matchers


def _cors_policy(
    allowed_origins: Optional[list[str]],
) -> route_components_pb2.CorsPolicy:
    """The route's CORS policy. `None` means the application has no
    credentialed browser traffic to protect (neither `oauth=` nor
    `allowed_origins`), and any origin may call — MCP sandboxes, for
    example, can show up with arbitrary origins. A list (possibly
    empty) means credentialed cross-origin browser traffic is
    restricted to the exact-match allow-list; `allow_credentials`
    is paired with exact-match origins, never a wildcard.
    """
    if allowed_origins is None:
        return route_components_pb2.CorsPolicy(
            allow_origin_string_match=[
                string_pb2.StringMatcher(
                    safe_regex=regex_pb2.RegexMatcher(
                        # The correct incantation for Envoy is `".*"`,
                        # not `"*"` (which only matches a literal
                        # star).
                        google_re2=regex_pb2.RegexMatcher.GoogleRE2(),
                        regex=".*",
                    ),
                )
            ],
            allow_methods=_CORS_ALLOW_METHODS,
            allow_headers=_CORS_ALLOW_HEADERS,
            max_age=_CORS_MAX_AGE,
            expose_headers=_CORS_EXPOSE_HEADERS,
        )
    return route_components_pb2.CorsPolicy(
        allow_credentials=BoolValue(value=True),
        allow_origin_string_match=_cors_origin_matchers(allowed_origins),
        allow_methods=_CORS_ALLOW_METHODS,
        allow_headers=_CORS_ALLOW_HEADERS,
        max_age=_CORS_MAX_AGE,
        expose_headers=_CORS_EXPOSE_HEADERS,
    )


def _http_filter_add_header_x_reboot_application_id(
    application_id: ApplicationId
) -> http_connection_manager_pb2.HttpFilter:
    template_input = {
        'application_id': application_id,
    }
    filter_content = render_lua_template(
        ADD_HEADER_X_REBOOT_APPLICATION_ID_TEMPLATE_FILENAME, template_input
    )

    return http_connection_manager_pb2.HttpFilter(
        name="reboot.add_header_x_reboot_application_id",
        # TODO(rjh): can we replace this with a standard add-header filter?
        typed_config=_lua_any(filter_content)
    )


@dataclass
class RouteMapEntry:
    # The start of this shard's key range. Conceptually this represents several
    # `byte`s, but it's encoded as a Lua-safe string literal with escape
    # characters (e.g. "\x41\x00").
    shard_keyrange_start: str
    # The server ID that traffic matching this entry should get sent to.
    server_id: ServerId

    @classmethod
    def from_key_bytes(cls, first_key_bytes: bytes, server_id: str):
        lua_escaped_bytes = ''.join(f'\\x{b:02x}' for b in first_key_bytes)
        return cls(
            shard_keyrange_start=lua_escaped_bytes,
            server_id=server_id,
        )


def _http_filter_compute_header_x_reboot_server_id(
    servers: list[ServerInfo],
) -> http_connection_manager_pb2.HttpFilter:
    # We must give Lua the list of all of the shards sorted by their
    # first key, for ~efficient lookup.
    all_shards: list[database_pb2.ShardInfo] = [
        shard for server in servers for shard in server.shards
    ]
    all_shards.sort(key=lambda shard: shard.shard_first_key)

    server_id_by_shard_id = {
        shard.shard_id: server.server_id for server in servers
        for shard in server.shards
    }

    route_map = [
        RouteMapEntry.from_key_bytes(
            first_key_bytes=shard.shard_first_key,
            server_id=server_id_by_shard_id[shard.shard_id],
        ) for shard in all_shards
    ]

    server_ids = [server.server_id for server in servers]

    this_replica_server_ids = [
        server.server_id for server in servers if server.on_this_replica
    ]

    template_input = {
        'server_ids': server_ids,
        'this_replica_server_ids': this_replica_server_ids,
        'route_map': route_map,
    }
    filter_content = render_lua_template(
        COMPUTE_HEADER_X_REBOOT_SERVER_ID_TEMPLATE_FILENAME, template_input
    )
    return http_connection_manager_pb2.HttpFilter(
        name="reboot.compute_header_x_reboot_server_id",
        typed_config=_lua_any(filter_content),
    )


def _http_filter_mangled_http_path() -> http_connection_manager_pb2.HttpFilter:
    # The contents of the MANGLED_HTTP_PATH_FILENAME Lua file need to still be
    # wrapped in an `envoy_on_request` function, since `routing_filter.lua.j2`
    # also uses the same content.
    filter_content = (
        "function envoy_on_request(request_handle)\n"
        f"{load_lua(MANGLED_HTTP_PATH_FILENAME)}\n"
        "end\n"
    )
    return http_connection_manager_pb2.HttpFilter(
        name="reboot.mangled_http_path",
        typed_config=_lua_any(filter_content),
    )


def _http_filter_remove_json_trailers(
) -> http_connection_manager_pb2.HttpFilter:
    filter_content = load_lua(REMOVE_JSON_TRAILERS_FILENAME)
    return http_connection_manager_pb2.HttpFilter(
        name="reboot.remove_json_trailers",
        typed_config=_lua_any(filter_content),
    )


def _http_filter_cors() -> http_connection_manager_pb2.HttpFilter:
    # TODO(rjh): set the `cors` policy here, instead of in `VirtualHost`; the
    #            latter is deprecated. Share code with `network_managers.py`.
    return http_connection_manager_pb2.HttpFilter(
        name="envoy.filters.http.cors",
        typed_config=any_pack(cors_pb2.Cors()),
    )


GRPC_JSON_TRANSCODER_HTTP_FILTER_NAME = "envoy.filters.http.grpc_json_transcoder"

# For those routes where we don't need the transcoding filter we have
# an empty configuration so it never activates (without this it has
# been shown to confuse the traffic).
EMPTY_GRPC_JSON_TRANSCODER_CONFIG = any_pack(
    transcoder_pb2.GrpcJsonTranscoder(
        # This field's presence is required (the listener will be rejected
        # without it), but we can leave it empty.
        proto_descriptor_bin=b"",
    )
)


def _http_filter_grpc_json_transcoder(
    file_descriptor_set: FileDescriptorSet,
) -> http_connection_manager_pb2.HttpFilter:
    return http_connection_manager_pb2.HttpFilter(
        name=GRPC_JSON_TRANSCODER_HTTP_FILTER_NAME,
        typed_config=any_pack(
            # ATTENTION: if you update any of this, also update the matching
            #            values in `envoy_filter_generator.py` method
            #            `generate_transcoding_filter`.
            # TODO(rjh): either obsolete `generate_transcoding_filter`,
            #            or use it, or share settings at least.
            transcoder_pb2.GrpcJsonTranscoder(
                convert_grpc_status=True,
                print_options=transcoder_pb2.GrpcJsonTranscoder.PrintOptions(
                    add_whitespace=True,
                    always_print_enums_as_ints=False,
                    always_print_primitive_fields=True,
                    preserve_proto_field_names=False,
                ),
                # The gRPC backend would be unhappy to receive
                # non-gRPC `application/json` traffic and would reply
                # with a `503`, which is not a good user experience
                # and not helpful in debugging. In addition, we've
                # observed that that interaction between Envoy and
                # gRPC triggers a bug in one of those two that will
                # cause subsequent valid requests to fail.
                #
                # See: https://github.com/reboot-dev/mono/issues/3074.
                #
                # Instead, simply (correctly) reject invalid
                # `application/json` traffic with a 404.
                request_validation_options=(
                    transcoder_pb2.GrpcJsonTranscoder.RequestValidationOptions(
                        reject_unknown_method=True,
                    )
                ),
                services=[
                    f"{file_descriptor_proto.package}.{service.name}"
                    for file_descriptor_proto in file_descriptor_set.file
                    for service in file_descriptor_proto.service
                ],
                proto_descriptor_bin=file_descriptor_set.SerializeToString(),
            )
        )
    )


def _http_filter_router() -> http_connection_manager_pb2.HttpFilter:
    return http_connection_manager_pb2.HttpFilter(
        name="envoy.filters.http.router",
        typed_config=any_pack(router_pb2.Router()),
    )


def _for_server(
    route_match: route_components_pb2.RouteMatch,
    server_header_matcher: route_components_pb2.HeaderMatcher,
) -> route_components_pb2.RouteMatch:
    """The web framework's route match, for this server: as given,
    plus the header that picks the server."""
    match = route_components_pb2.RouteMatch()
    match.CopyFrom(route_match)
    match.headers.append(server_header_matcher)
    return match


def _routes_for_server(
    application_id: ApplicationId,
    server: ServerInfo,
    kind: ClusterKind,
    file_descriptor_set: FileDescriptorSet,
    trust_caller_id: bool,
    route_matches: list[route_components_pb2.RouteMatch],
    catch_all: bool = True,
) -> list[route_components_pb2.Route]:
    # Every server gets routes to the websocket port, the gRPC
    # port, and the HTTP "catchall" port as described below.
    #
    # See corresponding routes for Istio in
    # reboot/controller/network_managers.py.

    cluster_name = _cluster_name(
        application_id=application_id,
        server_id=server.server_id,
        kind=kind,
    )

    server_header_matcher = route_components_pb2.HeaderMatcher(
        name=SERVER_ID_HEADER,
        string_match=string_pb2.StringMatcher(
            exact=server.server_id,
        ),
    )

    if kind == ClusterKind.GRPC:
        return [
            # This route sends all traffic with the
            # 'x-reboot-server-id' header and the 'content-type:
            # application/grpc' header to the gRPC port.
            route_components_pb2.Route(
                match=route_components_pb2.RouteMatch(
                    prefix="/",
                    headers=[
                        server_header_matcher,
                        route_components_pb2.HeaderMatcher(
                            name="content-type",
                            string_match=string_pb2.StringMatcher(
                                exact="application/grpc",
                            ),
                        ),
                    ],
                    grpc=route_components_pb2.RouteMatch.GrpcRouteMatchOptions(
                    ),
                ),
                route=route_components_pb2.RouteAction(
                    cluster=cluster_name,
                    max_stream_duration=route_components_pb2.RouteAction.
                    MaxStreamDuration(grpc_timeout_header_max=ZERO_SECONDS)
                ),
                request_headers_to_remove=(
                    # If we don't trust the caller ID header, remove it
                    # so that the upstream server can't be misled.
                    [CALLER_ID_HEADER] if not trust_caller_id else []
                ),
            ),
        ] + [
            # These routes send all traffic with the
            # 'x-reboot-server-id' header and a prefix path from
            # the file descriptor set of the application to the gRPC
            # port (where it will get gRPC-JSON transcoded).
            route_components_pb2.Route(
                match=route_components_pb2.RouteMatch(
                    prefix=prefix,
                    headers=[server_header_matcher],
                ),
                route=route_components_pb2.RouteAction(
                    cluster=cluster_name,
                    max_stream_duration=route_components_pb2.RouteAction.
                    MaxStreamDuration(grpc_timeout_header_max=ZERO_SECONDS)
                ),
            ) for prefix in get_path_prefixes_from_file_descriptor_set(
                file_descriptor_set,
            )
        ]

    elif kind == ClusterKind.HTTP:

        def http_route(
            match: route_components_pb2.RouteMatch,
        ) -> route_components_pb2.Route:
            return route_components_pb2.Route(
                match=match,
                route=route_components_pb2.RouteAction(
                    cluster=cluster_name,
                    # Set `max_stream_duration` to 0 to disable the timeout for this route.
                    max_stream_duration=route_components_pb2.RouteAction.
                    MaxStreamDuration(grpc_timeout_header_max=ZERO_SECONDS)
                ),
                typed_per_filter_config={
                    GRPC_JSON_TRANSCODER_HTTP_FILTER_NAME:
                        EMPTY_GRPC_JSON_TRANSCODER_CONFIG,
                },
            )

        return [
            # The paths the web framework answers (the application's
            # routes and mounts, and Reboot's), each its own route,
            # ahead of the catch-all below: today both go to the same
            # place, but something else may come to answer `/`.
            http_route(_for_server(route_match, server_header_matcher))
            for route_match in route_matches
        ] + (
            [
                # The catch-all: everything else goes to the HTTP port too.
                http_route(
                    route_components_pb2.RouteMatch(
                        prefix="/",
                        headers=[server_header_matcher],
                    )
                ),
            ] if catch_all else []
        )

    assert kind == ClusterKind.WEBSOCKET

    return [
        route_components_pb2.Route(
            match=route_components_pb2.RouteMatch(
                prefix="/",
                headers=[
                    route_components_pb2.HeaderMatcher(
                        name="upgrade",
                        string_match=string_pb2.StringMatcher(
                            exact="websocket",
                        ),
                    ),
                    server_header_matcher,
                ],
            ),
            route=route_components_pb2.RouteAction(
                cluster=cluster_name,
                # TODO: should we also include a `max_stream_duration`
                # here or are the websocket pings sufficient to keep
                # the connection from getting closed?
            ),
            typed_per_filter_config={
                GRPC_JSON_TRANSCODER_HTTP_FILTER_NAME:
                    EMPTY_GRPC_JSON_TRANSCODER_CONFIG,
            },
        )
    ]


# Marks a route to the frontend's dev server, so that the error page
# filter (`_frontend_error_filters`) knows a 503 came from there.
_FRONTEND_ROUTE_METADATA = base_pb2.Metadata(
    filter_metadata={
        "envoy.filters.http.lua":
            struct_pb2.Struct(
                fields={"frontend": struct_pb2.Value(string_value="1")},
            ),
    },
)


def _frontend_route(
    config: FrontendConfig,
    match: route_components_pb2.RouteMatch,
) -> route_components_pb2.Route:
    """A route to the frontend's dev server. Envoy handles WebSocket
    upgrades (for Hot Module Replacement) transparently."""
    return route_components_pb2.Route(
        match=match,
        route=route_components_pb2.RouteAction(
            cluster=FRONTEND_CLUSTER_NAME,
            # Under portless the dev server is behind the portless
            # proxy, which routes by name, so it must be asked for by
            # its name, not by the name the browser asked us for, which
            # is ours and would loop back here.
            host_rewrite_literal=(
                config.host if reboot.portless.enabled() else ""
            ),
        ),
        typed_per_filter_config={
            GRPC_JSON_TRANSCODER_HTTP_FILTER_NAME:
                EMPTY_GRPC_JSON_TRANSCODER_CONFIG,
        },
        metadata=_FRONTEND_ROUTE_METADATA,
    )


def _frontend_routes() -> list[route_components_pb2.Route]:
    """Routes for web dev server assets ("/__/frontend/**").

    MCP Apps use a double iframe: the outer `srcdoc` contains an inner
    `<iframe src="/__/frontend/mcp/...">`. This route proxies those
    requests to the web dev server.

    Returns empty list if the frontend is not configured.
    """
    config = _get_frontend_config()
    if config is None:
        return []

    # Route for web dev server assets: "/__/frontend/**".
    # Dev server is configured with `base: "/__/frontend/"` so paths match directly.
    return [
        _frontend_route(
            config,
            route_components_pb2.RouteMatch(prefix="/__/frontend/"),
        )
    ]


def _frontend_catch_all_routes() -> list[route_components_pb2.Route]:
    """With `--web-app`, the dev server serves the web app at `/`, so
    it gets `/` and every path nothing else claimed: this comes last,
    after the application's own paths and the MCP, OAuth and Reboot
    paths the web framework answers (`route_matches`).

    Returns empty list if the frontend is not configured or isn't
    serving the web app.
    """
    config = _get_frontend_config()
    if config is None or not config.web_app:
        return []
    return [
        _frontend_route(config, route_components_pb2.RouteMatch(prefix="/"))
    ]


def _frontend_cluster(
    local_envoy_mode: LocalEnvoyMode,
) -> cluster_pb2.Cluster | None:
    """Cluster for the frontend host (Vite in HMR, static server in dist).

    Returns None if the frontend is not configured.
    """
    config = _get_frontend_config()
    if config is None:
        return None

    # For localhost-like hostnames, use the appropriate address based
    # on the mode in which Envoy runs. Envoy in a Docker container
    # needs `host.docker.internal` to reach the host machine; Envoy
    # running as a stand-alone executable can use `localhost` directly.
    # Under portless the dev server's name is the proxy's on loopback,
    # reached at the loopback address with the name carried as SNI and
    # as the `Host` header.
    host = config.host
    if (
        host in ("localhost", "127.0.0.1", "0.0.0.0") or
        reboot.portless.enabled()
    ):
        if local_envoy_mode is LocalEnvoyMode.DOCKER:
            host = "host.docker.internal"
        else:
            host = "localhost"

    transport_socket: Optional[base_pb2.TransportSocket] = None
    if config.tls:
        # Under portless the dev server is the portless proxy, whose
        # certificates chain to its own locally generated CA: trust that
        # where portless keeps it. Otherwise there is nothing to
        # validate against: a dev server of the developer's own, often
        # with a self-signed certificate, or portless's CA out of reach
        # of Envoy in Docker, where the home directory isn't mounted.
        # Then any certificate is accepted, which is a developer's own
        # machine talking to its own dev server.
        common_tls_context = tls_pb2.CommonTlsContext()
        if (
            reboot.portless.enabled() and
            local_envoy_mode is not LocalEnvoyMode.DOCKER and
            reboot.portless.CA_PATH.is_file()
        ):
            common_tls_context.validation_context.trusted_ca.filename = (
                str(reboot.portless.CA_PATH)
            )
        transport_socket = base_pb2.TransportSocket(
            name="envoy.transport_sockets.tls",
            typed_config=any_pack(
                tls_pb2.UpstreamTlsContext(
                    sni=config.host,
                    common_tls_context=common_tls_context,
                )
            ),
        )

    return cluster_pb2.Cluster(
        name=FRONTEND_CLUSTER_NAME,
        type=cluster_pb2.Cluster.STRICT_DNS,
        lb_policy=cluster_pb2.Cluster.ROUND_ROBIN,
        common_http_protocol_options=protocol_pb2.HttpProtocolOptions(
            idle_timeout=ZERO_SECONDS,
        ),
        transport_socket=transport_socket,
        dns_lookup_family=cluster_pb2.Cluster.V4_ONLY,
        # Frontend is HTTP/1.1 (WebSockets not compatible with HTTP/2).
        load_assignment=endpoint_pb2.ClusterLoadAssignment(
            cluster_name=FRONTEND_CLUSTER_NAME,
            endpoints=[
                endpoint_components_pb2.LocalityLbEndpoints(
                    lb_endpoints=[
                        endpoint_components_pb2.LbEndpoint(
                            endpoint=endpoint_components_pb2.Endpoint(
                                address=address_pb2.Address(
                                    socket_address=address_pb2.SocketAddress(
                                        address=host,
                                        port_value=config.port,
                                    )
                                )
                            )
                        )
                    ],
                )
            ],
        ),
    )


def _frontend_error_filters() -> list[http_connection_manager_pb2.HttpFilter]:
    """Lua filter that replaces envoy's raw 503 for the
    `/__/frontend/` dev-server route with a friendly HTML page.

    Returns an empty list if the frontend is not configured.
    """
    config = _get_frontend_config()
    if config is None:
        return []

    # The error page shown when envoy can't reach the Vite
    # dev server.
    error_html = (
        '<!DOCTYPE html>'
        '<html lang="en"><head><meta charset="UTF-8">'
        '<meta name="viewport" '
        'content="width=device-width, initial-scale=1.0">'
        '<style>'
        'body{font-family:ui-monospace,SFMono-Regular,Menlo,'
        'monospace;background:#1a1a2e;color:#eee;display:flex;'
        'align-items:center;justify-content:center;'
        'min-height:100vh;margin:0}'
        '.c{text-align:center;padding:2rem}'
        'h2{color:#f87171}'
        'code{background:#0f0f1a;padding:.2rem .5rem;'
        'border-radius:4px;color:#fbbf24}'
        '</style></head><body><div class="c">'
        '<h2>Dev server not reachable</h2>'
        "<p>Couldn't reach the dev web server at "
        '<code>__FRONTEND_URL__</code>.</p>'
        '<p style="margin-top:1rem;opacity:.7">'
        'Is the dev web server running?</p>'
        '</div>'
        '<script>'
        # Send a `size-changed` postMessage so the
        # dev-loader relay (proxy.py) resizes the
        # wrapper to fit this error page.
        'window.parent.postMessage({'
        'jsonrpc:"2.0",'
        'method:"ui/notifications/size-changed",'
        'params:{height:document.body.scrollHeight}'
        '},"*");'
        '</script>'
        '</body></html>'
    ).replace('__FRONTEND_URL__', config.original_url)

    # Lua filter: a 503 on a route to the dev server (marked by
    # `_FRONTEND_ROUTE_METADATA`, which `metadata()` reads from the
    # matched route) gets the page in place of Envoy's raw body.
    lua_source = (
        'function envoy_on_response(response_handle)\n'
        '  if response_handle:metadata():get("frontend") == "1" and\n'
        '     response_handle:headers():get(":status")'
        ' == "503" then\n'
        '    response_handle:headers():replace(\n'
        '      "content-type", "text/html; charset=utf-8")\n'
        '    response_handle:body():setBytes([=[\n' + error_html + '\n'
        '    ]=])\n'
        '  end\n'
        'end\n'
    )

    return [
        http_connection_manager_pb2.HttpFilter(
            name="reboot.frontend_error_page",
            typed_config=_lua_any(lua_source),
        )
    ]


def _filter_http_connection_manager(
    application_id: ApplicationId,
    servers: list[ServerInfo],
    file_descriptor_set: FileDescriptorSet,
    trust_caller_id: bool,
    allowed_origins: Optional[list[str]],
    route_matches: list[route_components_pb2.RouteMatch],
) -> listener_components_pb2.Filter:
    # With `--web-app` the frontend's dev server, not the HTTP port,
    # answers whatever is left; see `_frontend_catch_all_routes`.
    frontend = _get_frontend_config()
    web_app = frontend is not None and frontend.web_app

    http_connection_manager = http_connection_manager_pb2.HttpConnectionManager(
        stat_prefix="grpc_json",
        stream_idle_timeout=ZERO_SECONDS,
        upgrade_configs=[
            http_connection_manager_pb2.HttpConnectionManager.UpgradeConfig(
                upgrade_type="websocket",
            ),
        ],
        # This is the configuration for a _local_ envoy. It will never
        # have a trusted (mTLS) connection with a peer. However, it may
        # sit behind other proxies that DO have mTLS connections. Don't
        # drop the `x-forwarded-client-cert` header if it exists.
        forward_client_cert_details=(
            http_connection_manager_pb2.HttpConnectionManager.
            ForwardClientCertDetails.ALWAYS_FORWARD_ONLY
        ),
        # TODO(rjh): this is a duration; but leaving out is the same as 0s, presumably?
        # stream_idle_timeout="0s",
        codec_type=http_connection_manager_pb2.HttpConnectionManager.AUTO,
        route_config=route_pb2.RouteConfiguration(
            name="local_route",
            virtual_hosts=[
                route_components_pb2.VirtualHost(
                    name="local_service",
                    domains=["*"],
                    # TODO(rjh): setting the `cors` policy here is deprecated,
                    #            instead we should set it directly on the
                    #            `envoy.filters.http.cors` filter in the filter
                    #            chain.
                    cors=_cors_policy(allowed_origins),
                    routes=(
                        # Frontend routes (if configured) must come
                        # first since they match specific prefixes.
                        _frontend_routes() + [
                            route for server in servers for kind in [
                                # Always list the route for the websocket
                                # first, since its matching is more specific.
                                ClusterKind.WEBSOCKET,
                                ClusterKind.GRPC,
                                ClusterKind.HTTP,
                            ] for route in _routes_for_server(
                                application_id=application_id,
                                server=server,
                                kind=kind,
                                file_descriptor_set=file_descriptor_set,
                                trust_caller_id=trust_caller_id,
                                route_matches=route_matches,
                                catch_all=not web_app,
                            )
                        ] + _frontend_catch_all_routes()
                    ),
                ),
            ],
        ),
        http_filters=[
            # Add the remove json trailers filter first so it's the last to
            # process responses (after transcoding and all other filters).
            # Response filters are processed in reverse order.
            _http_filter_remove_json_trailers(),
            _http_filter_add_header_x_reboot_application_id(application_id),
            # Before picking a server, we need to possibly de-mangle the path
            # to extract any relevant headers.
            _http_filter_mangled_http_path(),
            _http_filter_compute_header_x_reboot_server_id(servers),
            # Define CORS filter before the gRPC-JSON transcoding
            # filter, because otherwise perfectly-fine CORS requests
            # get rejected by the gRPC-JSON transcoding filter.
            _http_filter_cors(),
            # The gRPC-JSON transcoder filter comes before routing,
            # but note that we also need to override it for websocket
            # routes via a per-route config because otherwise it has
            # been shown to confuse traffic.
            _http_filter_grpc_json_transcoder(
                file_descriptor_set=file_descriptor_set,
            ),
        ] +
        # Friendly error page when the frontend dev server
        # is unreachable (only active when configured).
        _frontend_error_filters() + [
            _http_filter_router(),
        ]
    )

    return listener_components_pb2.Filter(
        name="envoy.filters.network.http_connection_manager",
        typed_config=any_pack(http_connection_manager),
    )


def _tls_socket(
    certificate_path: Path, key_path: Path
) -> base_pb2.TransportSocket:
    return base_pb2.TransportSocket(
        name="envoy.transport_sockets.tls",
        typed_config=any_pack(
            tls_pb2.DownstreamTlsContext(
                common_tls_context=tls_pb2.CommonTlsContext(
                    alpn_protocols=["h2"],
                    tls_certificates=[
                        common_pb2.TlsCertificate(
                            certificate_chain=base_pb2.DataSource(
                                filename=str(certificate_path),
                            ),
                            private_key=base_pb2.DataSource(
                                filename=str(key_path),
                            ),
                        ),
                    ],
                    validation_context=common_pb2.CertificateValidationContext(
                        trusted_ca=base_pb2.DataSource(
                            filename=str(certificate_path),
                        ),
                    ),
                ),
            )
        ),
    )


def listeners(
    application_id: ApplicationId,
    servers: list[ServerInfo],
    file_descriptor_set: FileDescriptorSet,
    trusted_host: str,
    trusted_port: int,  # 0 = pick any free port.
    public_port: int,
    use_tls: bool,
    certificate_path: Path,
    key_path: Path,
    allowed_origins: Optional[list[str]],
    route_matches: list[route_components_pb2.RouteMatch],
) -> list[listener_pb2.Listener]:

    @dataclass
    class ListenerConfig:
        name: str
        host: str
        port: int
        use_tls: bool
        trust_caller_id: bool

    listeners = [
        # The public listener takes traffic from anywhere (which may
        # be TLS-encrypted) on the port specified by the user, so
        # connections from other machines are expected and it listens
        # on every interface.
        ListenerConfig(
            name="public",
            host=EVERY_LOCAL_NETWORK_ADDRESS,
            port=public_port,
            use_tls=use_tls,
            # On the Reboot Cloud, proxies ensure that the caller ID is
            # set truthfully. Outside Reboot Cloud we can't trust public
            # traffic to not be lying about its caller ID.
            trust_caller_id=on_cloud(),
        ),
        # The trusted port takes traffic only from the local application
        # - no TLS is needed, nor supported.
        ListenerConfig(
            name="trusted",
            host=trusted_host,
            port=trusted_port,
            use_tls=False,
            trust_caller_id=True,
        ),
    ]

    return [
        listener_pb2.Listener(
            name=listener.name,
            address=address_pb2.Address(
                socket_address=address_pb2.SocketAddress(
                    address=listener.host,
                    port_value=listener.port,
                ),
            ),
            filter_chains=[
                listener_components_pb2.FilterChain(
                    filters=[
                        _filter_http_connection_manager(
                            application_id=application_id,
                            servers=servers,
                            file_descriptor_set=file_descriptor_set,
                            trust_caller_id=listener.trust_caller_id,
                            allowed_origins=allowed_origins,
                            route_matches=route_matches,
                        ),
                    ],
                    transport_socket=_tls_socket(certificate_path, key_path)
                    if listener.use_tls else None,
                )
            ],
            # See: https://github.com/reboot-dev/mono/issues/3944.
            per_connection_buffer_limit_bytes=UInt32Value(
                value=ENVOY_PER_CONNECTION_BUFFER_LIMIT_BYTES
            ),
        ) for listener in listeners
    ]


def _cluster_name(
    application_id: ApplicationId, server_id: ServerId, kind: ClusterKind
) -> str:
    # There are two forms the `ServerId`s can take here, neither of which may
    # be what you might expect:
    #
    # A) If there are multiple servers, server IDs are of the shape
    #    `[application-id]-[server-id]`, e.g. `foo-c123456`.
    #
    # B) If there is only a single server, the server ID is the
    #    application ID.
    #
    # This is a leftover of how local server management and Kubernetes
    # server management used to overlap.
    #
    # TODO(rjh): sanify the 'application_id' and 'server_id' relationship.
    #            We'd expect a server ID to be e.g. `c123456`.
    assert (
        server_id.startswith(f"{application_id}-") or
        server_id == application_id
    ), f"invalid server ID '{server_id}'"

    if kind == ClusterKind.GRPC:
        return f"{server_id}_grpc"

    elif kind == ClusterKind.HTTP:
        return f"{server_id}_http"

    else:
        assert (kind == ClusterKind.WEBSOCKET)
        return f"{server_id}_websocket"


def _cluster(
    application_id: ApplicationId,
    server_id: ServerId,
    host: str,
    port: int,
    kind: ClusterKind,
) -> cluster_pb2.Cluster:
    cluster_name = _cluster_name(application_id, server_id, kind)
    return cluster_pb2.Cluster(
        name=cluster_name,
        type=cluster_pb2.Cluster.STRICT_DNS,
        lb_policy=cluster_pb2.Cluster.ROUND_ROBIN,
        common_http_protocol_options=protocol_pb2.HttpProtocolOptions(
            idle_timeout=ZERO_SECONDS,
        ),
        dns_lookup_family=cluster_pb2.Cluster.V4_ONLY,
        # Setting empty HTTP2 protocol options is required to encourage Envoy to
        # use HTTP2 when talking to the upstream, so we MUST set this for gRPC
        # traffic - and for gRPC traffic ONLY, because websockets are NOT HTTP2.
        # TODO(rjh): this field is deprecated; migrate to
        #            `typed_extension_protocol_options`:
        #            https://github.com/envoyproxy/envoy/blob/45e0325f8d7ddf64a396798803a3fb7e6717257a/api/envoy/config/cluster/v3/cluster.proto#L927
        http2_protocol_options=protocol_pb2.Http2ProtocolOptions()
        if kind == ClusterKind.GRPC else None,
        load_assignment=endpoint_pb2.ClusterLoadAssignment(
            cluster_name=cluster_name,
            endpoints=[
                endpoint_components_pb2.LocalityLbEndpoints(
                    lb_endpoints=[
                        endpoint_components_pb2.LbEndpoint(
                            endpoint=endpoint_components_pb2.Endpoint(
                                address=address_pb2.Address(
                                    socket_address=address_pb2.SocketAddress(
                                        address=host,
                                        port_value=port,
                                    )
                                )
                            )
                        )
                    ],
                )
            ],
        ),
        # "Disable" all circuit breakers; they don't make much sense when all
        # traffic will flow to the host we're already on. Follows the pattern
        # suggested here: Follows the pattern suggested here:
        #   https://www.envoyproxy.io/docs/envoy/latest/faq/load_balancing/disable_circuit_breaking
        circuit_breakers=circuit_breaker_pb2.CircuitBreakers(
            thresholds=[
                circuit_breaker_pb2.CircuitBreakers.Thresholds(
                    priority=base_pb2.RoutingPriority.DEFAULT,
                    max_connections=UInt32Value(value=1000000000),
                    max_pending_requests=UInt32Value(value=1000000000),
                    max_requests=UInt32Value(value=1000000000),
                    max_retries=UInt32Value(value=1000000000),
                ),
                circuit_breaker_pb2.CircuitBreakers.Thresholds(
                    priority=base_pb2.RoutingPriority.HIGH,
                    max_connections=UInt32Value(value=1000000000),
                    max_pending_requests=UInt32Value(value=1000000000),
                    max_requests=UInt32Value(value=1000000000),
                    max_retries=UInt32Value(value=1000000000),
                ),
            ]
        ),
        # See: https://github.com/reboot-dev/mono/issues/3944.
        per_connection_buffer_limit_bytes=UInt32Value(
            value=ENVOY_PER_CONNECTION_BUFFER_LIMIT_BYTES
        ),
    )


def clusters(
    application_id: ApplicationId,
    servers: list[ServerInfo],
    local_envoy_mode: LocalEnvoyMode,
) -> list[cluster_pb2.Cluster]:
    result: list[cluster_pb2.Cluster] = []

    # Add frontend cluster if configured.
    frontend_cluster = _frontend_cluster(local_envoy_mode)
    if frontend_cluster is not None:
        result.append(frontend_cluster)

    for server in servers:
        # Every server serves both a gRPC and a WebSocket endpoint, on
        # different ports. They are therefore different clusters to Envoy.
        for kind in [
            ClusterKind.GRPC, ClusterKind.HTTP, ClusterKind.WEBSOCKET
        ]:
            result.append(
                _cluster(
                    application_id=application_id,
                    server_id=server.server_id,
                    host=server.address.host,
                    port=(
                        server.address.grpc_port
                        if kind == ClusterKind.GRPC else (
                            server.address.http_port if kind ==
                            ClusterKind.HTTP else server.address.websocket_port
                        )
                    ),
                    kind=kind,
                )
            )

    return result


def xds_cluster(
    host: str,
    port: int,
) -> cluster_pb2.Cluster:
    return cluster_pb2.Cluster(
        name="xds_cluster",
        type=cluster_pb2.Cluster.STRICT_DNS,
        dns_lookup_family=cluster_pb2.Cluster.V4_ONLY,
        load_assignment=endpoint_pb2.ClusterLoadAssignment(
            cluster_name="xds_cluster", endpoints=[
                endpoint_components_pb2.LocalityLbEndpoints(
                    lb_endpoints=[
                        endpoint_components_pb2.LbEndpoint(
                            endpoint=endpoint_components_pb2.Endpoint(
                                address=address_pb2.Address(
                                    socket_address=address_pb2.SocketAddress(
                                        address=host,
                                        port_value=port,
                                    )
                                )
                            )
                        )
                    ],
                )
            ]
        ),
        typed_extension_protocol_options={
            "envoy.extensions.upstreams.http.v3.HttpProtocolOptions":
                any_pack(
                    http_protocol_options_pb2.HttpProtocolOptions(
                        explicit_http_config=http_protocol_options_pb2.
                        HttpProtocolOptions.ExplicitHttpConfig(
                            # We must set this field explicitly (even to
                            # its default), since it's part of a oneof.
                            http2_protocol_options=protocol_pb2.
                            Http2ProtocolOptions(),
                        )
                    )
                )
        },
    )
