"""Servicers for the developer dashboard application."""
import os
from pathlib import Path
from rbt.dashboard.v1.dashboard_pb2 import (
    DashboardGetRequest,
    DashboardGetResponse,
    DashboardRecordCheckRequest,
    DashboardRecordCheckResponse,
    DashboardUpdateApiRequest,
    DashboardUpdateApiResponse,
    DashboardUpdateCodeRequest,
    DashboardUpdateCodeResponse,
    DashboardUpdateFeaturesRequest,
    DashboardUpdateFeaturesResponse,
    PreferencesGetRequest,
    PreferencesGetResponse,
    PreferencesSetCallGraphLayoutRequest,
    PreferencesSetCallGraphLayoutResponse,
    PreferencesSetMethodsExpandedRequest,
    PreferencesSetMethodsExpandedResponse,
    PreferencesSetNavWidthRequest,
    PreferencesSetNavWidthResponse,
    PreferencesSetPaneWidthRequest,
    PreferencesSetPaneWidthResponse,
    PreferencesSetSeenRequest,
    PreferencesSetSeenResponse,
    PreferencesSetSuppressAutomaticOpenRequest,
    PreferencesSetSuppressAutomaticOpenResponse,
)
from rbt.dashboard.v1.dashboard_rbt import Dashboard, Preferences
from rbt.std.collections.ordered_map.v1.ordered_map_rbt import OrderedMap
from reboot.aio.auth.authorizers import allow
from reboot.aio.contexts import (
    ReaderContext,
    TransactionContext,
    WorkflowContext,
    WriterContext,
)
from reboot.dashboard.backend import (
    api_watcher,
    code_watcher,
    features_watcher,
)
from reboot.dashboard.backend.constants import (
    CHANGELOG_ID,
    ENVVAR_RBT_API_DIRECTORY,
    ENVVAR_RBT_APPLICATION,
    ENVVAR_RBT_GENERATED_DIRECTORY,
)
from reboot.dashboard.backend.needs_generate_reason import (
    needs_generate_reason,
)
from reboot.std.item.v1.item import Item
from reboot.uuidv7 import uuid7


class DashboardServicer(Dashboard.Servicer):
    """Holds the shape the developer's API files declare."""

    def authorizer(self):
        # Anyone who can reach this can already read the files it
        # describes: it holds nothing but the shape of the developer's
        # own API files, and only ever runs under `rbt dashboard`.
        return allow()

    async def Get(
        self,
        context: ReaderContext,
        request: DashboardGetRequest,
    ) -> DashboardGetResponse:
        return DashboardGetResponse(
            api_directory=self.state.api_directory,
            error=self.state.error if self.state.HasField('error') else None,
            api_files=self.state.api_files,
            apis=self.state.apis,
            api_digests=self.state.api_digests,
            servicers=self.state.servicers,
            agents=self.state.agents,
            tools=self.state.tools,
            hazards=self.state.hazards,
            generated=self.state.generated,
            needs_generate_reason=needs_generate_reason(self.state),
            features=self.state.features,
            api_check=(
                self.state.api_check
                if self.state.HasField('api_check') else None
            ),
            code_check=(
                self.state.code_check
                if self.state.HasField('code_check') else None
            ),
            features_check=(
                self.state.features_check
                if self.state.HasField('features_check') else None
            ),
            api_changed_at=(
                self.state.api_changed_at
                if self.state.HasField('api_changed_at') else None
            ),
            code_changed_at=(
                self.state.code_changed_at
                if self.state.HasField('code_changed_at') else None
            ),
            features_changed_at=(
                self.state.features_changed_at
                if self.state.HasField('features_changed_at') else None
            ),
        )

    async def RecordCheck(
        self,
        context: WriterContext,
        request: DashboardRecordCheckRequest,
    ) -> DashboardRecordCheckResponse:
        """Records a check that found nothing to update: when the
        watcher checked the developer's files and how long it took."""
        watcher = request.WhichOneof('watcher')
        if watcher == 'api':
            self.state.api_check.CopyFrom(request.api)
        elif watcher == 'code':
            self.state.code_check.CopyFrom(request.code)
        elif watcher == 'features':
            self.state.features_check.CopyFrom(request.features)
        else:
            raise ValueError(f"Expecting a watcher's check, not {watcher!r}")

        return DashboardRecordCheckResponse()

    @classmethod
    async def WatchApi(
        cls,
        context: WorkflowContext,
        request: Dashboard.WatchApiRequest,
    ) -> Dashboard.WatchApiResponse:
        """Returns only when the dashboard stops, reading the
        developer's API files whenever they change.

        The directory comes from the environment each time this runs,
        so that an `rbt dashboard` restarted against a different one
        reads the new directory. Taking it from the request would keep
        whichever directory the run that started watching had.
        """
        api_directory = os.environ[ENVVAR_RBT_API_DIRECTORY]

        await api_watcher.watch(context, api_directory=api_directory)

        return Dashboard.WatchApiResponse()

    async def UpdateCode(
        self,
        context: TransactionContext,
        request: DashboardUpdateCodeRequest,
    ) -> DashboardUpdateCodeResponse:
        """Replaces what the application implements and records what
        changed, newest last."""
        del self.state.servicers[:]
        self.state.servicers.extend(request.servicers)
        del self.state.agents[:]
        self.state.agents.extend(request.agents)
        del self.state.tools[:]
        self.state.tools.extend(request.tools)
        del self.state.hazards[:]
        self.state.hazards.extend(request.hazards)
        self.state.code_analysis_version = request.code_analysis_version
        self.state.code_files.clear()
        self.state.code_files.MergeFrom(request.code_files)
        self.state.generated.clear()
        self.state.generated.MergeFrom(request.generated)
        self.state.code_check.CopyFrom(request.check)
        self.state.code_changed_at.CopyFrom(request.check.at)

        if len(request.changes) > 0:
            await OrderedMap.ref(CHANGELOG_ID).Insert(
                context,
                entries={
                    str(uuid7()): Item(bytes=change.SerializeToString())
                    for change in request.changes
                },
            )

        return DashboardUpdateCodeResponse()

    @classmethod
    async def WatchCode(
        cls,
        context: WorkflowContext,
        request: Dashboard.WatchCodeRequest,
    ) -> Dashboard.WatchCodeResponse:
        """Returns only when the dashboard stops, working out which of
        the developer's files implements each state type.

        The application comes from the environment each time this
        runs, for the same reason the API directory does. A developer
        who named none gets nothing looked for, which is the normal
        case for a Node.js application.
        """
        application = os.environ.get(ENVVAR_RBT_APPLICATION)
        generated_directory = os.environ.get(ENVVAR_RBT_GENERATED_DIRECTORY)

        if application is not None:
            await code_watcher.watch(
                context,
                application=Path(application),
                generated_directory=(
                    Path(generated_directory)
                    if generated_directory is not None else None
                ),
            )

        return Dashboard.WatchCodeResponse()

    async def UpdateFeatures(
        self,
        context: WriterContext,
        request: DashboardUpdateFeaturesRequest,
    ) -> DashboardUpdateFeaturesResponse:
        """Replaces what the developer's `.feature` files declare."""
        self.state.features.clear()
        self.state.features.MergeFrom(request.features)
        self.state.features_check.CopyFrom(request.check)
        self.state.features_changed_at.CopyFrom(request.check.at)

        return DashboardUpdateFeaturesResponse()

    @classmethod
    async def WatchFeatures(
        cls,
        context: WorkflowContext,
        request: Dashboard.WatchFeaturesRequest,
    ) -> Dashboard.WatchFeaturesResponse:
        """Returns only when the dashboard stops, parsing the
        developer's `.feature` files whenever they change."""
        await features_watcher.watch(context)

        return Dashboard.WatchFeaturesResponse()

    async def UpdateApi(
        self,
        context: TransactionContext,
        request: DashboardUpdateApiRequest,
    ) -> DashboardUpdateApiResponse:
        """Replaces what the API files declare and records what
        changed, newest last, as one transaction."""
        self.state.api_directory = request.api_directory
        if request.HasField('error'):
            self.state.error = request.error
        else:
            self.state.ClearField('error')
        self.state.api_files.clear()
        self.state.api_files.MergeFrom(request.api_files)
        self.state.apis.clear()
        self.state.apis.MergeFrom(request.apis)
        self.state.api_digests.clear()
        self.state.api_digests.MergeFrom(request.api_digests)
        self.state.api_check.CopyFrom(request.check)
        self.state.api_changed_at.CopyFrom(request.check.at)

        if len(request.changes) > 0:
            await OrderedMap.ref(CHANGELOG_ID).Insert(
                context,
                entries={
                    str(uuid7()): Item(bytes=change.SerializeToString())
                    for change in request.changes
                },
            )

        return DashboardUpdateApiResponse()


class PreferencesServicer(Preferences.Servicer):
    """Holds what the developer has said about their dashboard.

    Two unrelated choices share one state because both are facts about
    this machine's dashboard rather than about the application, and
    each has its own writer so that recording one never overwrites the
    other.
    """

    def authorizer(self):
        # Nothing here is worth keeping from anyone who can reach it:
        # it holds what this machine's own browser was told about
        # opening dashboards, and only ever runs under `rbt dashboard`.
        return allow()

    async def Get(
        self,
        context: ReaderContext,
        request: PreferencesGetRequest,
    ) -> PreferencesGetResponse:
        return PreferencesGetResponse(
            suppress_automatic_open=self.state.suppress_automatic_open,
            expanded_methods=self.state.expanded_methods,
            nav_width=(
                self.state.nav_width
                if self.state.HasField('nav_width') else None
            ),
            pane_width=(
                self.state.pane_width
                if self.state.HasField('pane_width') else None
            ),
            changelog_seen_key=(
                self.state.changelog_seen_key
                if self.state.HasField('changelog_seen_key') else None
            ),
            models_seen_at=(
                self.state.models_seen_at
                if self.state.HasField('models_seen_at') else None
            ),
            features_seen_at=(
                self.state.features_seen_at
                if self.state.HasField('features_seen_at') else None
            ),
            call_graph_layout=(
                self.state.call_graph_layout
                if self.state.HasField('call_graph_layout') else None
            ),
        )

    async def SetSuppressAutomaticOpen(
        self,
        context: WriterContext,
        request: PreferencesSetSuppressAutomaticOpenRequest,
    ) -> PreferencesSetSuppressAutomaticOpenResponse:
        self.state.suppress_automatic_open = request.suppress_automatic_open
        return PreferencesSetSuppressAutomaticOpenResponse()

    async def SetMethodsExpanded(
        self,
        context: WriterContext,
        request: PreferencesSetMethodsExpandedRequest,
    ) -> PreferencesSetMethodsExpandedResponse:
        """Opens or closes each named method: one for a single
        method's toggle, all of a state type's for its own."""
        expanded = set(self.state.expanded_methods)

        for method in request.methods:
            key = f'{request.state_type}.{method}'
            if request.expanded:
                expanded.add(key)
            else:
                expanded.discard(key)

        self.state.expanded_methods[:] = sorted(expanded)

        return PreferencesSetMethodsExpandedResponse()

    async def SetNavWidth(
        self,
        context: WriterContext,
        request: PreferencesSetNavWidthRequest,
    ) -> PreferencesSetNavWidthResponse:
        self.state.nav_width = request.nav_width
        return PreferencesSetNavWidthResponse()

    async def SetPaneWidth(
        self,
        context: WriterContext,
        request: PreferencesSetPaneWidthRequest,
    ) -> PreferencesSetPaneWidthResponse:
        self.state.pane_width = request.pane_width
        return PreferencesSetPaneWidthResponse()

    async def SetSeen(
        self,
        context: WriterContext,
        request: PreferencesSetSeenRequest,
    ) -> PreferencesSetSeenResponse:
        """Records what each given page showed the last time it was
        open."""
        if request.HasField('changelog_seen_key'):
            self.state.changelog_seen_key = request.changelog_seen_key
        if request.HasField('models_seen_at'):
            self.state.models_seen_at.CopyFrom(request.models_seen_at)
        if request.HasField('features_seen_at'):
            self.state.features_seen_at.CopyFrom(request.features_seen_at)
        return PreferencesSetSeenResponse()

    async def SetCallGraphLayout(
        self,
        context: WriterContext,
        request: PreferencesSetCallGraphLayoutRequest,
    ) -> PreferencesSetCallGraphLayoutResponse:
        """Replaces the call graph's layout. The default layout, nothing
        collapsed, dragged or resized, is stored as no layout at all."""
        layout = request.call_graph_layout
        if (
            not layout.collapsed_packages and
            not layout.moved_package_boxes and
            not layout.moved_state_type_cards and
            not layout.resized_package_boxes
        ):
            self.state.ClearField('call_graph_layout')
        else:
            self.state.call_graph_layout.CopyFrom(layout)
        return PreferencesSetCallGraphLayoutResponse()
