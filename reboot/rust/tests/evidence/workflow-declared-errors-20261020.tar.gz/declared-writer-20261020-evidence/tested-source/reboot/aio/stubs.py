import dataclasses
import grpc
import grpc_status._async as rpc_status
import uuid
from contextlib import asynccontextmanager
from google.protobuf.message import Message
from grpc.aio import AioRpcError
from log.log import get_logger
from rbt.v1alpha1 import errors_pb2
from reboot.aio.aborted import (
    TRANSACTION_SHOULD_RETRY_REASONS_WITHOUT_BACKOFF,
    Aborted,
    SystemAborted,
)
from reboot.aio.backoff import Backoff
from reboot.aio.caller_id import CallerID
from reboot.aio.contexts import (
    Context,
    Participants,
    TransactionContext,
    WorkflowContext,
)
from reboot.aio.external import ExternalContext, InitializeContext
from reboot.aio.headers import (
    IDEMPOTENCY_KEY_HEADER,
    TRANSACTION_RETRY_AGE_HEADER,
    Headers,
)
from reboot.aio.idempotency import (
    IdempotencyManager,
    make_expiring_idempotency_key,
)
from reboot.aio.internals.channel_manager import _ChannelManager
from reboot.aio.internals.contextvars import get_application_id
from reboot.aio.types import (
    ApplicationId,
    GrpcMetadata,
    ServiceName,
    StateRef,
    StateTypeName,
)
from typing import (
    Any,
    AsyncIterable,
    AsyncIterator,
    Awaitable,
    Callable,
    Generator,
    Generic,
    Optional,
    Protocol,
    TypeVar,
    runtime_checkable,
)

CallT = TypeVar('CallT', bound=grpc.Call)
ResponseT = TypeVar('ResponseT', bound=Message)
RequestT = TypeVar('RequestT', bound=Message)

logger = get_logger(__name__)


@runtime_checkable
class UnaryCall(Protocol):
    """A unary RPC call: awaiting it returns the response, and after that
    `trailing_metadata()` returns the metadata the server sent with it.

    `grpc.aio.UnaryUnaryCall`, `UnaryRetriedCall` and
    `NestedTransactionUnaryRetriedCall` all have this shape.
    """

    def __await__(self) -> Generator[Any, None, Any]:
        ...

    async def trailing_metadata(self) -> GrpcMetadata:
        ...


class UnaryRetriedCall(Generic[ResponseT]):
    """
    Helper for making an RPC call, and retrying if there's a retryable
    error.

    The built-in gRPC retry mechanism unfortunately only supports up to
    5 retries before giving up [1]; that's not sufficient for the use
    case of a Reboot application. This wrapper therefore implements
    custom retry logic.

    This must be done in a helper object wrapped around a gRPC `call`
    object, because while there are only a few places in our generated
    code where we _create_ a `Call` object, there are many places where
    we `await` them - and most of those places are not suitable for
    in-place retry logic.

    [1] https://github.com/grpc/proposal/blob/master/A6-client-retries.md#validation-of-retrypolicy
    """

    def __init__(
        self,
        *,
        # In some places in the generated code we must create a `call`
        # object to decide whether or not to even make the call; in
        # those cases, the already-created `call` object can be passed,
        # so it can be used to make the first call.
        call: Optional[Awaitable[ResponseT]],
        # What follows is information that's needed to create subsequent
        # `call` objects (for retries, or if no `call` was provided in
        # the first place).
        stub_method: Callable[...,
                              Awaitable[ResponseT] | AsyncIterable[ResponseT]],
        method_name: str,
        request: Message,
        metadata: GrpcMetadata,
        # When something went _fatally_ wrong, an error of the following
        # type is raised.
        aborted_type: type[Aborted],
    ) -> None:
        self._call: Optional[Awaitable[ResponseT]] = call
        self._stub_method = stub_method
        self._method_name = method_name
        self._request = request
        self._metadata = metadata
        self._aborted_type = aborted_type

        # The age of the transaction this call started, once known:
        # the root transaction id of its first attempt, learned from
        # the first `TransactionShouldRetry` the call aborts with. A
        # retry carries it as the transaction's age so that the
        # retried transaction is as old as its first attempt rather
        # than younger than every transaction started since, which
        # would let it be aborted the same way again and again.
        self._retry_age: Optional[uuid.UUID] = None

    async def trailing_metadata(self) -> GrpcMetadata:
        """Return the trailing metadata from the call."""
        if self._call is None:
            raise RuntimeError(
                "Cannot get trailing metadata before the call has been made"
            )
        return await self._call.trailing_metadata( # type: ignore[attr-defined]
        )

    def __await__(self) -> Generator[Any, None, ResponseT]:
        return self._call_with_retries().__await__()

    def _should_retry(self, error: grpc.aio.AioRpcError) -> bool:
        # For now, the only retriable error is UNAVAILABLE.
        return error.code() == grpc.StatusCode.UNAVAILABLE

    async def _transaction_should_retry(
        self,
    ) -> Optional[errors_pb2.TransactionShouldRetry]:
        """The `TransactionShouldRetry` the failed call aborted with, or
        `None` if it aborted with something else."""
        if self._call is None:
            return None
        status = await rpc_status.from_call(self._call)
        if status is None:
            return None
        error = Aborted.error_from_google_rpc_status_details(
            status,
            [errors_pb2.TransactionShouldRetry],
        )
        if isinstance(error, errors_pb2.TransactionShouldRetry):
            return error
        return None

    def _metadata_with_retry_age(self) -> GrpcMetadata:
        """The call's metadata with the transaction age header set to
        the transaction's age, for a retry; unchanged while the age is
        unknown or once the header is present."""
        if self._retry_age is None or any(
            key == TRANSACTION_RETRY_AGE_HEADER for key, _ in self._metadata
        ):
            return self._metadata
        return self._metadata + (
            (TRANSACTION_RETRY_AGE_HEADER, str(self._retry_age)),
        )

    async def _call_with_retries(self) -> ResponseT:
        backoff = Backoff()
        # A `TransactionShouldRetry` may ask us to retry immediately,
        # but we elide the backoff only once: a transaction that keeps
        # being asked to start over should still back off rather than
        # hammer the cluster with immediate retries.
        backoff_elided = False
        while True:
            if self._call is None:
                new_call = self._stub_method(
                    self._request, metadata=self._metadata
                )
                assert isinstance(new_call, Awaitable)
                self._call = new_call
            try:
                return await self._call
            except grpc.aio.AioRpcError as error:
                if self._should_retry(error):
                    logger.debug(
                        f"Unary call to '{self._method_name}' encountered "
                        f"retryable error: {error}; will retry..."
                    )
                    should_retry = await self._transaction_should_retry()
                    if (
                        self._retry_age is None and
                        should_retry is not None and
                        should_retry.retry_age != ''
                    ):
                        self._retry_age = uuid.UUID(should_retry.retry_age)
                    if (
                        should_retry is not None and should_retry.reason
                        == errors_pb2.TransactionShouldRetry.PRESUMED_DEADLOCK
                    ):
                        logger.warning(
                            f"Retrying '{self._method_name}' because its "
                            "transaction is presumed deadlocked: "
                            f"{error.details()}"
                        )
                    apply_backoff = (
                        backoff_elided or should_retry is None or
                        should_retry.reason
                        not in TRANSACTION_SHOULD_RETRY_REASONS_WITHOUT_BACKOFF
                    )
                    if apply_backoff:
                        await backoff()
                    else:
                        backoff_elided = True
                    # We need to create a fresh call object for the
                    # retry, carrying the age of the first attempt.
                    self._metadata = self._metadata_with_retry_age()
                    self._call = None
                    continue

                # Because the `self._call` is not necessarily the `call`
                # that was passed to us, the outer try/except blocks may
                # not correctly spot and handle an error. We therefore
                # do that here.
                status = (
                    await rpc_status.from_call(self._call)
                ) if self._call is not None else None

                if status is not None:
                    raise self._aborted_type.from_status(status) from None

                raise self._aborted_type.from_grpc_aio_rpc_error(
                    error
                ) from None

        raise RuntimeError("This is unreachable")


class NestedTransactionUnaryRetriedCall(Generic[ResponseT]):
    """A unary call made within a transaction, re-issued each time it
    fails with `NestedTransactionShouldRetry` for a nested transaction
    the caller is not within: the nested transaction the call started,
    or one deeper, was presumed deadlocked with a sibling and has
    rolled back, and the caller is the level that must start it over.
    Whatever the rolled-back nested transaction claimed is still a
    participant on the transaction's behalf, so each failed attempt's
    participants are merged into the caller's. Any other failure is
    raised as is.
    """

    def __init__(
        self,
        *,
        stub_method: Callable[..., grpc.aio.UnaryUnaryCall],
        method_name: str,
        request: Message,
        metadata: GrpcMetadata,
        context: Context,
    ) -> None:
        self._stub_method = stub_method
        self._method_name = method_name
        self._request = request
        self._metadata = metadata
        self._context = context
        # The latest attempt, once one has been made.
        self.call: Optional[grpc.aio.UnaryUnaryCall] = None

    async def code(self) -> grpc.StatusCode:
        """The status code of the latest attempt."""
        assert self.call is not None, "No attempt has been made"
        return await self.call.code()

    async def details(self) -> str:
        """The status details of the latest attempt."""
        assert self.call is not None, "No attempt has been made"
        return await self.call.details()

    async def trailing_metadata(self) -> GrpcMetadata:
        """The trailing metadata of the latest attempt; empty before
        one has been made."""
        if self.call is None:
            return ()
        return await self.call.trailing_metadata()

    def __await__(self) -> Generator[Any, None, ResponseT]:
        return self._call_with_retries().__await__()

    async def _nested_transaction_should_retry(
        self,
    ) -> Optional[errors_pb2.NestedTransactionShouldRetry]:
        """The `NestedTransactionShouldRetry` the latest attempt failed
        with, or `None` if it failed with something else."""
        assert self.call is not None, "No attempt has been made"
        status = await rpc_status.from_call(self.call)
        if status is None:
            return None
        error = Aborted.error_from_google_rpc_status_details(
            status,
            [errors_pb2.NestedTransactionShouldRetry],
        )
        if isinstance(error, errors_pb2.NestedTransactionShouldRetry):
            return error
        return None

    async def _call_with_retries(self) -> ResponseT:
        transaction_ids = self._context.transaction_ids
        assert transaction_ids is not None
        backoff = Backoff()
        # The first re-issue is immediate: the nested transaction has
        # rolled back, so what it claimed is free or is about to be
        # claimed by the older sibling it lost to. A nested transaction
        # that keeps losing backs off so that it is not re-issued into
        # the same conflict again and again.
        backoff_elided = False
        while True:
            self.call = self._stub_method(
                self._request, metadata=self._metadata
            )
            try:
                response: ResponseT = await self.call
                return response
            except grpc.aio.AioRpcError as error:
                should_retry = await self._nested_transaction_should_retry()
                if (
                    should_retry is None or
                    uuid.UUID(should_retry.transaction_id) in transaction_ids
                ):
                    raise
                self._context.participants.union(
                    Participants.from_grpc_metadata(
                        await self.call.trailing_metadata()
                    )
                )
                logger.warning(
                    f"Re-issuing '{self._method_name}' because the nested "
                    f"transaction {should_retry.transaction_id} it started "
                    "is presumed deadlocked with a sibling and has rolled "
                    f"back: {error.details()}"
                )
                if backoff_elided:
                    await backoff()
                else:
                    backoff_elided = True


class Stub:
    """Common base class for generated reboot stubs.
    """
    _channel_manager: _ChannelManager
    _headers: Headers

    _idempotency_manager: IdempotencyManager

    # Context that was used to create this stub.
    _context: Optional[Context]

    def __init__(
        self,
        *,
        channel_manager: _ChannelManager,
        idempotency_manager: IdempotencyManager,
        state_ref: StateRef,
        context: Optional[Context],
        bearer_token: Optional[str],
        caller_id: Optional[CallerID],
    ):
        self._channel_manager = channel_manager
        self._idempotency_manager = idempotency_manager
        self._context = context

        application_id: Optional[ApplicationId] = None

        workflow_id: Optional[uuid.UUID] = None
        transaction_ids: Optional[list[uuid.UUID]] = None
        transaction_coordinator_state_type: Optional[StateTypeName] = None
        transaction_coordinator_state_ref: Optional[StateRef] = None
        transaction_retry_age: Optional[uuid.UUID] = None

        workflow_iteration: Optional[int] = None

        coordinator_read_only_aware: bool = False

        if context is not None:
            caller_id = CallerID(
                application_id=context.application_id,
                # Carry who this call is made on behalf of. If a
                # bearer token is set, `Headers` drops the `Auth`
                # again (but not the caller ID: the call stays
                # app-internal).
                auth=context.auth,
            )

            # For the time being, all traffic is intra-application. The
            # target application is therefore the same as the calling
            # application.
            application_id = context.application_id

            workflow_id = context.workflow_id
            workflow_iteration = context.workflow_iteration
            transaction_ids = context.transaction_ids
            transaction_coordinator_state_type = context.transaction_coordinator_state_type
            transaction_coordinator_state_ref = context.transaction_coordinator_state_ref
            # Every state a retried transaction touches orders it by
            # the age of its first attempt, not only the state the
            # retry arrived at.
            transaction_retry_age = context.transaction_retry_age

            # If we are the transaction coordinator then let our
            # participants know that we are read-only aware.
            #
            # NOTE: we MUST NOT set `coordinator_read_only_aware =
            # True` unless we are the coordinator because otherwise we
            # might set it in _participant_ that is aware of read-only
            # but an upstream caller might _not_ be aware and thus we
            # may propagate read-only participants that get dropped!
            if isinstance(context, TransactionContext) and not context.nested:
                coordinator_read_only_aware = True
            else:
                # Propagate the read-only-aware flag from the inbound RPC.
                coordinator_read_only_aware = (
                    context._headers.coordinator_read_only_aware
                )
        else:
            # When we're creating a `Stub` via an `ExternalContext`,
            # we use the application ID from the asyncio context
            # variable, if present.
            application_id = get_application_id()

        # NOTE: when running tests via `reboot.aio.tests.Reboot`
        # we won't always know our application ID.

        self._headers = Headers(
            application_id=application_id,
            state_ref=state_ref,
            workflow_id=workflow_id,
            workflow_iteration=workflow_iteration,
            transaction_ids=transaction_ids,
            transaction_coordinator_state_type=
            transaction_coordinator_state_type,
            transaction_coordinator_state_ref=transaction_coordinator_state_ref,
            transaction_retry_age=transaction_retry_age,
            bearer_token=bearer_token,
            caller_id=caller_id,
            internal_call=context is not None,
            coordinator_read_only_aware=coordinator_read_only_aware,
        )

    def _should_call_retry_unavailable(
        self, call: Awaitable | AsyncIterable,
        request_or_requests: Message | AsyncIterable[Message]
    ) -> bool:
        if isinstance(call, AsyncIterable):
            # This is a server-streaming call.
            #
            # It is NOT safe to retry server-streaming calls,
            # even if they can only be readers. Unlike
            # _reactive_ reader calls, streaming reader
            # responses can have ~any semantic the developer
            # wants, and it isn't safe to simply restart the
            # response stream from the beginning.
            #
            # We therefore do NOT implement transparent retry
            # logic for this call.
            return False
        if isinstance(request_or_requests, AsyncIterable):
            # This is a client-streaming call.
            #
            # It is NOT safe to retry client-streaming calls,
            # since the `request_or_requests` is an iterable and
            # may have already been (partially) consumed by the
            # time a retry would be attempted.
            #
            # We therefore do NOT implement transparent retry
            # logic for this call.
            return False

        # This is a unary call. It is _safe_ to retry, but should we?
        # Retries are done at the root of the DAG, so only at the root
        # will we consider retrying. Even at the root, it depends on the
        # type of DAG root we have:
        # 1. Workflows retry failures by restarting the whole workflow.
        #    That is, we will NOT retry individual calls.
        # 2. `ExternalContext`s. These are the only place where we retry
        #    individual calls.
        #
        # If and ONLY if we're in an `ExternalContext`, the `_context`
        # is None, because `ExternalContext` is the only context type
        # that doesn't inherit from `Context`.
        return self._context is None

    @asynccontextmanager
    async def _call(
        self,
        state_type_name: StateTypeName,
        service_name: ServiceName,
        method: str,
        stub_method: Callable[...,
                              Awaitable[ResponseT] | AsyncIterable[ResponseT]],
        request_or_requests: RequestT | AsyncIterable[RequestT],
        *,
        unary: bool,
        reader: bool,
        response_type: type[ResponseT],
        aborted_type: type[Aborted],
        metadata: Optional[GrpcMetadata] = None,
        idempotency_key: Optional[uuid.UUID] = None,
        per_iteration: bool = False,
        always: bool = False,
        bearer_token: Optional[str] = None,
    ) -> AsyncIterator[Awaitable[ResponseT] | AsyncIterable[ResponseT]]:
        """Helper for making an RPC, handling any user-defined errors, and
        doing so correctly depending on whether or not we are reactive
        or in a transaction.
        """
        if self._context is not None and self._context.transaction_id is not None:
            unrecoverable_abort = self._context.transaction_unrecoverable_abort
            if unrecoverable_abort is not None:
                # The transaction can only abort at this point, so
                # refuse to do any more work on its behalf: every
                # state we'd touch would take a lock and provisionally
                # mutate only to be rolled back, and the failure would
                # not surface until the method returned.
                raise unrecoverable_abort

        if metadata is None:
            metadata = ()

        # TODO(benh): maybe just overwrite the idempotency key instead
        # of checking for its existence?
        if any(t[0] == IDEMPOTENCY_KEY_HEADER for t in metadata):
            raise ValueError(
                f"Do not set '{IDEMPOTENCY_KEY_HEADER}' metadata yourself"
            )

        # If this call is not to a reader, is coming from an
        # `ExternalContext` (which is when `self._context is None`),
        # and there isn't a user-provided idempotency key, add one so
        # that we can retry safely.
        if not reader and self._context is None and idempotency_key is None:
            assert isinstance(self._idempotency_manager, ExternalContext)

            # We may perform transparent retries on this call. That
            # means it needs to be idempotent, and for non-readers that
            # means we need an idempotency key. So even if the user or
            # idempotency manager didn't provide an idempotency key, we
            # generate one now. Keys generated here don't need to be
            # reproducible, they just need to be unique, and it should
            # expire after 7 days.
            #
            # Although, for `InitializeContext`, we don't generate a
            # retry-safety idempotency key so that we don't pay for
            # idempotent mutations. Retryable errors (e.g.,
            # UNAVAILABLE) will still be properly handled by the outer
            # `initialize` retry handler in `servers.py` which re-runs
            # the entire `initialize` function.
            if not isinstance(self._idempotency_manager, InitializeContext):
                idempotency_key = make_expiring_idempotency_key()

        # If we're a `WorkflowContext` all non-readers should have an
        # idempotency key already (unless `.always()` which intentionally
        # has no key).
        assert (
            not isinstance(self._context, WorkflowContext) or
            (reader or idempotency_key is not None or always)
        )

        if idempotency_key is not None:
            metadata += ((IDEMPOTENCY_KEY_HEADER, str(idempotency_key)),)

        headers = self._headers

        # If this is a workflow, refresh `workflow_iteration` because
        # it may change dynamically as the workflow progresses through
        # control loop iterations and thus `self._headers` is stale.
        # Only set it for `per_iteration` calls so that the server
        # stores/recovers the mutation with iteration scoping.
        if isinstance(self._context, WorkflowContext):
            headers = dataclasses.replace(
                headers,
                workflow_iteration=(
                    self._context.workflow_iteration if per_iteration else None
                ),
            )

        if bearer_token is not None:
            headers = dataclasses.replace(
                headers,
                bearer_token=bearer_token,
            )

        metadata += headers.to_grpc_metadata()

        call: Awaitable[ResponseT] | AsyncIterable[ResponseT]
        try:
            # Check if we should execute this call reactively.
            if (
                self._context is not None and
                self._context.react is not None and unary and reader
            ):
                # This code path only applies for _transitive_ reactive
                # reader calls; calls that are made directly via
                # `WeakReference.reactively()` are handled elsewhere.
                # This code path handles a reader call made from within
                # a context that is already reactive, and that therefore
                # (implicitly) must be reactive themselves.
                #
                # Reactive calls are only supported for unary readers,
                # i.e., we only have a single request, and we won't be
                # in a transaction.
                #
                # This type of reactive call is _not_ the root of a DAG,
                # and so is NOT retried on error (even if the error is
                # retryable).
                assert not isinstance(request_or_requests, AsyncIterable)
                assert self._context.transaction_id is None

                call, response = await self._context.react.call(
                    state_type_name=state_type_name,
                    state_ref=self._headers.state_ref,
                    service_name=service_name,
                    method=method,
                    request=request_or_requests,
                    response_type=response_type,
                    metadata=metadata,
                )

                yield response
            elif self._context is not None and self._context.transaction_id is not None:
                async with self._call_transactionally(
                    stub_method,
                    request_or_requests,
                    method=method,
                    unary=unary,
                    aborted_type=aborted_type,
                    metadata=metadata,
                ) as call:
                    yield call
            else:
                call = stub_method(request_or_requests, metadata=metadata)
                if self._should_call_retry_unavailable(
                    call, request_or_requests
                ):
                    assert isinstance(call, Awaitable)
                    assert isinstance(request_or_requests, Message)
                    # This is not a reactive call.
                    assert (
                        self._context is None or self._context.react is None or
                        not unary or not reader
                    )
                    # This is not a transaction.
                    assert (
                        self._context is None or
                        self._context.transaction_id is None
                    )
                    yield UnaryRetriedCall(
                        call=call,
                        stub_method=stub_method,
                        method_name=method,
                        request=request_or_requests,
                        metadata=metadata,
                        aborted_type=aborted_type,
                    )
                else:
                    yield call

        except AioRpcError as error:
            status = (
                await rpc_status.from_call(call)
            ) if call is not None else None

            if status is not None:
                raise aborted_type.from_status(status) from None

            raise aborted_type.from_grpc_aio_rpc_error(error) from None
        finally:
            # NOTE: to ensure that a caller can read their writes in a
            # reactive setting we need to invalidate any reactive
            # readers. There is still the possibility if someone is
            # concurrently reading while writing that they'll get a
            # stale response but that is possible regardless due to
            # the inherent non-determinism of concurrent calls.
            if (
                self._context is not None and
                self._context.react is not None and not reader
            ):

                self._context.react.invalidate(
                    service_name=service_name,
                    state_ref=self._headers.state_ref,
                )

    @asynccontextmanager
    async def _call_transactionally(
        self,
        stub_method: Callable[..., CallT],
        request_or_requests: RequestT | AsyncIterable[RequestT],
        *,
        method: str,
        unary: bool,
        aborted_type: type[Aborted],
        metadata: GrpcMetadata,
    ) -> AsyncIterator[CallT | NestedTransactionUnaryRetriedCall]:
        """Helper for making an unreactive RPC and properly tracking it if it
        is part of a transaction. A unary RPC is re-issued when a
        nested transaction it started is presumed deadlocked with a
        sibling; see `NestedTransactionUnaryRetriedCall`.
        """
        assert self._context is not None
        assert self._context.transaction_id is not None

        self._context.outstanding_rpcs += 1

        call: Optional[CallT | NestedTransactionUnaryRetriedCall] = None

        try:
            if unary:
                assert isinstance(request_or_requests, Message)
                call = NestedTransactionUnaryRetriedCall(
                    stub_method=stub_method,
                    method_name=method,
                    request=request_or_requests,
                    metadata=metadata,
                    context=self._context,
                )
            else:
                call = stub_method(request_or_requests, metadata=metadata)
            assert call is not None
            yield call
        except AioRpcError as error:
            status = (
                await rpc_status.from_call(call)
            ) if call is not None else None

            aborted = (
                aborted_type.from_status(status) if status is not None else
                aborted_type.from_grpc_aio_rpc_error(error)
            )

            if not aborted_type.is_from_backend_and_recoverable(aborted):
                # Keep the first abort, which is the one that would
                # have propagated had the caller not caught it.
                if self._context.transaction_unrecoverable_abort is None:
                    self._context.transaction_unrecoverable_abort = aborted

            raise aborted
        except:
            # We don't know what went wrong, so we can't hand the
            # caller anything better than a generic error.
            #
            # TODO(benh): considering stringifying the exception to
            # include in the error we raise when doing the prepare
            # stage of two phase commit.
            if self._context.transaction_unrecoverable_abort is None:
                self._context.transaction_unrecoverable_abort = RuntimeError(
                    'Transaction must abort'
                )

            raise
        finally:
            saw_legacy_to_abort = False
            if call is not None:
                participants = Participants.from_grpc_metadata(
                    await call.trailing_metadata()
                )
                self._context.participants.union(participants)
                saw_legacy_to_abort = participants.saw_legacy_to_abort

            self._context.outstanding_rpcs -= 1

            # Rolling-upgrade compatibility: an older server
            # propagated participants to abort which we no longer
            # support so we fail the transaction with the retryable
            # `Unavailable` so that it can be retried, hopefully after
            # all servers have been upgraded.
            if saw_legacy_to_abort:
                aborted = SystemAborted(
                    errors_pb2.Unavailable(),
                    message=(
                        "A transaction participant was marked to abort "
                        "by an older server during a rolling upgrade; "
                        "retry required."
                    ),
                )
                self._context.transaction_unrecoverable_abort = aborted
                raise aborted
