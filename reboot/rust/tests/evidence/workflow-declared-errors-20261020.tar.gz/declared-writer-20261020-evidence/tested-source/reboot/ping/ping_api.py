from reboot.api import (
    API,
    UI,
    Exclusive,
    Field,
    Methods,
    Model,
    Reader,
    Tool,
    Transaction,
    Type,
    Workflow,
    Writer,
)

# -- Ping/Pong models. --


class DoPingResponse(Model):
    num_pings: int = Field(tag=1)


class DoPingPeriodicallyRequest(Model):
    num_pings: int = Field(tag=1)
    period_seconds: float = Field(tag=2)


class DoPingPeriodicallyResponse(Model):
    num_pings: int = Field(tag=1)


class DescribeResponse(Model):
    text: str = Field(tag=1)


class NumPingsResponse(Model):
    num_pings: int = Field(tag=1)


class DoPongResponse(Model):
    num_pongs: int = Field(tag=1)


class NumPongsResponse(Model):
    num_pongs: int = Field(tag=1)


class PingState(Model):
    num_pings: int = Field(tag=1, default=0)


class PongState(Model):
    num_pongs: int = Field(tag=1, default=0)


# -- User models. --


class CreateCounterRequest(Model):
    description: str = Field(tag=1)


class CreateCounterResponse(Model):
    counter_id: str = Field(tag=1)


class CounterEntry(Model):
    counter_id: str = Field(tag=1)
    description: str = Field(tag=2)


class ListCountersResponse(Model):
    counters: list[CounterEntry] = Field(tag=1, default_factory=list)


class WhoAmIResponse(Model):
    user_id: str = Field(tag=1)
    email: str = Field(tag=2, default="")


class UserState(Model):
    counter_ids: list[str] = Field(tag=1, default_factory=list)
    # The email identity claim most recently delivered at sign-in
    # (empty when the identity provider supplied none).
    email: str = Field(tag=2, default="")


# -- Counter models (simple counter). --


class InitializeCounterRequest(Model):
    description: str = Field(tag=1)
    # The `user_id` of the Counter's owner, recorded so that only the
    # owner may call the Counter later.
    owner_id: str = Field(tag=2)


class DescriptionResponse(Model):
    description: str = Field(tag=1)


class IncrementResponse(Model):
    value: int = Field(tag=1)


class ValueResponse(Model):
    value: int = Field(tag=1)


class CounterState(Model):
    value: int = Field(tag=1, default=0)
    description: str = Field(tag=2, default="")
    owner_id: str = Field(tag=3, default="")


class ShowClickerProps(Model):
    # Visual style for the clicker UI; the AI picks a primary
    # color to match the user's mood or the counter's purpose.
    # The snake_case field name is intentional — it exercises the
    # Python→TS camelCase conversion path that any real Reboot
    # app needs for multi-word UI request fields. Empty string
    # means use the app's default style.
    primary_color: str = Field(tag=1, default="")


api = API(
    Ping=Type(
        state=PingState,
        methods=Methods(
            show_pinger=UI(
                request=None,
                path="pinger",
                title="Ping Counter",
                description="Interactive UI for the Ping's counter.",
            ),
            do_ping=Transaction(
                mode=Exclusive(),
                request=None,
                response=DoPingResponse,
                mcp=Tool(),
            ),
            do_ping_periodically=Workflow(
                request=DoPingPeriodicallyRequest,
                response=DoPingPeriodicallyResponse,
                mcp=None,
            ),
            describe=Reader(
                request=None,
                response=DescribeResponse,
                mcp=None,
            ),
            num_pings=Reader(
                request=None,
                response=NumPingsResponse,
                mcp=Tool(),
            ),
        ),
    ),
    Pong=Type(
        state=PongState,
        methods=Methods(
            do_pong=Writer(
                request=None,
                response=DoPongResponse,
                mcp=None,
            ),
            num_pongs=Reader(
                request=None,
                response=NumPongsResponse,
                mcp=None,
            ),
        ),
    ),
    User=Type(
        state=UserState,
        methods=Methods(
            create_counter=Transaction(
                mode=Exclusive(),
                request=CreateCounterRequest,
                response=CreateCounterResponse,
                description="Create a new Counter with a "
                "description of what it counts. Returns "
                "the `counter_id`, which is not "
                "human-readable but should be passed to "
                "future tool calls that need it.",
                mcp=Tool(),
            ),
            list_counters=Reader(
                request=None,
                response=ListCountersResponse,
                description="List all counters created by "
                "this user. Returns `counter_id` and "
                "description for each. The `counter_id` is "
                "not human-readable, but use it when "
                "calling tools that take a `counter_id`.",
                mcp=Tool(),
            ),
            whoami=Reader(
                request=None,
                response=WhoAmIResponse,
                description="Returns the authenticated user's ID.",
                mcp=Tool(),
            ),
        ),
    ),
    Counter=Type(
        state=CounterState,
        methods=Methods(
            show_clicker=UI(
                request=ShowClickerProps,
                path="clicker",
                title="Counter Clicker",
                description=("Interactive clicker for the Counter."),
            ),
            create=Writer(
                request=InitializeCounterRequest,
                response=None,
                factory=True,
                mcp=None,
            ),
            increment=Writer(
                request=None,
                response=IncrementResponse,
                description="Increment the counter.",
                mcp=Tool(),
            ),
            value=Reader(
                request=None,
                response=ValueResponse,
                description="Get the current counter value.",
                mcp=Tool(),
            ),
            description=Reader(
                request=None,
                response=DescriptionResponse,
                mcp=None,
            ),
        ),
    ),
)
