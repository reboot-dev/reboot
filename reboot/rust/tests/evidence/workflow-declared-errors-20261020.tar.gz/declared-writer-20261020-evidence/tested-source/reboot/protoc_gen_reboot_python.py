#!/usr/bin/env python3

import ast
import os
import re
import reboot.aio.tracing
import sys
from dataclasses import dataclass
from google.protobuf.descriptor import (
    Descriptor,
    FieldDescriptor,
    FileDescriptor,
    MethodDescriptor,
)
from google.protobuf.descriptor_pool import DescriptorPool
from reboot.options import get_field_options, get_method_options
from reboot.protoc_gen_reboot_generic import (
    BaseClient,
    BaseFile,
    BaseLegacyGrpcService,
    BaseMethod,
    BaseMethodOptions,
    BaseService,
    BaseState,
    PluginSpecificData,
    ProtoMethodOptions,
    ProtoType,
    RebootProtocPlugin,
    UserProtoError,
)
from typing import Optional, Sequence

PythonType = str


@dataclass
class PythonMethodOptions(BaseMethodOptions):
    errors: dict[ProtoType, PythonType]
    # When we generate errors from Pydantic API, we will generate a top-level
    # error message with a 'oneof' field for each Pydantic model error.
    # We need to keep track of the Pydantic model types for proper type
    # checking in the generated code.
    # The `pydantic_error_types` list contains the proper Pydantic model
    # type names.
    # Set only when generating from Pydantic APIs.
    pydantic_error_types: list[PythonType]
    # During the code generation we need to know each 'oneof' field details
    # which will contain:
    #   1) A top-level gRPC generated error type;
    #   2) A gRPC generated error type for a corresponding 'oneof' field.
    #   3) A Pydantic type for a corresponding 'oneof' field;
    # This will allow us to properly create a top-level Protobuf error
    # message which will contain the specified field and we can convert
    # that field back and forth between Pydantic and Protobuf formats.
    pydantic_error_field_details: dict[
        str,
        tuple[
            PythonType,
            PythonType,
            PythonType,
        ],
    ]


@dataclass
class PythonMethod(BaseMethod):
    options: PythonMethodOptions
    input_type: PythonType
    input_type_name: PythonType
    output_type: PythonType
    output_type_name: PythonType
    input_type_fields: dict[str, str]
    has_non_none_request: bool
    has_non_none_response: bool


@dataclass
class PythonLegacyGrpcService(BaseLegacyGrpcService):
    # The name of the Python protoc generated '*_pb2_grpc.py' file.
    pb2_grpc_name: str


@dataclass
class PythonService(BaseService):
    methods: Sequence[PythonMethod]
    # The name of the Python protoc generated '*_pb2_grpc.py' file.
    pb2_grpc_name: str


@dataclass
class PythonState(BaseState):
    services: Sequence[PythonService]
    pb2_name: str


@dataclass
class PythonClient(BaseClient):
    services: Sequence[PythonService]
    state: Optional[PythonState]


@dataclass
class PythonFile(BaseFile):
    # The following is a Sequence, not list, to make it covariant:
    #   https://mypy.readthedocs.io/en/stable/common_issues.html#variance
    states: Sequence[PythonState]
    clients: Sequence[PythonClient]
    imports: set[str]
    # The name of the Python protoc generated '*_pb2.py' file.
    pb2_name: str


class PythonRebootProtocPlugin(RebootProtocPlugin):

    def __init__(self, pool: Optional[DescriptorPool] = None):
        """Initialize the plugin with a descriptor pool. Used only when NodeJS
        plugin generates Python Reboot code."""
        if pool is not None:
            self.pool = pool

    def _py_service(
        self,
        service: BaseService,
        from_pydantic: bool,
    ) -> PythonService:

        return PythonService(
            proto=service.proto,
            options=service.options,
            methods=[
                PythonMethod(
                    proto=method.proto,
                    options=self._analyze_options(
                        method.options.proto,
                        method.proto._descriptor,
                        from_pydantic,
                    ),
                    input_type=self._python_type_from_proto_type(
                        method.proto._descriptor.input_type
                    ),
                    input_type_name=self._py_type_name(
                        method.proto._descriptor.input_type
                    ),
                    output_type=self._python_type_from_proto_type(
                        method.proto._descriptor.output_type
                    ),
                    output_type_name=self._py_type_name(
                        method.proto._descriptor.output_type
                    ),
                    input_type_fields=self._analyze_input_type_fields(
                        method.proto._descriptor.input_type,
                        from_pydantic,
                    ),
                    has_non_none_request=self.
                    _analyze_has_non_none_request_or_response(
                        method.proto._descriptor.input_type,
                        from_pydantic,
                    ),
                    has_non_none_response=self.
                    _analyze_has_non_none_request_or_response(
                        method.proto._descriptor.output_type,
                        from_pydantic,
                    ),
                ) for method in service.methods
            ],
            pb2_grpc_name=self._pb2_module_name(
                service.proto._descriptor.file
            ) + '_grpc',
        )

    def _py_state(self, file: BaseFile, state: BaseState) -> PythonState:
        return PythonState(
            proto=state.proto,
            services=[
                self._py_service(
                    service,
                    file.options.proto.pydantic is not None,
                ) for service in state.services
            ],
            pb2_name=self._pb2_module_name(file.proto._descriptor),
        )

    def add_language_dependent_data(self, file: BaseFile) -> BaseFile:
        return PythonFile(
            proto=file.proto,
            options=file.options,
            legacy_grpc_services=[
                PythonLegacyGrpcService(
                    proto=legacy_grpc_service.proto,
                    pb2_grpc_name=self._pb2_module_name(
                        legacy_grpc_service.proto._descriptor.file
                    ) + '_grpc',
                ) for legacy_grpc_service in file.legacy_grpc_services
            ],
            states=[self._py_state(file, state) for state in file.states],
            clients=[
                PythonClient(
                    proto=client.proto,
                    services=[
                        self._py_service(
                            service,
                            file.options.proto.pydantic is not None,
                        ) for service in client.services
                    ],
                    state=self._py_state(file, client.state)
                    if client.state is not None else None,
                ) for client in file.clients
            ],
            reboot_version=file.reboot_version,
            # The generated code names modules of two kinds: the
            # protobuf modules of the `.proto` dependency graph, and
            # the Python modules defining the Pydantic models that
            # `pydantic_type` options spell out.
            imports=self._analyze_imports(file.proto._descriptor) |
            self._analyze_pydantic_imports(file.proto._descriptor),
            pb2_name=self._pb2_module_name(file.proto._descriptor),
        )

    @staticmethod
    def plugin_specific_data() -> PluginSpecificData:
        return PluginSpecificData(
            template_filename="reboot.py.j2",
            output_filename_suffix="_rbt.py",
            supported_features=[
                "reader",
                "writer",
                "transaction",
                "error",
                "streaming",
                "workflow",
            ],
            only_generates_with_reboot_services=False,
            exclude_google_and_reboot_system_generation=False,
        )

    @classmethod
    def _is_google_or_reboot_package(cls, package_name: str) -> bool:
        return package_name.startswith('google.') or package_name.startswith(
            'rbt.v1alpha1'
        )

    @classmethod
    def _pb2_module_name(cls, file: FileDescriptor) -> str:
        """Get gRPC Python module name from file descriptor name and package.
        """
        file_name = os.path.basename(file.name).removesuffix('.proto')
        return file.package + '.' + file_name + '_pb2'

    @classmethod
    def _py_type_name(cls, message: Descriptor) -> str:
        """Get type name of the given message type, including any enclosing
        types.
        """
        if message.containing_type is None:
            return message.name
        return f"{cls._py_type_name(message.containing_type)}.{message.name}"

    @classmethod
    def _python_type_from_proto_type(
        cls,
        message: Descriptor,
    ) -> str:
        """Get full name (package and type) of generated gRPC message from
        message descriptor.
        """
        py_type_name = cls._py_type_name(message)
        py_module_name = cls._pb2_module_name(message.file)
        full_py_type_name = f'{py_module_name}.{py_type_name}'
        return full_py_type_name

    @classmethod
    def _python_type_from_map_entry_type(
        cls,
        message: Descriptor,
    ) -> str:
        """Gets a fully qualified `dict[K,V]` type definition for the given `repeated ${Field}Entry`
        message.

        Protobuf encodes its `map` type as a repeated message type name `{${Field}Entry}`, which is
        an inner type of the message with the same name as the field.
        """

        field_types = cls._analyze_message_fields(message)
        if set(field_types.keys()) != {'key', 'value'}:
            raise UserProtoError(
                f"Unexpected content for `map` field type message: {field_types}. "
                "Please report this issue to the maintainers!"
            )

        key_name = field_types['key']
        value_name = field_types['value']

        return f'dict[{key_name}, {value_name}]'

    def _analyze_options(
        self,
        proto_method_options: ProtoMethodOptions,
        method: MethodDescriptor,
        from_pydantic: bool,
    ) -> PythonMethodOptions:
        pydantic_error_types: list[PythonType] = []
        pydantic_error_field_details: dict[
            str,
            tuple[
                PythonType,
                PythonType,
                PythonType,
            ],
        ] = {}
        if from_pydantic:
            pydantic_error_types = self._analyze_pydantic_error_types(method)
            pydantic_error_field_details = self._analyze_pydantic_error_field_details(
                method
            )

        errors = self._analyze_python_errors(method)

        assert len(errors) <= 1 or not from_pydantic, (
            "Pydantic APIs with multiple errors should generate a single "
            "Protobuf error type containing a oneof of all error options. "
            "Please report this bug to the maintainers!"
        )
        return PythonMethodOptions(
            proto=proto_method_options,
            errors=errors,
            pydantic_error_types=pydantic_error_types,
            pydantic_error_field_details=pydantic_error_field_details,
        )

    def _analyze_pydantic_error_field_details(
        self,
        method: MethodDescriptor,
    ) -> dict[str, tuple[PythonType, PythonType, PythonType]]:
        """Analyze and return a mapping of Pydantic error field details for the given method.

        The Protobuf error schema for Pydantic APIs contains a
        top-level error message with a 'oneof' field which contains
        each Pydantic model error. This function collects the necessary
        details for each 'oneof' field to allow proper conversion
        between Pydantic and Protobuf formats.
        """
        method_options = get_method_options(method)
        pydantic_error_field_details: dict[
            str,
            tuple[
                PythonType,
                PythonType,
                PythonType,
            ],
        ] = {}

        for error_name in method_options.errors:
            assert (len(method_options.errors) == 1), (
                "Pydantic APIs with multiple errors should generate a single "
                "Protobuf error type containing a oneof of all error options. "
                "Please report this bug to the maintainers!"
            )

            # When generating from Pydantic APIs, each error message
            # corresponds to a 'oneof' field and we have only one top-level
            # error message.
            top_level_error_message = self.find_error_message(
                error_name, method
            )

            assert (len(top_level_error_message.oneofs) == 1), (
                "Pydantic APIs with multiple errors should generate a single "
                "Protobuf error type containing a oneof of all error options. "
                "Please report this bug to the maintainers!"
            )

            for oneof in top_level_error_message.oneofs:
                for field in oneof.fields:
                    field_options = get_field_options(field)
                    assert field_options.pydantic_type is not None

                    field_proto_message_type = field.message_type

                    pydantic_error_field_details[field.name] = (
                        self._python_type_from_proto_type(
                            top_level_error_message,
                        ),
                        self._python_type_from_proto_type(
                            field_proto_message_type,
                        ),
                        field_options.pydantic_type,
                    )

        return pydantic_error_field_details

    def _analyze_pydantic_error_types(
        self,
        method: MethodDescriptor,
    ) -> list[PythonType]:
        """Analyze and return a list of Pydantic error types for the given method.

        The Protobuf error schema for Pydantic APIs generates a top-level error
        message with a 'oneof' field for each Pydantic model error. This function
        collects the Pydantic model types for proper type checking in the
        generated code.

        Used only when generating from Pydantic APIs.
        """

        method_options = get_method_options(method)
        pydantic_error_types: list[PythonType] = []

        for error_name in method_options.errors:
            error_message = self.find_error_message(error_name, method)

            for field in error_message.fields:
                field_options = get_field_options(field)
                assert field_options.pydantic_type is not None
                pydantic_error_types.append(field_options.pydantic_type)

        return pydantic_error_types

    def _analyze_python_errors(
        self, method: MethodDescriptor
    ) -> dict[ProtoType, PythonType]:
        method_options = get_method_options(method)
        # From error name, e.g., 'product.api.ErrorName' to Python type, e.g., {
        # 'product.api.ErrorName': 'product.api.file_pb2.ErrorName' }.
        errors: dict[ProtoType, PythonType] = {}

        for error_name in method_options.errors:
            error_message = self.find_error_message(error_name, method)
            file = error_message.file
            errors[f"{file.package}.{error_message.name}"
                  ] = self._python_type_from_proto_type(error_message)

        return errors

    @classmethod
    def _analyze_imports(cls, file: FileDescriptor) -> set[str]:
        """Return the set of protobuf modules our generated code needs:
        the `_pb2` (and `_pb2_grpc`) modules of the file itself and,
        transitively, of every `.proto` file it imports.

        These are exactly the modules reachable through the `.proto`
        dependency graph, which makes every protobuf message the
        generated code names importable.
        """
        # Firstly, we need the standard gRPC modules, i.e., `_pb2` and
        # `_pb2_grpc`...
        imports = {
            cls._pb2_module_name(file),
        }
        if len(file.services_by_name) > 0:
            imports.add(cls._pb2_module_name(file) + '_grpc')

        # Also include each 'import' in the .proto file.
        for dependency in file.dependencies:
            imports = imports.union(cls._analyze_imports(dependency))

        return imports

    @classmethod
    def _analyze_pydantic_imports(cls, file: FileDescriptor) -> set[str]:
        """Return the set of modules that define the Pydantic models
        which the file's `pydantic_type` field options name.

        Those options spell a model by its module and class, e.g.,
        `shared.errors.NotFoundError`, and the generated code uses them
        verbatim as Python expressions. A model defined in a file other
        than the API file, e.g., an error type shared between APIs, is
        only reachable that way once its module is imported.

        The `.proto` generated for a Pydantic API file carries its own
        copy of every model the API uses, so the module defining a
        shared model is named only by these options and is absent from
        the `.proto` dependency graph that `_analyze_imports` walks.

        Used only when generating from Pydantic APIs.
        """
        modules: set[str] = set()

        def visit(message: Descriptor) -> None:
            for field in message.fields:
                pydantic_type = get_field_options(field).pydantic_type
                if not pydantic_type:
                    continue
                # A `pydantic_type` is a type expression, e.g.,
                # `IMPORT_typing.Optional[list[shared.errors.Money]]`,
                # so we parse it to find each dotted name in it. For
                # `shared.errors.Money` that yields `shared.errors` and
                # its parent package `shared`; importing both is
                # equivalent to importing `shared.errors` alone.
                for node in ast.walk(ast.parse(pydantic_type, mode='eval')):
                    if isinstance(node, ast.Attribute):
                        module = ast.unparse(node.value)
                        # Our own imports, e.g., `IMPORT_typing`, are
                        # already in place.
                        if not module.startswith('IMPORT_'):
                            modules.add(module)
            for nested_message in message.nested_types:
                visit(nested_message)

        for message in file.message_types_by_name.values():
            visit(message)

        return modules

    @classmethod
    def _analyze_has_non_none_request_or_response(
        cls,
        message: Descriptor,
        from_pydantic: bool,
    ) -> bool:
        if not from_pydantic:
            # There is no way to have `None` request or response outside
            # of Pydantic API.
            return True

        # We use `google.protobuf.Empty` to represent `None` request or
        # response.
        return message.full_name != 'google.protobuf.Empty'

    @classmethod
    def _analyze_input_type_fields(
        cls,
        message: Descriptor,
        from_pydantic: bool,
    ) -> dict[str, str]:
        """Helper to analyze input type fields either from protobuf message
        descriptor or from Pydantic model in the API.
        """

        if from_pydantic:
            return cls._analyze_pydantic_fields(message)
        else:
            return cls._analyze_message_fields(message)

    @classmethod
    def _analyze_pydantic_fields(
        cls,
        message: Descriptor,
    ) -> dict[str, str]:
        model_fields: dict[str, str] = {}

        for field in message.fields:
            field_options = get_field_options(field)
            assert field_options.pydantic_type is not None
            model_fields[field.name] = field_options.pydantic_type

        return model_fields

    @classmethod
    def _analyze_message_fields(
        cls,
        message: Descriptor,
    ) -> dict[str, str]:
        """Returns a dict from field name, e.g., 'foo' to type
        depending on language, e.g., { 'foo': 'product.api.file_pb2.Foo' }.
        """

        def is_valid_field_name(name: str) -> bool:
            """Field name should be snake_case, lowercase, and not start with
            more than one underscore..
            """
            if name.startswith('__'):
                return False

            pattern = r"^_?[a-z0-9]+(_[a-z0-9]*)*$"

            return bool(re.match(pattern, name))

        py_types: dict[int, str] = {
            FieldDescriptor.TYPE_DOUBLE: 'float',
            FieldDescriptor.TYPE_FLOAT: 'float',
            FieldDescriptor.TYPE_INT32: 'int',
            FieldDescriptor.TYPE_INT64: 'int',
            FieldDescriptor.TYPE_UINT32: 'int',
            FieldDescriptor.TYPE_UINT64: 'int',
            FieldDescriptor.TYPE_SINT32: 'int',
            FieldDescriptor.TYPE_SINT64: 'int',
            FieldDescriptor.TYPE_FIXED32: 'int',
            FieldDescriptor.TYPE_FIXED64: 'int',
            FieldDescriptor.TYPE_SFIXED32: 'int',
            FieldDescriptor.TYPE_SFIXED64: 'int',
            FieldDescriptor.TYPE_BOOL: 'bool',
            FieldDescriptor.TYPE_STRING: 'str',
            FieldDescriptor.TYPE_BYTES: 'bytes',
            FieldDescriptor.TYPE_ENUM: 'int',
        }

        message_fields: dict[str, str] = {}

        for field in message.fields:

            if not is_valid_field_name(field.name):
                raise UserProtoError(
                    f"Field name '{field.name}' is forbidden. Field names must "
                    "be snake_case and lowercase and not start with more than "
                    "one underscore."
                )
            if cls._is_map_field(message, field):
                message_fields[field.name
                              ] = cls._python_type_from_map_entry_type(
                                  field.message_type
                              )
                continue

            if field.type == FieldDescriptor.TYPE_GROUP:
                raise UserProtoError(
                    "Fields of type 'group' are currently not supported"
                )
            elif field.type == FieldDescriptor.TYPE_MESSAGE:
                message_fields[field.name] = cls._python_type_from_proto_type(
                    field.message_type
                )
            else:
                assert field.type in py_types
                message_fields[field.name] = py_types[field.type]

            if field.label == FieldDescriptor.LABEL_REPEATED:
                # To avoid name conflicts in the generated code, we import the
                # 'typing' module as 'IMPORT_typing'.
                message_fields[
                    field.name
                ] = f"IMPORT_typing.Iterable[{message_fields[field.name]}]"

        return message_fields


# This is a separate function (rather than just being in `__main__`) so that we
# can refer to it as a `script` in our `pip_package` BUILD targets.
@reboot.aio.tracing.main_span("protoc_gen_reboot_python")
def main():
    try:
        PythonRebootProtocPlugin.execute()
    except UserProtoError as error:
        print(f"{error}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
