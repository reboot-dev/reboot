import argparse
import time
import traceback
from pathlib import Path
from rbt.v1alpha1.admin import export_import_pb2_grpc
from reboot.admin import export_import_client
from reboot.aio.external import ExternalContext
from reboot.cli.common import terminal
from reboot.cli.common.admin_credential import (
    add_admin_credential_args,
    resolve_admin_credential,
)
from reboot.cli.common.rc import ArgumentParser, add_common_channel_args
from typing import Optional


def export_and_import_subcommands() -> list[str]:
    return ['export', 'import']


def register_export_and_import(parser: ArgumentParser):

    def _add_common_args(subcommand):
        add_common_channel_args(subcommand)
        add_admin_credential_args(subcommand)

    _add_common_args(parser.subcommand('export'))
    parser.subcommand('export').add_argument(
        '--directory',
        type=str,
        help="a directory to export data to, as JSON-lines files",
        required=True,
    )

    _add_common_args(parser.subcommand('import'))
    parser.subcommand('import').add_argument(
        '--directory',
        type=str,
        help="a directory to import data from, as JSON-lines files",
        required=True,
    )


def _export_import_stub(
    args: argparse.Namespace,
    admin_credential: str,
) -> export_import_pb2_grpc.ExportImportStub:
    context = ExternalContext(
        name="reboot-cli",
        bearer_token=admin_credential,
        url=args.application_url,
    )
    return export_import_pb2_grpc.ExportImportStub(
        context.legacy_grpc_channel()
    )


async def do_export(args: argparse.Namespace) -> int:
    """Implementation of the 'export' subcommand."""

    dest_dir = Path(args.directory)
    if dest_dir.is_dir() and any(dest_dir.iterdir()):
        terminal.fail(f"Destination directory `{dest_dir}` must be empty.\n\n")

    admin_credential = resolve_admin_credential(args)
    export_import = _export_import_stub(args, admin_credential)
    export_start_time = time.monotonic()
    try:
        await export_import_client.do_export(
            export_import, dest_dir, admin_token=admin_credential
        )
    except Exception as e:
        terminal.fail(
            f"Failed to export: {e}\n\nPlease report this issue to the maintainers."
        )

    terminal.info(
        f"Exported to: `{dest_dir}` in {time.monotonic() - export_start_time:.2f} seconds"
    )
    return 0


async def do_import(args: argparse.Namespace) -> int:
    """Implementation of the 'import' subcommand."""

    src_dir = Path(args.directory)
    if not src_dir.is_dir() or not any(src_dir.iterdir()):
        terminal.fail(f"Source directory `{src_dir}` must be non-empty.\n\n")

    admin_credential = resolve_admin_credential(args)
    export_import = _export_import_stub(args, admin_credential)
    import_start_time = time.monotonic()
    try:
        await export_import_client.do_import(
            export_import, src_dir, admin_token=admin_credential
        )
    except BaseException as e:
        traceback.print_exc()
        terminal.fail(
            f"Failed to import: {type(e)}: {e}\n\nPlease report this issue to the maintainers."
        )

    terminal.info(
        f"Imported from: `{src_dir}` in {time.monotonic() - import_start_time:.2f} seconds"
    )
    return 0


async def handle_export_and_import_subcommand(
    args: argparse.Namespace,
) -> Optional[int]:
    if args.subcommand == 'export':
        return await do_export(args)
    elif args.subcommand == 'import':
        return await do_import(args)
    return None
