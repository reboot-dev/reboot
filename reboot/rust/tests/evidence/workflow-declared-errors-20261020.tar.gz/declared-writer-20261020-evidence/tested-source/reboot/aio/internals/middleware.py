from __future__ import annotations

import functools
import grpc
import reboot.aio.tracing
import uuid
from abc import ABC, abstractmethod
from contextlib import contextmanager
from google.protobuf.message import Message
from logging import Logger
from reboot.aio.auth.authorizers import Authorizer
from reboot.aio.auth.token_verifiers import TokenVerifier
from reboot.aio.contexts import (
    Context,
    ContextT,
    EffectValidation,
    EffectValidationRetry,
    ReaderContext,
    TransactionContext,
    WorkflowContext,
    _log_message_for_effect_validation,
)
from reboot.aio.headers import Headers
from reboot.aio.idempotency import Checkpoint, IdempotencyManager
from reboot.aio.internals.channel_manager import _ChannelManager
from reboot.aio.internals.contextvars import Servicing, _servicing
from reboot.aio.internals.tasks_dispatcher import (
    TaskResponseOrStatus,
    TasksDispatcher,
)
from reboot.aio.placement import PlacementClient
from reboot.aio.tasks import TaskEffect
from reboot.aio.types import (
    ApplicationId,
    ServerId,
    ServiceName,
    StateRef,
    StateTypeName,
)
from reboot.settings import DOCS_BASE_URL
from reboot.time import DateTimeWithTimeZone
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Callable,
    Concatenate,
    Coroutine,
    Iterator,
    Optional,
    ParamSpec,
    TypeVar,
)

# `StateManager` is only used in type annotations in this module.
# A runtime import would create a circular dependency: `middleware`
# imports `state_managers`, and `state_managers` imports `middleware`.
if TYPE_CHECKING:
    from reboot.aio.state_managers import StateManager

P = ParamSpec('P')
SelfT = TypeVar('SelfT')
ReturnT = TypeVar('ReturnT')

# Dictionary 'method_name': 'timestamp' to keep track of when we last
# explained effect validation for a method. By using the helper
# `_log_message_for_effect_validation` we'll log a message on the
# first invocation of 'method_name' as well as after some time so that
# the user is not inundated with log messages.
_has_ever_explained_effect_validation: dict[str, DateTimeWithTimeZone] = {}


def maybe_run_function_twice_to_validate_effects(
    f: Callable[Concatenate[bool, P], Coroutine[Any, Any, ReturnT]]
) -> Callable[P, Coroutine[Any, Any, ReturnT]]:
    # TODO: Ideally this would inject a keyword argument, but that cannot currently be made
    # typesafe. See https://peps.python.org/pep-0612/#concatenating-keyword-parameters

    @functools.wraps(f)
    async def wrapper(*args: P.args, **kwargs: P.kwargs):
        try:
            return await f(False, *args, **kwargs)
        except EffectValidationRetry:
            return await f(True, *args, **kwargs)

    return wrapper


class Middleware(ABC):
    """Base class for generated middleware.
    """
    # We expect these values to be set by generated subclass constructors.
    tasks_dispatcher: TasksDispatcher
    request_type_by_method_name: dict[str, type[Message]]

    _token_verifier: Optional[TokenVerifier]
    _authorizer: Authorizer

    def __init__(
        self,
        *,
        application_id: ApplicationId,
        server_id: ServerId,
        state_type_name: StateTypeName,
        service_names: list[ServiceName],
        placement_client: PlacementClient,
        channel_manager: _ChannelManager,
        effect_validation: EffectValidation,
        get_database_timestamp_ms: Callable[[], Optional[int]],
    ):
        self._application_id = application_id
        self._server_id = server_id
        self._state_type_name = state_type_name
        assert len(service_names) > 0
        self._service_names = service_names
        self._effect_validation = effect_validation
        self._get_database_timestamp_ms = get_database_timestamp_ms

        self.placement_client = placement_client
        self.channel_manager = channel_manager

    @property
    def application_id(self) -> ApplicationId:
        return self._application_id

    @property
    def server_id(self) -> ServerId:
        return self._server_id

    @property
    def state_type_name(self) -> StateTypeName:
        return self._state_type_name

    @property
    def service_names(self) -> list[ServiceName]:
        return self._service_names

    def create_context(
        self,
        *,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        context_type: type[ContextT],
        task: Optional[TaskEffect] = None,
        # For a `TransactionContext` only: whether the transaction
        # method declared that it holds the lock on its own state
        # exclusive from the start.
        exclusive: Optional[bool] = None,
        # These parameters are used in the `WorkflowContext` only.
        reactively_state_manager: Optional[StateManager] = None,
        reactively_state_type: Optional[type] = None,
    ) -> ContextT:
        """Create a Context object given the parameters."""
        # Toggle 'servicing' to indicate we are initializing the
        # servicing of an RPC which will, for example, permit the
        # construction of a context without raising an error.
        _servicing.set(Servicing.INITIALIZING)

        # Sanity check: we're handling the right type, right?
        if state_type_name != self._state_type_name:
            raise ValueError(
                f"Requested unexpected state type '{state_type_name}'; "
                f"this servicer is of type {self._state_type_name}"
            )

        kwargs: dict = dict(
            channel_manager=self.channel_manager,
            headers=headers,
            state_type_name=state_type_name,
            method=method,
            task=task,
            effect_validation=self._effect_validation,
        )
        if context_type == WorkflowContext:
            assert reactively_state_manager is not None, (
                "`reactively_state_manager` is required for"
                " `WorkflowContext`"
            )
            assert reactively_state_type is not None, (
                "`reactively_state_type` is required for `WorkflowContext`"
            )
            kwargs['reactively_state_manager'] = reactively_state_manager
            kwargs['reactively_state_type'] = reactively_state_type
        if context_type == TransactionContext:
            assert exclusive is not None, (
                "`exclusive` is required for `TransactionContext`"
            )
            kwargs['exclusive'] = exclusive
            kwargs['database_timestamp_ms'] = self._get_database_timestamp_ms()
        context = context_type(**kwargs)

        # Now toggle 'servicing' to indicate that we are servicing the
        # RPC which will, for example, forbid the construction of a
        # context by raising an error.
        _servicing.set(Servicing.YES)

        return context

    @contextmanager
    def use_context(
        self,
        *,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        context_type: type[ContextT],
        task: Optional[TaskEffect] = None,
    ) -> Iterator[ContextT]:
        """
        Context manager for ensuring that we reset the asyncio context
        variable to the previous context.

        Also ensures that the tracing context is set up correctly.
        """
        context: Optional[Context] = Context.get()
        try:
            with reboot.aio.tracing.context_from_headers(headers):
                yield self.create_context(
                    headers=headers,
                    state_type_name=state_type_name,
                    method=method,
                    context_type=context_type,
                    task=task,
                )
        finally:
            if context is not None:
                Context.set(context)

    async def stop(self):
        """Stop the middleware background tasks.
        """
        await self.tasks_dispatcher.stop()

    def maybe_raise_effect_validation_retry(
        self,
        *,
        logger: Logger,
        idempotency_manager: IdempotencyManager,
        method_name: str,
        validating_effects: bool,
        context: Context,
        checkpoint: Optional[Checkpoint] = None,
    ) -> None:
        """If we're validating effects, explains that we are about to retry, and then raises.
        """
        if self._effect_validation == EffectValidation.DISABLED or validating_effects:
            # Effect validation is disabled, or we are in the second run of an effect
            # validation: either way, allow the method to complete.
            return

        is_non_root_in_nested = (
            # Is either an inner method in a transaction, or a nested transaction.
            (
                not isinstance(context, TransactionContext) and
                context.transaction_id is not None
            ) or
            (isinstance(context, TransactionContext) and context.nested) or
            # Is an inner method in a workflow.
            (
                not isinstance(context, WorkflowContext) and
                context.workflow_id is not None
            ) or
            # Reader called from within a Reboot method. The outermost
            # method's effect-validation re-run will re-invoke this
            # reader, so skip its own validation.
            (isinstance(context, ReaderContext) and context.internal_call)
        )
        if is_non_root_in_nested:
            # When a method is nested (transactions/workflows), retry occurs
            # only at the top level. This is a non-root method below a nested
            # method, so don't retry.
            return

        # Effect validation is enabled, and this method needs to retry: compose
        # a message, log it, and then raise.
        message = (
            f"Re-running method {method_name} to validate effects. "
            f"See {DOCS_BASE_URL}/develop/side_effects for "
            "more information."
        )

        _log_message_for_effect_validation(
            effect_validation=self._effect_validation,
            identifier=method_name,
            timestamps=_has_ever_explained_effect_validation,
            logger=logger,
            message=message,
        )

        # Reset the `IdempotencyManager` so that we re-execute the
        # method as though it is being retried from scratch, unless a
        # checkpoint was provided in which case restore it.
        if checkpoint is None:
            idempotency_manager.reset()
        else:
            idempotency_manager.restore(checkpoint)

        raise EffectValidationRetry()

    @abstractmethod
    async def dispatch(
        self,
        task: TaskEffect,
        *,
        only_validate: bool = False,
    ) -> TaskResponseOrStatus:
        """Abstract dispatch method; implemented by code generation for each
        of the service's task methods."""
        raise NotImplementedError

    @abstractmethod
    async def inspect(self, state_ref: StateRef) -> AsyncIterator[Message]:
        """Abstract method for handling an Inspect request; implemented by code
        generation for each of the services."""
        raise NotImplementedError
        yield  # Necessary for type checking.

    @abstractmethod
    async def react_query(
        self,
        headers: Headers,
        method: str,
        request_bytes: bytes,
    ) -> AsyncIterator[tuple[Optional[Message], list[uuid.UUID]]]:
        """Abstract method for handling a React request; implemented by code
        generation for each of the service's React compatible reader methods."""
        raise NotImplementedError
        yield  # Necessary for type checking.

    @abstractmethod
    async def react_mutate(
        self,
        headers: Headers,
        method: str,
        request_bytes: bytes,
    ) -> Message:
        """Abstract method for handling a React mutation; implemented by code
        generation for each of the service's React compatible mutator methods."""
        raise NotImplementedError

    @abstractmethod
    def add_to_server(self, server: grpc.aio.Server) -> None:
        raise NotImplementedError
