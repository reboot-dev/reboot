import pydantic
import pydantic_core
import re
import types
import typing
from enum import Enum
from google.protobuf import json_format
from google.protobuf.message import Message
from google.protobuf.struct_pb2 import Value
from pydantic.fields import FieldInfo
from reboot.settings import (
    AUTO_CONSTRUCT_METHOD,
    AUTO_CONSTRUCT_STATE_TYPE,
    SET_CLAIMS_METHOD,
)
from typing import (
    Any,
    Dict,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
    get_args,
    get_origin,
)

PRIMITIVE = Union[int, float, str, bool]
PRIMITIVE_TYPE = Union[
    typing.Type[int],
    typing.Type[float],
    typing.Type[str],
    typing.Type[bool],
]

COLLECTION = Union[
    List[Any],
    Dict[str, Any],
]
COLLECTION_TYPE = Union[
    typing.Type[List[Any]],
    typing.Type[Dict[str, Any]],
]


def is_annotation_any(annotation: object) -> bool:
    """Whether `annotation` is the `typing.Any` special form.

    `get_args` on an annotation such as `dict[str, Any]` hands back the
    `typing.Any` object itself, so converters that recurse into
    annotations meet it as a value. Comparing through an `object`-typed
    parameter keeps the comparison legal under `strict_equality` for
    callers whose declared parameter types do not mention `Any`.
    """
    return annotation is Any


# We don't allow passing arbitrary default values, only these empty
# defaults, which also matches with Protobuf semantics.
ALLOWED_DEFAULT_BY_FIELD_TYPE = {
    str: "",
    int: 0,
    float: 0.0,
    bool: False,
    # `None` is allowed for `Optional` fields, but we check that separately.
}

ALLOWED_DEFAULT_FACTORY_BY_FIELD_TYPE: dict[type, type] = {
    list: list,
    dict: dict,
}


class UserPydanticError(Exception):
    """Exception raised in case of a malformed user-provided Pydantic schema."""
    pass


class Model(pydantic.BaseModel):
    """
    Base class for Pydantic request/response/error in Reboot API definitions.
    """
    # We want to ensure that 'validate_assignment=True' for all
    # Model subclasses, so that field types are always validated
    # when they are assigned new values, it is important since we use
    # the Pydantic model type annotation to generate Protobuf messages and
    # if the field value is not of the correct type, the conversion
    # will fail.
    model_config = pydantic.ConfigDict(validate_assignment=True)

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        super().__pydantic_init_subclass__(**kwargs)

        for field_name, field_info in cls.model_fields.items():
            field_type_origin = get_origin(field_info.annotation)

            if field_type_origin is None:
                # If the type has no origin, it is either a primitive type
                # or a `Model`. Otherwise it will be a collection
                # type like `list` or `dict`.
                field_type_origin = field_info.annotation

            assert field_type_origin is not None

            if field_info.default_factory is not None:
                allowed_default_factory = ALLOWED_DEFAULT_FACTORY_BY_FIELD_TYPE.get(
                    field_type_origin,
                    None,
                )

                if allowed_default_factory is None:
                    allowed_types = ', '.join(
                        f'`{allowed_type.__name__}`' for allowed_type in
                        ALLOWED_DEFAULT_FACTORY_BY_FIELD_TYPE.keys()
                    )
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'uses `default_factory` which is not supported for type '
                        f'`{field_type_origin.__name__}`. Only '
                        f'{allowed_types} '
                        'types can have a `default_factory` currently.'
                    )

                if field_type_origin is allowed_default_factory and field_info.default_factory is not allowed_default_factory:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        f'uses `default_factory` with an unsupported value. '
                        f'Supported default factory value for `{allowed_default_factory.__name__}` is `{allowed_default_factory.__name__}`.'
                    )

            is_optional = False
            is_model = False
            is_discriminated_union = False

            if field_type_origin is Union or field_type_origin is types.UnionType:
                args = get_args(field_info.annotation)
                non_none_args = [arg for arg in args if arg is not type(None)]
                if len(non_none_args) != len(args):
                    # When the number of non-None args is different
                    # from the total number of args, this is an
                    # `Optional[T]`, where `T` can be a discriminated union,
                    # but for the purpose of default value checking,
                    # we just need to know that it is `Optional`.
                    is_optional = True
                    nested_optional_type = get_origin(non_none_args[0]
                                                     ) or non_none_args[0]
                    is_model = isinstance(
                        nested_optional_type, type
                    ) and issubclass(nested_optional_type, Model)
                else:
                    is_discriminated_union = True
            else:
                is_model = isinstance(field_type_origin, type) and issubclass(
                    field_type_origin,
                    Model,
                )

            has_default = field_info.default is not pydantic_core.PydanticUndefined

            if has_default:
                # TODO: Write the document about why it is challenging
                # to have default values in the distributed systems
                # and attach the link to the error message.
                if is_discriminated_union:
                    # Discriminated unions cannot have default values,
                    # because its options will be always different
                    # `Model` types and we don't support that currently.
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'is a discriminated union and cannot have a '
                        '`default` value.'
                    )
                elif is_model and not is_optional:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'is a non-optional `Model` type and cannot have a '
                        '`default` value. Use `Optional` for `Model` types '
                        'with empty default.'
                    )
                elif field_info.default is None and not is_optional:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'is a non-optional type and cannot have `default` '
                        'set to `None`. Change the `default` or make the '
                        'field `Optional`.'
                    )
                elif field_info.default is not None and is_optional:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'is `Optional` and uses `default` with a non-None '
                        'value. Reboot supports only `None` default value '
                        'for `Optional` fields.'
                    )
                elif is_optional:
                    # If the field is `Optional` and uses `default=None`,
                    # it is valid, we don't need to check further.
                    continue

                allowed_default = ALLOWED_DEFAULT_BY_FIELD_TYPE.get(
                    field_type_origin,
                    None,
                )

                # The allowed default for `Literal` is the first literal
                # value (according to how Protobuf `enum`s work).
                if field_type_origin is Literal:
                    literal_args = get_args(field_info.annotation)
                    if len(literal_args) == 0:
                        raise UserPydanticError(
                            f'Field `{field_name}` in model `{cls.__name__}` '
                            f'is a `Literal` with no values.'
                        )
                    first_literal = literal_args[0]
                    if field_info.default != first_literal:
                        raise UserPydanticError(
                            f'Field `{field_name}` in model `{cls.__name__}` '
                            f'uses `default` with an unsupported value. '
                            f'Supported default value for `Literal` is the '
                            f'first literal value `{first_literal}`.'
                        )
                    continue
                elif field_type_origin is list or field_type_origin is dict:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        f'is a `{field_type_origin.__name__}` type and cannot '
                        'have a `default` value. Use `default_factory` '
                        'instead.'
                    )
                elif allowed_default is None:
                    allowed_types = ', '.join(
                        f'`{allowed_type.__name__}`' for allowed_type in
                        ALLOWED_DEFAULT_BY_FIELD_TYPE.keys()
                    )
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        'uses `default` which is not supported for type '
                        f'`{field_type_origin.__name__}`. Only '
                        f'{allowed_types}, `Optional` and `Literal` '
                        'types can have a `default` currently.'
                    )
                elif field_info.default != allowed_default:
                    raise UserPydanticError(
                        f'Field `{field_name}` in model `{cls.__name__}` '
                        f'uses `default` with an unsupported value. '
                        f'Supported default value for `{field_type_origin.__name__}` is `{allowed_default}`.'
                    )


def _get_discriminated_union_info(
    field_type: type,
    field_info: Optional[FieldInfo] = None,
) -> Optional[Tuple[str, list[type[Model]]]]:
    """
    Check if a field type is a discriminated union and return info about it.

    Returns:
        A tuple of (discriminator_field_name, list_of_type_args) if
        it's a discriminated union, None otherwise.
    """
    origin = get_origin(field_type)
    if origin is not Union and origin is not types.UnionType:
        return None

    # Get the discriminator from `field_info` if available.
    discriminator = None
    if field_info is not None:
        discriminator = field_info.discriminator

    if discriminator is None:
        return None

    # Reboot only supports the string-name form of pydantic
    # discriminators (the field name); callable `Discriminator`
    # instances aren't supported.
    assert isinstance(discriminator, str)

    # Get all non-None args, since it might be an optional discriminated union.
    non_none_args = [
        arg for arg in get_args(field_type) if arg is not type(None)
    ]

    # A discriminated union must have at least 2 options.
    assert len(non_none_args) >= 2

    return (discriminator, non_none_args)


def _pydantic_to_proto(
    input: Model | PRIMITIVE | COLLECTION | None,
    input_type: Optional[typing.Type],
    # We always will return lists, dicts and BaseModels as proto messages.
    output_type: typing.Type[Message] | PRIMITIVE_TYPE,
    field_info: Optional[FieldInfo] = None,
) -> Message | PRIMITIVE:
    """Converts a Pydantic 'input' of type 'input_type' to the
    'output_type' Protobuf message or primitive type.

    We use that function to convert user defined Pydantic values to the
    generated Protobuf messages that Reboot uses internally.

    While generating Protobuf code we check that every type has fully
    defined annotations (i.e. 'list[str]' instead of just 'list'), so we
    can use 'get_args' and 'get_origin' to extract the actual types.

    According to the way we generate Protobuf messages, we currently
    do not support nested optional types inside collections, i.e.
    'list[Optional[T]]' or 'dict[str, Optional[T]]'.

    The only place where 'Optional[T]' is supported is for fields
    directly in Pydantic BaseModels.

    # NOTE: Do not call that function directly, use 'pydantic_to_proto'
    # instead. If you have to call it directly, make sure that the 'input'
    # Model has the same structure as expected by the 'output_type' and
    # if 'input' is 'Model' it should be validated.
    """
    input_type_or_origin = get_origin(input_type)
    if input_type_or_origin is None:
        # If the type has no origin, it is either a primitive type
        # or a 'Model'. Otherwise it will be a collection
        # type like 'list' or 'dict'.
        input_type_or_origin = input_type

    if input_type is Any:
        # An `Any`-typed value — e.g. a `dict[str, Any]` map value —
        # is carried on the wire as a `google.protobuf.Value`, which
        # represents any JSON value: `null`, a number, a string, a
        # bool, a list, or an object.
        return json_format.ParseDict(input, Value())

    if input_type_or_origin is Union or input_type_or_origin is types.UnionType:
        # It might be a discriminated union or an `Optional[T]`.
        assert input_type is not None
        discriminated_union_info = _get_discriminated_union_info(
            input_type,  # type: ignore[arg-type]
            field_info,
        )

        if discriminated_union_info is None:
            # If `discriminated_union_info` is `None`, that means that
            # the corresponding `FieldInfo` does not have a `discriminator`
            # and we can treat this as an `Optional[T]`.
            non_none_args = [
                arg for arg in get_args(input_type) if arg is not type(None)
            ]
            assert len(non_none_args) == 1
            input_type = non_none_args[0]
            return _pydantic_to_proto(
                input,
                input_type,
                output_type,
            )

        discriminator, type_args = discriminated_union_info
        assert isinstance(input, Model)

        # The `output_type` must be a Protobuf message with a oneof.
        assert isinstance(output_type, type) and issubclass(
            output_type,
            Message,
        )

        # Get the discriminator value from the input.
        discriminator_value = getattr(input, discriminator)

        # Find the matching option type.
        for type_arg in type_args:
            literal_field = type_arg.model_fields.get(discriminator)
            assert literal_field is not None
            literal_args = get_args(literal_field.annotation)
            assert len(literal_args) == 1

            if literal_args[0] != discriminator_value:
                # It is not the matching option, skip it.
                continue

            # Found matching option, convert it.
            output = output_type()

            # The oneof field name is the lower-cased discriminator value.
            oneof_field_name = to_snake_case(discriminator_value)

            # Get the nested message for this option.
            output_message = getattr(output, oneof_field_name)

            # Convert the option excluding the discriminator field,
            # we do it as a separate loop since the discriminator field
            # exists only in the Pydantic model, not in the Protobuf message.
            for (
                field_name,
                option_field_info,
            ) in type_arg.model_fields.items():
                # Skip the discriminator field.
                if field_name == discriminator:
                    continue

                input_field = getattr(input, field_name)
                if input_field is None:
                    continue

                input_field_type = option_field_info.annotation
                output_message_field = getattr(
                    output_message,
                    field_name,
                )
                nested_output = _pydantic_to_proto(
                    input_field,
                    input_field_type,
                    type(output_message_field),
                    option_field_info,
                )

                if isinstance(nested_output, Message):
                    output_message_field.CopyFrom(nested_output)
                else:
                    setattr(
                        output_message,
                        field_name,
                        nested_output,
                    )

            return output

        raise ValueError(
            f"No matching option found for discriminator value "
            f"`{discriminator_value}` in discriminated union."
        )

    if input_type_or_origin is Literal:
        literal_args = get_args(input_type)
        assert input in literal_args, f"Value `{input}` not in `Literal{literal_args}`"
        return literal_args.index(input)

    # Assert that we have a valid type after we check for `Union` and `Literal`,
    # since those are special typing constructs and not "real" types.
    assert isinstance(input_type_or_origin, type)

    if input_type_or_origin is list:
        # Ensure 'output_type' is a class (not a Union of primitive
        # types), so we can safely call 'output_type' as a class inside
        # 'issubclass', so mypy can properly check types.
        assert isinstance(output_type, type) and issubclass(
            output_type,
            Message,
        )

        output = output_type()

        assert hasattr(output, 'items')
        assert isinstance(input, list)
        list_args = get_args(input_type)
        # We should always have exactly one argument for lists.
        assert len(list_args) == 1
        list_item_type = list_args[0]

        list_item_origin = get_origin(list_item_type)

        for list_item in input:
            # For 'RepeatedScalarContainer' there is no 'add' method, so
            # we need to handle scalar containers separately.
            if list_item_type in (int, float, str, bool):
                # Primitive type, we can append directly.
                output.items.append(list_item)
            elif list_item_origin is Literal:
                # 'Literal' items become a 'repeated' Protobuf 'enum', so
                # append the literal's index like a plain scalar.
                output.items.append(
                    _pydantic_to_proto(list_item, list_item_type, int)
                )
            else:
                output_item = output.items.add()
                nested_output = _pydantic_to_proto(
                    list_item,
                    list_item_type,
                    type(output_item),
                )
                assert isinstance(nested_output, Message)
                output_item.CopyFrom(nested_output)
        return output
    elif input_type_or_origin is dict:
        # Ensure 'output_type' is a class (not a Union of primitive
        # types), so we can safely call 'output_type' as a class inside
        # 'issubclass', so mypy can properly check types.
        assert isinstance(output_type, type) and issubclass(
            output_type,
            Message,
        )

        output = output_type()

        assert hasattr(output, 'record')
        assert isinstance(input, dict)
        dict_args = get_args(input_type)
        # We should always have exactly two arguments for dicts.
        assert len(dict_args) == 2
        dict_value_type = dict_args[1]

        dict_value_origin = get_origin(dict_value_type)

        for key, value in input.items():
            # For map fields, we use dictionary-style assignment instead
            # of 'add()' or 'append()'. Scalar map values use direct
            # assignment while message map values should use 'CopyFrom()'.
            if dict_value_type in (int, float, str, bool):
                # Primitive type, we can assign directly.
                output.record[key] = value
            elif dict_value_origin is Literal:
                # 'Literal' values become a 'map' with a Protobuf
                # 'enum' value type; assign the literal's index.
                output.record[key] = _pydantic_to_proto(
                    value, dict_value_type, int
                )
            else:
                output_value = output.record[key]
                nested_output = _pydantic_to_proto(
                    value,
                    dict_value_type,
                    type(output_value),
                )
                assert isinstance(nested_output, Message)
                output_value.CopyFrom(nested_output)
        return output
    elif issubclass(input_type_or_origin, Model):
        assert isinstance(output_type, type(Message))
        assert isinstance(input, Model)

        output = output_type()

        for field_name, field_info in type(input).model_fields.items():
            try:
                # If we were constructing the Pydantic model for initial
                # state, that model will not have any fields, since we
                # create it with 'model_construct' and then user should
                # set the required fields manually. If a required field is
                # missing, we will get an AttributeError here and we can
                # raise a proper ValidationError.
                input_field = getattr(input, field_name)
            except AttributeError:
                raise pydantic_core.ValidationError.from_exception_data(
                    title=
                    f"Missing required field {field_name} in {type(input).__name__}",
                    line_errors=[
                        {
                            'type': 'missing',
                            'loc': (field_name,),
                            # The 'input' field is required by the
                            # ValidationError but we don't have
                            # the actual input value here, so we will
                            # show an empty value, e.g.:
                            #
                            # 'field_name'
                            # Field required [type=missing, input_value='input_type()', input_type='input_type']
                            #    For further information visit https://errors.pydantic.dev/2.12/v/missing
                            'input': input,
                        }
                    ]
                )
            if input_field is None:
                # If the Pydantic field is 'None', we skip setting it
                # in the Protobuf message, because Protobuf fields are
                # 'optional' by default.
                continue

            input_field_type = field_info.annotation

            output_field = getattr(output, field_name)
            nested_output = _pydantic_to_proto(
                input_field,
                input_field_type,
                type(output_field),
                field_info,
            )

            # We can't call 'setattr' on the message types in Protobuf.
            if isinstance(nested_output, Message):
                assert output_type.DESCRIPTOR.fields_by_name.get(
                    field_name
                ).message_type is not None

                output_field.CopyFrom(nested_output)
            else:
                assert output_type.DESCRIPTOR.fields_by_name.get(
                    field_name
                ).message_type is None

                setattr(output, field_name, nested_output)

        return output
    elif issubclass(input_type_or_origin, (int, float, str, bool)):
        assert isinstance(input, (int, float, str, bool))
        return input
    else:
        raise ValueError(
            f"Unexpected input type in '_pydantic_to_proto'. "
            f"Expected 'Model', 'list', 'dict' or primitive type for output '{output_type}' "
            f"but got '{input}' of type '{input_type}'."
        )


def pydantic_to_proto(
    input: Model,
    input_type: typing.Type[Model],
    output_type: typing.Type[Message],
):
    """Converts a Pydantic 'input' of type 'input_type' to the
    'output_type' Protobuf message. The function expects 'input' to be
    a value of type 'Model', which ensures 'validate_assignment=True',
    so the input is already validated except the case when the input is created
    using 'model_construct' (e.g. for initial state creation), for that case
    we check that required fields are set and if not we raise a proper
    ValidationError in '_pydantic_to_proto'. The field type will still
    be checked by Pydantic, since we ensure 'validate_assignment=True'.
    """
    return _pydantic_to_proto(
        input,
        input_type,
        output_type,
    )


def _proto_to_pydantic(
    input: Message | PRIMITIVE,
    output_type: typing.Type[Model] | PRIMITIVE_TYPE | COLLECTION_TYPE | None,
    field_info: Optional[FieldInfo] = None,
) -> Model | PRIMITIVE | COLLECTION | None:
    """Converts a Protobuf 'input' message or primitive type to the
    'output_type' Model, list, dict or primitive type.

    We use that function to convert Reboot generated Protobuf messages
    to user defined Pydantic values.

    While generating Protobuf code we check that every type has fully
    defined annotations (i.e. 'list[str]' instead of just 'list'), so we
    can use 'get_args' and 'get_origin' to extract the actual types.

    According to the way we generate Protobuf messages, we currently
    do not support nested optional types inside collections, i.e.
    'list[Optional[T]]' or 'dict[str, Optional[T]]'.
    The only place where 'Optional[T]' is supported is for fields
    directly in Pydantic BaseModels.

    NOTE: Do not call that function directly, use 'proto_to_pydantic'
    instead. If you have to call it directly, make sure that the 'input'
    Message has the same structure as expected by the 'output_type' and
    has all required fields set.
    """
    if output_type is None:
        # If a user specifies 'response=None' in the method definition,
        # we don't want to create an arbitrary data structure, but return
        # 'None' directly.
        return None

    if is_annotation_any(output_type):
        # Reverse of the `Any` case in `_pydantic_to_proto`: a
        # `google.protobuf.Value` becomes the JSON value it holds.
        assert isinstance(input, Value)
        return json_format.MessageToDict(input)

    output_type_or_origin = get_origin(output_type)

    if output_type_or_origin is None:
        # If the type has no origin, it is either a primitive type
        # or a 'Model'. Otherwise it will be a collection
        # type like 'list' or 'dict'.
        output_type_or_origin = output_type

    # `mypy` complains that 'output' is possibly redefined across different
    # branches, so we define it here once.
    output: Union[list[Any], dict[str, Any]]

    if output_type_or_origin is Union or output_type_or_origin is types.UnionType:
        # Check if this is a discriminated union.
        discriminated_union_info = _get_discriminated_union_info(
            output_type,  # type: ignore[arg-type]
            field_info,
        )

        if discriminated_union_info is None:
            # If `discriminated_union_info` is `None`, that means that
            # the corresponding `FieldInfo` does not have a `discriminator`
            # and we can treat this as an `Optional[T]`.
            non_none_args = [
                arg for arg in get_args(output_type) if arg is not type(None)
            ]
            assert len(non_none_args) == 1
            output_type = non_none_args[0]
            return _proto_to_pydantic(
                input,
                output_type,
            )

        discriminator, type_args = discriminated_union_info
        assert isinstance(input, Message)

        # Find which oneof case is set by checking the DESCRIPTOR.
        # The oneof field name should match the discriminator.
        oneof = input.DESCRIPTOR.oneofs_by_name.get(discriminator)
        assert oneof is not None, (
            f"Expected oneof '{discriminator}' in proto message"
        )

        # Get the currently set field in the oneof.
        current_field = input.WhichOneof(discriminator)
        if current_field is None:
            return None

        # The oneof field name corresponds to the snake_case of
        # the discriminator value.
        # Find the matching option type.
        for type_arg in type_args:
            literal_field = type_arg.model_fields.get(discriminator)
            assert literal_field is not None
            literal_args = get_args(literal_field.annotation)
            assert len(literal_args) == 1

            expected_oneof_name = to_snake_case(literal_args[0])
            if expected_oneof_name != current_field:
                # It is not the matching option, skip it.
                continue

            # Found matching option, convert it.
            proto_field = getattr(input, current_field)
            output = {}

            # Set the discriminator value.
            output[discriminator] = literal_args[0]

            # Convert the option excluding the discriminator field,
            # we do it as a separate loop since the discriminator field
            # exists only in the Pydantic model, not in the Protobuf message.
            for (
                field_name,
                option_field_info,
            ) in type_arg.model_fields.items():
                if field_name == discriminator:
                    continue

                if proto_field.HasField(field_name):
                    option_input_field = getattr(
                        proto_field,
                        field_name,
                    )
                    output[field_name] = _proto_to_pydantic(
                        option_input_field,
                        option_field_info.annotation,
                        option_field_info,
                    )
                else:
                    output[field_name] = None

            return type_arg(**output)

        raise ValueError(
            f"No matching option found for oneof case `{current_field}` "
            f"in discriminated union with discriminator `{discriminator}`."
        )

    if output_type_or_origin is Literal:
        # TODO: In the PR for support defaults, make sure we support the
        # first `Literal` option as the default value.
        literal_args = get_args(output_type)
        assert isinstance(
            input, int
        ), f"Expected `int` for `Literal`, got `{type(input)}`"
        assert 0 <= input < len(
            literal_args
        ), f"Enum value `{input}` out of range for `Literal{literal_args}`"
        return literal_args[input]

    # Assert that we have a valid type after we check for `Union` and `Literal`,
    # since those are special typing constructs and not "real" types.
    assert isinstance(output_type_or_origin, type)

    if output_type_or_origin is list:
        assert isinstance(input, Message)
        assert hasattr(input, 'items')
        list_args = get_args(output_type)
        # We should always have exactly one argument for lists.
        assert len(list_args) == 1
        list_item_type = list_args[0]
        output = []
        for list_item in input.items:
            output.append(_proto_to_pydantic(
                list_item,
                list_item_type,
            ))
        return output
    elif output_type_or_origin is dict:
        assert isinstance(input, Message)
        assert hasattr(input, 'record')
        dict_args = get_args(output_type)
        # We should always have exactly two arguments for dicts.
        assert len(dict_args) == 2
        dict_value_type = dict_args[1]
        output = {}
        for key, value in input.record.items():
            output[key] = _proto_to_pydantic(
                value,
                dict_value_type,
            )
        return output
    elif issubclass(output_type_or_origin, Model):
        # Ensure 'output_type' is a class (not a Union of primitive
        # types), so we can safely call 'output_type' as a class inside
        # 'issubclass', so mypy can properly check types.
        assert isinstance(output_type, type) and issubclass(output_type, Model)
        assert isinstance(input, Message)

        output = {}

        for field_name, field_info in output_type.model_fields.items():
            input_field = getattr(input, field_name)
            output_field_type = field_info.annotation

            if input.HasField(field_name):
                # Always set the field if it is present in the
                # Protobuf message.
                output[field_name] = _proto_to_pydantic(
                    input_field,
                    output_field_type,
                    field_info,
                )
            else:
                # We should be converting a Protobuf message which was
                # created from a Pydantic model so if a field is not set
                # in the Protobuf message, it means that the field was
                # 'Optional' and set to 'None' in Pydantic or if it was
                # a required field, it was missing we allow Pydantic to
                # either set a default value or raise a validation error
                # on the calling side.
                output_field_type_origin = get_origin(output_field_type)
                if output_field_type_origin is Union or output_field_type_origin is types.UnionType:
                    if type(None) in get_args(output_field_type):
                        # Union which has `NoneType` as one of the args
                        # is treated as an `Optional[T]` and we set
                        # the field to `None` explicitly.
                        output[field_name] = None
                        continue

        return output_type(**output)

    elif issubclass(output_type_or_origin, (float, str, bool)):
        assert isinstance(input, (float, str, bool))
        return input
    elif issubclass(output_type_or_origin, int):
        # We map Python 'int' to Protobuf 'double', so we need to
        # truncate the float value back to int here.
        assert isinstance(input, (int, float))
        return int(input)
    else:
        raise ValueError(
            f"Unexpected output type in '_proto_to_pydantic'. "
            f"Expected 'Model', 'list', 'dict' or primitive type for input '{input}' "
            f"but got '{output_type}'."
        )


def proto_to_pydantic(
    input: Message,
    output_type: typing.Type[Model],
):
    """Converts a Protobuf 'input' message to the
    'output_type' Model. Since the 'output_type' is a Pydantic
    model, we are sure that Pydantic validation will be done during
    the 'output_type' object creation.
    """

    return _proto_to_pydantic(
        input,
        output_type,
    )


def Field(*, tag: int, **kwargs) -> Any:
    """
    Helper function to create a Pydantic Field with protobuf tag number.
    """
    json_schema_extra = kwargs.get('json_schema_extra', {})
    json_schema_extra['tag'] = tag
    kwargs['json_schema_extra'] = json_schema_extra
    return pydantic.Field(**kwargs)


class MethodKind(str, Enum):
    WRITER = "writer"
    READER = "reader"
    TRANSACTION = "transaction"
    WORKFLOW = "workflow"


class Tool(pydantic.BaseModel):
    """
    Expose a method as an MCP tool.
    """
    name: Optional[str] = None
    title: Optional[str] = None


class Resource(pydantic.BaseModel):
    """
    Expose a method as an MCP resource.
    """
    name: Optional[str] = None
    title: Optional[str] = None


class UI(pydantic.BaseModel):
    """UI method type.

    Generates an MCP tool that triggers UI display, and
    an MCP resource that serves the UI's HTML. Unlike
    Reader/Writer, UI methods have no backend servicer.

    `path` is the UI's URL path under Reboot's `/__/frontend/mcp/`,
    such as `"clicker"` or `"shop/cart"`: in development the
    frontend's dev server (`--frontend-url`) serves it at
    `/__/frontend/mcp/clicker/`, and built it is
    `<--mcp-app-dist-path>/clicker/index.html`. It is not a
    directory in the project; the method name is the UI's identity.

    The `request` type defines the React component's
    props. There is no `response` -- the tool triggers
    UI display and the React component handles rendering.
    """
    request: Optional[typing.Type[Model]]
    path: str
    title: Optional[str] = None
    description: Optional[str] = None

    @pydantic.field_validator('path')
    @classmethod
    def _validate_path(cls, path: str) -> str:
        segments = path.split('/')
        # The form `path` used to take, a directory relative to the
        # project root (`frontend/mcp/clicker`), or that directory
        # with just the frontend stripped off (`mcp/clicker`).
        if len(segments) > 1 and segments[0] in ('frontend', 'mcp'):
            raise ValueError(
                f"'{path}' is not a valid `UI(path=...)`: it is the UI's "
                "URL path under `/__/frontend/mcp/`, such as "
                f"`path=\"{segments[-1]}\"`, not a directory in the "
                "project. The frontend's dev server serves the UI there, "
                "and its build is at "
                "`<--mcp-app-dist-path>/<path>/index.html`."
            )
        if any(segment in ('', '.', '..') for segment in segments):
            raise ValueError(
                f"'{path}' is not a valid `UI(path=...)`: give the UI's "
                "URL path under `/__/frontend/mcp/`, with no leading or "
                "trailing slash, e.g. `path=\"clicker\"` or "
                "`path=\"shop/cart\"`."
            )
        return path


class MethodModel(pydantic.BaseModel):
    """
    Base class for method type definitions in Reboot API.
    Contains common fields for all method types
    (Reader, Writer, Transaction, Workflow).
    """
    request: Optional[typing.Type[Model]]
    response: Optional[typing.Type[Model]]
    errors: list[typing.Type[Model]] = []
    description: Optional[str] = None
    factory: bool = False
    kind: MethodKind
    mcp: Optional[Tool]

    # TODO(rjh): we need more experience with resources
    #            in the context of MCP Apps before
    #            officially supporting them in Reboot. It
    #            seems that many (most? all?) LLMs do not
    #            use available resources in responses to
    #            end-user requests, which would make them
    #            essentially useless.
    @pydantic.model_validator(mode='before')
    @classmethod
    def _reject_resource(cls, values):
        if isinstance(values.get('mcp'), Resource):
            raise ValueError(
                "'Resource()' is not yet supported; "
                "use 'Tool()' instead"
            )
        return values


class Writer(MethodModel):
    kind: MethodKind = MethodKind.WRITER


class Reader(MethodModel):
    kind: MethodKind = MethodKind.READER


class Exclusive(pydantic.BaseModel):
    """A `Transaction(...)`'s `mode=`: the transaction takes the lock on
    its own state exclusive from the start, so that concurrent callers
    of the same state queue behind it. The choice for a transaction
    that writes its own state, which is most of them: two such
    transactions can never run to completion concurrently anyway, and
    starting shared is what lets them deadlock on the upgrade.
    """


class Shared(pydantic.BaseModel):
    """A `Transaction(...)`'s `mode=`: the transaction takes the lock on
    its own state shared and upgrades it to exclusive only if it writes
    its own state, so that callers proceed concurrently while none of
    them writes it. The choice for a transaction that mostly reads its
    own state while writing others, such as the root of a tree of
    states that every call descends through.
    """


class Transaction(MethodModel):
    kind: MethodKind = MethodKind.TRANSACTION
    # How the transaction holds the lock on its own state while it
    # runs, `Exclusive()` or `Shared()`. Required; `Type` refuses a
    # transaction that has not chosen one, so that the choice is made
    # rather than defaulted.
    mode: Optional[Union[Exclusive, Shared]] = None


class Workflow(MethodModel):
    kind: MethodKind = MethodKind.WORKFLOW


MethodType = Union[Writer, Reader, Transaction, Workflow, UI]


def is_snake_case(input: str) -> bool:
    return re.match(r'^[a-z0-9]+(_[a-z0-9]+)*$', input) is not None


def to_snake_case(input: str) -> str:
    snake_case_words = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', input)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', snake_case_words).lower()


def to_pascal_case(input: str) -> str:
    """Convert snake_case to PascalCase."""
    return ''.join(word.capitalize() for word in input.split('_'))


def snake_to_camel(snake_str: str) -> str:
    """Convert snake_case to camelCase."""
    components = snake_str.split('_')
    return components[0] + ''.join(
        word.capitalize() for word in components[1:]
    )


def get_field_tag(field_info) -> Optional[int]:
    """Get the tag from a Pydantic field's json_schema_extra."""
    json_schema_extra = getattr(field_info, 'json_schema_extra', {})
    if isinstance(json_schema_extra, dict) and 'tag' in json_schema_extra:
        return json_schema_extra['tag']
    return None


# We need to define 'Methods' as a class, so Python typing can
# properly identify it as a type for 'Type.methods' field.
# Otherwise we will see error like:
# Argument "methods" to "Type" has incompatible type
# "dict[str, MethodModel]"; expected "dict[str, Writer | Reader
# | Transaction | Workflow]".
class Methods(dict[str, MethodType]):

    def __init__(self, **methods: MethodType):
        super().__init__(**methods)


class Type(pydantic.BaseModel):
    """Represents a Reboot data type with state and methods."""

    # 'Methods' is a dict, so we need to allow arbitrary types
    # to avoid Pydantic validation errors.
    model_config = pydantic.ConfigDict(
        arbitrary_types_allowed=True,
    )

    state: typing.Type[Model]
    methods: Methods
    description: Optional[str] = None

    def __init__(
        self,
        *,
        state: typing.Type[Model],
        methods: Methods,
        description: Optional[str] = None,
    ):

        def validate_all_fields_are_reboot_base_classes(
            field_type,
            method_name,
            field_info: Optional[FieldInfo] = None,
        ):
            field_type_origin = get_origin(field_type)
            if field_type_origin is Union or field_type_origin is types.UnionType:
                discriminated_union_info = _get_discriminated_union_info(
                    field_type,  # type: ignore[arg-type]
                    field_info,
                )
                if discriminated_union_info is not None:
                    # Check if this is a discriminated union and
                    # validate all option types.
                    discriminator, type_args = discriminated_union_info
                    for type_arg in type_args:
                        if discriminator not in type_arg.__annotations__:
                            raise UserPydanticError(
                                f"Discriminated union option type "
                                f"`{type_arg}` is missing "
                                f"discriminator field `{discriminator}`."
                            )
                        literal_field = type_arg.model_fields.get(
                            discriminator
                        )
                        assert literal_field is not None
                        literal_args = get_args(literal_field.annotation)
                        if len(literal_args) != 1:
                            raise UserPydanticError(
                                f"Discriminator field `{discriminator}` "
                                f"in option type `{type_arg}` must be "
                                f"a `Literal` with exactly one value."
                            )

                        validate_all_fields_are_reboot_base_classes(
                            type_arg,
                            method_name,
                        )
                else:
                    # If `discriminated_union_info` is `None`, that means that
                    # the corresponding `FieldInfo` does not have a `discriminator`
                    # and we can treat this as an `Optional[T]`.
                    non_none_args = [
                        arg for arg in get_args(field_type)
                        if arg is not type(None)
                    ]
                    assert len(non_none_args) == 1
                    return validate_all_fields_are_reboot_base_classes(
                        non_none_args[0],
                        method_name,
                    )
            elif field_type_origin is list:
                list_args = get_args(field_type)
                # We should always have exactly one argument for lists.
                assert len(list_args) == 1
                return validate_all_fields_are_reboot_base_classes(
                    list_args[0],
                    method_name,
                )
            elif field_type_origin is dict:
                dict_args = get_args(field_type)
                # We should always have exactly two arguments for dicts.
                assert len(dict_args) == 2
                return validate_all_fields_are_reboot_base_classes(
                    dict_args[1],
                    method_name,
                )
            elif field_type_origin is Literal:
                # We support only string literals for now.
                literal_args = get_args(field_type)
                for arg in literal_args:
                    if not isinstance(arg, str):
                        state_or_method = "'state'" if method_name is None else f"method '{method_name}'"
                        raise UserPydanticError(
                            f"{state_or_method} has `Literal` field with "
                            f"non-string value `{arg}`. Only string "
                            "literals are supported."
                        )
            elif field_type is Any:
                # `dict[str, Any]` becomes a Protobuf `map<string,
                # google.protobuf.Value>` carrying arbitrary JSON
                # values; the value type needs no further validation.
                pass
            elif issubclass(field_type, pydantic.BaseModel):
                if not issubclass(field_type, Model):
                    state_or_method = ""
                    if method_name is None:
                        state_or_method = "'state'"
                    else:
                        state_or_method = f"method '{method_name}'"
                    raise UserPydanticError(
                        f"{state_or_method} has field type "
                        f"'{field_type}' which is not a subclass of "
                        "Reboot 'Model'. All 'state', "
                        "'request', 'response', and 'error' "
                        "types must inherit from 'Model'."
                    )
                for field_info in field_type.model_fields.values():
                    validate_all_fields_are_reboot_base_classes(
                        field_info.annotation,
                        method_name,
                        field_info,
                    )
            else:
                assert field_type in (int, float, str, bool)

        if not issubclass(state, Model):
            raise UserPydanticError("'state' must be a subclass of 'Model'.")

        # Validate all fields there rather then in the constructor of
        # 'Model', so that we won't have that validation
        # overhead in the runtime on the server, but only during
        # API definition time.
        validate_all_fields_are_reboot_base_classes(
            state,
            None,
        )

        for method_name, method in methods.items():
            if isinstance(method, UI):
                # UI methods only have a request type.
                if method.request is not None:
                    validate_all_fields_are_reboot_base_classes(
                        method.request,
                        method_name,
                    )
            elif isinstance(method, MethodModel):
                if isinstance(method, Transaction) and method.mode is None:
                    raise UserPydanticError(
                        f"Transaction '{method_name}' does not say how it "
                        "holds the lock on its own state while it runs. "
                        "Every transaction must declare one of:\n"
                        "  mode=Exclusive() takes the lock exclusive from "
                        "the start, so that concurrent callers of the same "
                        "state queue behind it. The choice for a "
                        "transaction that writes its own state, which is "
                        "most of them.\n"
                        "  mode=Shared() takes the lock shared and upgrades "
                        "it to exclusive only if the transaction writes its "
                        "own state, so that callers proceed concurrently "
                        "while none of them writes it. The choice for a "
                        "transaction that mostly reads its own state while "
                        "writing others."
                    )
                if method.request is not None:
                    validate_all_fields_are_reboot_base_classes(
                        method.request,
                        method_name,
                    )
                if method.response is not None:
                    validate_all_fields_are_reboot_base_classes(
                        method.response,
                        method_name,
                    )
                for error in method.errors:
                    validate_all_fields_are_reboot_base_classes(
                        error,
                        method_name,
                    )
            else:
                raise UserPydanticError(
                    f"Method '{method_name}' must be an instance of "
                    f"'Writer', 'Reader', 'Transaction', "
                    f"'Workflow', or 'UI'."
                )

        super().__init__(
            state=state,
            methods=methods,
            description=description,
        )


class SetClaimsRequest(Model):
    """Request for the `set_claims` method the framework injects on
    auto-constructed state types. The framework fills it in when it
    delivers a user's verified identity claims at sign-in; it is not
    meant to be built by application code.
    """
    # The user's verified identity claims, keyed by their presented
    # names. A `dict[str, Any]` (a `map<string, google.protobuf.Value>`
    # on the wire) so it carries free-form JSON claim values verbatim
    # and stays decoupled from whatever claims the identity provider
    # was configured to deliver.
    claims: dict[str, Any] = Field(tag=1, default_factory=dict)


class API(pydantic.BaseModel):
    """Main API definition containing multiple Reboot data types.
    We set extra='allow' to permit dynamic data type fields, i.e.
    'api.ServiceName.state' or
    'api.ServiceName.methods['MethodName'].request'."""

    # Allow dynamic data type fields (e.g., API(StateOne=Type(...),
    # StateTwo=Type(...))). Without this, Pydantic would reject unknown
    # fields in '__init__(**types)'.
    model_config = pydantic.ConfigDict(extra='allow')

    if typing.TYPE_CHECKING:
        # The types are extra fields, e.g. `api.Shop`, which pydantic
        # serves from a `__getattr__` it only defines at runtime.
        def __getattr__(self, name: str) -> Type:
            ...

    def __init__(self, **types: Optional[Type]):
        for type_name, data_type in types.items():
            if data_type is None:
                continue

            if not isinstance(data_type, Type):
                raise UserPydanticError(
                    f"Data type '{type_name}' must be a 'Type' instance, "
                    f"got '{data_type.__class__.__name__}'"
                )

            # The auto-constructed state type, if present, is
            # special: it will be auto-constructed by Reboot as
            # needed. To support that, we inject a `create`
            # constructor method. The name was picked to be
            # self-explanatory, and to avoid the word "new" which
            # is a reserved keyword in TypeScript. If the customer
            # has defined their own `create` method we give a
            # helpful error explaining that that's not allowed,
            # but they can override the default implementation
            # with custom initialization logic in their servicer.
            if type_name == AUTO_CONSTRUCT_STATE_TYPE:
                # Validate that all state fields have defaults,
                # or are optional — auto-constructed state
                # instances are created without arguments, which
                # must produce a valid state.
                for field_name, field_info in (
                    data_type.state.model_fields.items()
                ):
                    has_default = (
                        field_info.default
                        is not pydantic_core.PydanticUndefined or
                        field_info.default_factory is not None
                    )
                    # Optional fields are also acceptable: they
                    # default to `None` during
                    # auto-construction.
                    args = get_args(field_info.annotation)
                    is_optional = any(a is type(None) for a in args)
                    if not has_default and not is_optional:
                        raise UserPydanticError(
                            f"Field `{field_name}` in "
                            f"{type_name} state model "
                            f"`{data_type.state.__name__}` "
                            "must have a default value, or "
                            "be optional. "
                            f"{type_name} instances are "
                            "auto-constructed, in their "
                            "default (empty) state, and such a "
                            "fresh state must be valid."
                        )

                if AUTO_CONSTRUCT_METHOD in data_type.methods:
                    raise UserPydanticError(
                        f"'{AUTO_CONSTRUCT_METHOD}' is a "
                        "reserved method name for "
                        f"{type_name} types. If you want "
                        "custom initialization logic, "
                        "override the default "
                        f"'{AUTO_CONSTRUCT_METHOD}' "
                        "Transaction in your servicer "
                        "implementation instead of declaring "
                        "it in the API definition. You may "
                        "also declare alternative factory "
                        "methods for your own use, but note "
                        "the system will always use "
                        f"'{AUTO_CONSTRUCT_METHOD}' when "
                        "automatically constructing a "
                        f"'{type_name}' for a new AI "
                        "session."
                    )
                if SET_CLAIMS_METHOD in data_type.methods:
                    raise UserPydanticError(
                        f"'{SET_CLAIMS_METHOD}' is a "
                        "reserved method name for "
                        f"{type_name} types: the framework "
                        "calls it to deliver a user's "
                        "verified identity claims. If you "
                        "want to act on those claims, "
                        f"override the default "
                        f"'{SET_CLAIMS_METHOD}' Transaction "
                        "in your servicer implementation "
                        "instead of declaring it in the API "
                        "definition."
                    )
                # The auto-constructed `create` is a `Transaction`, so
                # that a servicer overriding it can call other state
                # machines while constructing a `User`, e.g. "when a
                # `User` is created, also create a `Cart`".
                data_type.methods[AUTO_CONSTRUCT_METHOD] = Transaction(
                    request=None,
                    response=None,
                    factory=True,
                    # Constructing the state always writes it.
                    mode=Exclusive(),
                    # The `User.create` method is reserved for auto
                    # construction a `User` state for new AI session. It
                    # is called by the Reboot internally and shouldn't
                    # be exposed as an MCP tool so others can't call it
                    # directly.
                    mcp=None,
                )
                # The `set_claims` method delivers the user's verified
                # identity claims. It is a `Transaction` (like
                # `create`) so a servicer overriding it can call other
                # state machines. It is a plain method, not a
                # constructor: the framework calls it only after
                # `create` has brought the state into existence.
                data_type.methods[SET_CLAIMS_METHOD] = Transaction(
                    request=SetClaimsRequest,
                    response=None,
                    factory=False,
                    # Storing the claims writes the state.
                    mode=Exclusive(),
                    # `set_claims` is only called app-internal, so never
                    # over MCP.
                    mcp=None,
                )

        # Only pass non-None types to Pydantic.
        super().__init__(**{k: v for k, v in types.items() if v is not None})

    def get_types(self) -> Dict[str, Type]:
        """Get all Reboot data types defined in this API."""
        types = {}
        # Iterate `__pydantic_extra__`, which preserves the order in
        # which the types were passed to `API(...)`, rather than
        # `model_fields_set`, which is a `set` whose iteration order
        # is randomized per process. The types' order flows through
        # to the synthesized `.proto` and thus the generated code, so
        # a stable order keeps generated output deterministic.
        for field_name, field_value in (self.__pydantic_extra__ or {}).items():
            if isinstance(field_value, Type):
                types[field_name] = field_value

        return types
