import os
from contextlib import asynccontextmanager
from enum import Enum
from reboot.settings import (
    ENVVAR_NODEJS_SERVER,
    ENVVAR_PYTHON_SERVER,
    ENVVAR_RBT_DEV,
    ENVVAR_RBT_NAME,
    ENVVAR_RBT_SERVE,
    ENVVAR_RBT_SERVERS,
    ENVVAR_REBOOT_CLOUD_VERSION,
    ENVVAR_REBOOT_IN_TEST,
    ENVVAR_REBOOT_NODEJS,
)
from typing import Optional


class RunEnvironment(Enum):
    """Known run environments."""
    RBT_DEV = 1
    RBT_SERVE = 2
    RBT_CLOUD = 3


class InvalidRunEnvironment(RuntimeError):
    """Exception for when run environment cannot be determined."""
    pass


def detect_run_environment() -> RunEnvironment:
    """Internal helper to determine what run environment we are in."""
    # NOTE: ordering matters here as we may have multiple environment
    # variables set but some take precedence to others.
    if os.environ.get(ENVVAR_REBOOT_CLOUD_VERSION) is not None:
        # This environment variable is only set by the Cloud's controller, so we
        # must be on the Cloud. NOTE that it is NOT sufficient to look for
        # environment variables set by Kubernetes - it is possible to run `rbt
        # serve` on Kubernetes without being in the Cloud.
        return RunEnvironment.RBT_CLOUD
    elif os.environ.get(ENVVAR_RBT_DEV, 'false').lower() == 'true':
        return RunEnvironment.RBT_DEV
    elif os.environ.get(ENVVAR_RBT_SERVE, 'false').lower() == 'true':
        return RunEnvironment.RBT_SERVE

    raise InvalidRunEnvironment()


def within_nodejs_server():
    """Internal helper to determine if we're within a Node.js _server_.

    NOTE: THIS DOESN'T TELL US IF WE'RE RUNNING FROM WITHIN
    NODE.JS, JUST IF WE'RE IN A NODE.JS SERVER!

    """
    return os.environ.get(
        ENVVAR_NODEJS_SERVER,
        'false',
    ).lower() == 'true'


def within_python_server():
    """Internal helper to determine if we're within a Python
    server subprocess."""
    return (os.environ.get(
        ENVVAR_PYTHON_SERVER,
        'false',
    ).lower() == 'true')


def on_cloud() -> bool:
    """Helper for checking if we are running in a 'rbt cloud'
    cluster."""
    try:
        return detect_run_environment() == RunEnvironment.RBT_CLOUD
    except InvalidRunEnvironment:
        return False


def running_rbt_dev() -> bool:
    """Helper for checking if we are running via `rbt dev`."""

    try:
        return detect_run_environment() == RunEnvironment.RBT_DEV
    except InvalidRunEnvironment:
        return False


def running_rbt_serve() -> bool:
    """Helper for checking if we are running via `rbt serve`."""

    try:
        return detect_run_environment() == RunEnvironment.RBT_SERVE
    except InvalidRunEnvironment:
        return False


def is_in_test() -> bool:
    """Helper for checking if we are running inside a
    `reboot.aio.tests.Reboot` test harness, which is a permissive,
    local-development-like environment."""

    return os.environ.get(ENVVAR_REBOOT_IN_TEST, 'false').lower() == 'true'


def in_nodejs() -> bool:
    """Helper for checking if we are running in Node.js."""

    return os.environ.get(ENVVAR_REBOOT_NODEJS, 'false').lower() == 'true'


def application_name() -> str:
    """Helper that returns the current name this application has been run
    with, e.g., via `rbt dev run --application-name=...` or `rbt serve
    --application-name=...`.
    """
    # TODO(rjh): make sure all paths in the Cloud set this environment
    #            variable (not just customer containers using the `rbt
    #            serve` CLI, but also the bazel-built images), and
    #            make sure that it is obeyed (i.e. the CLI considers
    #            it an alternative to the `--application-name`
    #            argument). Then replace the fallback below with an
    #            `assert`.
    return os.environ.get(ENVVAR_RBT_NAME) or "Reboot Application"


@asynccontextmanager
async def fake_rbt_dev_environment():
    """Temporarily sets the run environment to resemble a valid `rbt dev`"""

    previous_rbt_dev_value = os.environ.get(ENVVAR_RBT_DEV)
    previous_rbt_servers_value = os.environ.get(ENVVAR_RBT_SERVERS)
    os.environ[ENVVAR_RBT_DEV] = 'true'
    os.environ[ENVVAR_RBT_SERVERS] = '1'

    try:
        yield
    finally:

        def reset(envvar_name: str, previous_value: Optional[str]):
            if previous_value is None:
                del os.environ[envvar_name]
            else:
                os.environ[envvar_name] = previous_value

        reset(ENVVAR_RBT_DEV, previous_rbt_dev_value)
        reset(ENVVAR_RBT_SERVERS, previous_rbt_servers_value)
