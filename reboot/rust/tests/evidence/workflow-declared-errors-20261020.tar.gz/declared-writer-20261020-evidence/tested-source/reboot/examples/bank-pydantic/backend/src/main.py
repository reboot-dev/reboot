import asyncio
from account_servicer import AccountServicer
from bank.v1.bank_rbt import Bank
from bank_servicer import BankServicer
from constants import SINGLETON_BANK_ID
from customer_servicer import CustomerServicer
from example_prompts import example_prompts
from reboot.aio.applications import Application
from reboot.aio.auth.oauth import OAuth
from reboot.aio.auth.oauth_providers import (
    Development,
    OAuthProviderByEnvironment,
)
from reboot.aio.external import InitializeContext
from reboot.std.collections.ordered_map.v1.ordered_map import (
    ordered_map_library,
)
from user_servicer import UserServicer


async def initialize(context: InitializeContext):
    await Bank.create(context, SINGLETON_BANK_ID)


async def main():
    await Application(
        title="Rebank",
        servicers=[
            AccountServicer,
            BankServicer,
            CustomerServicer,
            UserServicer,
        ],
        # The `User` type is auto-constructed per authenticated user,
        # which requires an OAuth provider to identify users.
        oauth=OAuth(
            provider=OAuthProviderByEnvironment(
                dev=Development(),
                # TODO: set a real provider (e.g. `Google(...)`) before
                # production; `prod=None` makes a production deployment
                # fail to start until one is chosen.
                prod=None,
            ),
            # The redirect URI of our own mobile app (see
            # `frontend/mobile/`), whose users Reboot signs in without
            # a consent screen. Without this the mobile app would be
            # treated like any other dynamically registered client and
            # its users would have to approve a consent screen first.
            # Expo's development redirect URI skips consent
            # automatically under `rbt dev run`, so this entry is what
            # a standalone build needs.
            skip_consent_for_redirect_uris=[
                "bankpydanticmobile://redirect",
            ],
        ),
        # Include `OrderedMap` library.
        libraries=[ordered_map_library()],
        initialize=initialize,
        example_prompts=example_prompts,
    ).run()


if __name__ == '__main__':
    asyncio.run(main())
