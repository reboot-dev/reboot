import grpc.aio
import importlib
import inspect
import rbt.v1alpha1.config_mode_pb2 as config_mode_pb2
import rbt.v1alpha1.config_mode_pb2_grpc as config_mode_pb2_grpc
from abc import ABC, abstractmethod
from functools import total_ordering
from google.protobuf.descriptor import FileDescriptor
from google.protobuf.message import Message
from mcp.server.fastmcp import FastMCP
from rbt.v1alpha1.application_config_pb2 import ApplicationConfig
from reboot.aio.external import ExternalContext
from reboot.aio.types import ServiceName, StateTypeName
from typing import Any, Callable, Mapping, Optional


class Servicer(ABC):
    """Base class for generated Servicers.
    """
    # Any servicer subclass must be labeled with the name of the service name
    # and a reference to the FileDescriptor that it originated from.
    #
    # These are class level attributes set by code generation for all generated
    # servicers.
    #
    # The format of the service name is the proto3 fully qualified name of the
    # `service` object, e.g., `my.package.FooService`.
    __service_names__: list[ServiceName]
    __state_type_name__: StateTypeName
    __state_type__: type[Message]
    __file_descriptor__: FileDescriptor

    # Whether this servicer is for an auto-constructed state type.
    _is_auto_construct: bool

    # Naming: has a leading underscore to ensure it doesn't collide with
    # customer-API-defined methods; those can't use leading underscores.
    @staticmethod
    def _mcp_tool_names() -> list[str]:
        """
        Return the MCP tool names this servicer would register.
        
        Overridden by generated code for states with MCP annotations.
        """
        return []

    @staticmethod
    def _add_mcp(
        mcp: FastMCP,
        auto_construct_state_type_full_names: list[StateTypeName],
    ) -> None:
        """
        Register any MCP tools/resources on `mcp`.

        Overridden by generated code for states with MCP annotations.
        """
        pass

    # Naming: has a leading underscore to ensure it doesn't collide with
    # customer-API-defined methods; those can't use leading underscores.
    @staticmethod
    async def _authenticated(
        context: ExternalContext,
        state_id: str,
        claims: Optional[Mapping[str, Any]] = None,
    ) -> None:
        """
        Record that a user authenticated: construct their state with
        the given ID if it does not exist yet (idempotently, so
        repeated calls are a NOOP), then, when `claims` is given,
        deliver the user's verified identity claims through the
        state's `set_claims` method.

        `claims=None` means the caller has no claims information for
        this authentication (e.g. a token refresh, which never
        consults the identity provider) and so skips `set_claims`
        entirely; it never means "the user has no claims" and never
        clears previously delivered claims.

        Overridden by generated code for auto-constructable state types.
        """
        pass

    # Naming: has a leading underscore to ensure it doesn't collide with
    # customer-API-defined methods; those can't use leading underscores.
    @staticmethod
    async def _set_claims_if_exists(
        context: ExternalContext,
        state_id: str,
        claims: Mapping[str, Any],
    ) -> None:
        """
        Deliver a user's verified identity claims to their state —
        but only if it already exists; never construct it. For
        identity changes that arrive outside a sign-in (e.g. an
        identity provider webhook), where materializing state for an
        identity that never signed in would be wrong.

        Overridden by generated code for auto-constructable state types.
        """
        pass


class ConfigServicer(config_mode_pb2_grpc.ConfigServicer):

    @classmethod
    def add_to_server(cls, server, *args):
        config_mode_pb2_grpc.add_ConfigServicer_to_server(cls(*args), server)

    def __init__(self, application_config: ApplicationConfig):
        self._application_config = application_config

    async def Get(self, _request, _context):
        return config_mode_pb2.GetConfigResponse(
            application_config=self._application_config
        )


# A `Routable` represents a service where we may want to route gRPC
# requests. It only describes the service via its name and the file
# descriptor in which the service information is located.
#
# Use `Serviceable` (a subclass of `Routable`) for representing
# services that you want to actually instantiate and serve. Otherwise
# use `Routable`.
#
# The `total_ordering` decorator helps us make this class comparable by
# implementing only `__eq__` and `__lt__`. The decorator will implement the
# rest. See:
#   https://docs.python.org/3/library/functools.html#functools.total_ordering
@total_ordering
class Routable(ABC):

    @abstractmethod
    def service_names(self) -> list[ServiceName]:
        """Return fully qualified service name."""
        raise NotImplementedError

    @abstractmethod
    def state_type_name(self) -> Optional[StateTypeName]:
        """Returns the name of the associated state type; if any"""
        raise NotImplementedError

    @abstractmethod
    def file_descriptor(self) -> FileDescriptor:
        """Return service file descriptor set."""
        raise NotImplementedError

    def _key(self) -> str:
        # TODO(rjh): in the future we may allow multiple servicers to implement
        # the same service. When that happens, we'll need to compare the name of
        # the servicer as well as the name of the service, and add tests that
        # demonstrate that that works.
        return str(self.service_names())

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, Serviceable):
            return NotImplemented

        return self._key() < other._key()

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Serviceable):
            return NotImplemented

        return self._key() == other._key()

    def __hash__(self) -> int:
        return hash(self._key())


class Serviceable(Routable):

    @abstractmethod
    def instantiate(
        self
    ) -> tuple[Servicer | object, Optional[Callable[[object, grpc.aio.Server],
                                                    None]]]:
        """Returns a tuple of the instantiated servicer and an optional callback that
        can be used to add the servicer to a gRPC server.
        """
        raise NotImplementedError

    @staticmethod
    def from_servicer_type(servicer_type: type):
        if issubclass(servicer_type, Servicer):
            return RebootServiceable(servicer_type)
        else:
            return _find_legacy_serviceable(servicer_type)


class RebootServiceable(Serviceable):

    def __init__(self, servicer_type: type[Servicer]):
        self._servicer_type = servicer_type

    def service_names(self) -> list[ServiceName]:
        return self._servicer_type.__service_names__

    def state_type_name(self) -> StateTypeName:
        return self._servicer_type.__state_type_name__

    def file_descriptor(self) -> FileDescriptor:
        return self._servicer_type.__file_descriptor__

    def instantiate(self) -> tuple[Servicer, None]:
        return (self._servicer_type(), None)


def _find_legacy_serviceable(
    # A legacy gRPC servicer type can't be more specific than `type`, because
    # legacy gRPC servicers (as generated by the gRPC `protoc` plugin) do not
    # share any common base class other than `object`.
    servicer_type: type
) -> type[Serviceable]:
    # To handle legacy gRPC servicers, we must find the matching generated
    # Reboot module and use the appropriate Reboot `Serviceable` there.
    #
    # The first step is to find the base (generated, legacy) gRPC servicer
    # class, so that we can figure out which gRPC module it was defined in. When
    # we get the full list of classes, the last parent class is always `object`.
    # Since generated gRPC servicers are direct subclasses of `object`, the
    # second to last parent class will be that base gRPC servicer class.
    parent_classes = inspect.getmro(servicer_type)
    grpc_servicer_base_class = parent_classes[-2]
    grpc_module_name = grpc_servicer_base_class.__module__
    if (
        not grpc_module_name.endswith('_pb2_grpc') or
        not grpc_servicer_base_class.__name__.endswith('Servicer')
    ):
        raise ValueError(
            f"Given type '{servicer_type}' is not a legacy gRPC servicer"
        )

    # Can we find a reboot module that matches the gRPC module?
    reboot_module_name = (grpc_module_name[:-len('_pb2_grpc')] + '_rbt')
    try:
        reboot_module = importlib.import_module(reboot_module_name)
        # If we've gotten here, we've successfully imported the user's generated
        # reboot module! We can use the helper function it defines to find the
        # appropriate Reboot `Serviceable` class for the given gRPC servicer.
        return reboot_module.MakeLegacyGrpcServiceable(servicer_type)
    except ImportError:
        raise ValueError(
            f"Could not find a Reboot module for '{servicer_type}'. "
            "Did you forget to run 'rbt generate' with the Reboot plugin?"
        )
