from __future__ import annotations

import asyncio
import dataclasses
import grpc.aio
import json
import uuid
from abc import ABC
from collections import defaultdict
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import timedelta
from enum import Enum
from google.protobuf.message import Message
from logging import Logger
from rbt.v1alpha1 import database_pb2, errors_pb2, react_pb2, react_pb2_grpc
from reboot.aio.aborted import SystemAborted, is_grpc_retryable_exception
from reboot.aio.auth import Auth
from reboot.aio.backoff import Backoff
from reboot.aio.external import ExternalContext
from reboot.aio.headers import (
    TRANSACTION_PARTICIPANTS_HEADER,
    TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER,
    TRANSACTION_PARTICIPANTS_TO_ABORT_HEADER,
    Headers,
)
from reboot.aio.idempotency import (
    PER_ITERATION,
    How,
    Idempotency,
    IdempotencyManager,
    _merge_idempotency_seeds,
    make_derived_idempotency_key,
    make_idempotency_alias,
)
from reboot.aio.internals.channel_manager import (
    LegacyGrpcChannel,
    _ChannelManager,
)
from reboot.aio.internals.contextvars import Servicing, _servicing
from reboot.aio.tasks import TaskEffect
from reboot.aio.types import (
    ApplicationId,
    GrpcMetadata,
    ServiceName,
    StateId,
    StateRef,
    StateTypeName,
)
from reboot.time import DateTimeWithTimeZone
from reboot.uuidv7 import uuid7
from reboot.wait_for_tasks import wait_for_tasks
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncGenerator,
    Awaitable,
    Callable,
    Generic,
    Iterator,
    Literal,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    TypeAlias,
    TypeVar,
)

# `StateManager` is only used in type annotations in this module.
# A runtime import would create a circular dependency: `contexts`
# imports `state_managers`, and `state_managers` imports `contexts`.
if TYPE_CHECKING:
    from reboot.aio.state_managers import StateManager

ContextT = TypeVar('ContextT', bound='Context')
ResponseT = TypeVar('ResponseT', bound=Message)


class IterationCompleteCallable(Protocol):
    """Callable signature accepted by
    `WorkflowContext.on_iteration_complete`. May be sync (returning
    `None`) or async (returning an `Awaitable[None]`). The runtime
    awaits async returns to completion before continuing.
    """

    def __call__(self, *, iteration: int) -> None | Awaitable[None]:
        ...


class MethodCompleteCallable(Protocol):
    """Callable signature accepted by
    `WorkflowContext.on_method_complete`. May be sync (returning
    `None`) or async (returning an `Awaitable[None]`). The runtime
    awaits async returns to completion before continuing.

    `retrying=True` means the workflow method body raised and the
    framework will retry it; `retrying=False` means the method body
    returned normally or raised a declared error.
    """

    def __call__(self, *, retrying: bool) -> None | Awaitable[None]:
        ...


# Module-level immutable empty set, used as the default in
# `dict.get(..., _EMPTY)` membership checks inside `Participants`
# so we don't allocate a throwaway `set()` per call. `frozenset`
# is also a defense-in-depth measure: anyone accidentally mutating
# the default would hit an `AttributeError` rather than silently
# corrupting a one-off empty set.
_EMPTY: frozenset[StateRef] = frozenset()


class Participants:
    # Participants that we should commit.
    _should_commit: defaultdict[StateTypeName, set[StateRef]]

    # Participants that are read-only and only need to be `Prepare`'ed
    # and should never be re-`Prepare`'ed.
    _read_only: defaultdict[StateTypeName, set[StateRef]]

    @classmethod
    def from_sidecar(cls, participants: database_pb2.Participants):
        """Constructs an instance from the sidecar protobuf representation.
        Goes through `add()` rather than writing the underlying sets
        directly so the disjoint invariant gets revalidated (catches
        any future bug in `to_sidecar` or in a hand-built proto).
        """
        result = cls()
        for (state_type, state_refs) in participants.should_commit.items():
            for state_ref in state_refs.state_refs:
                result.add(state_type, StateRef(state_ref))
        for (state_type, state_refs) in participants.read_only.items():
            for state_ref in state_refs.state_refs:
                result.add(state_type, StateRef(state_ref), read_only=True)
        return result

    def to_sidecar(self) -> database_pb2.Participants:
        """Helper to construct the sidecar protobuf representation."""
        return database_pb2.Participants(
            should_commit={
                state_type:
                    database_pb2.Participants.StateRefs(
                        state_refs=[
                            state_ref.to_str() for state_ref in state_refs
                        ]
                    )
                for (state_type, state_refs) in self._should_commit.items()
                if len(state_refs) > 0
            },
            read_only={
                state_type:
                    database_pb2.Participants.StateRefs(
                        state_refs=[
                            state_ref.to_str() for state_ref in state_refs
                        ]
                    )
                for (state_type, state_refs) in self._read_only.items()
                if len(state_refs) > 0
            },
        )

    def __init__(self):
        self._should_commit = defaultdict(set)
        self._read_only = defaultdict(set)
        # Set by `from_grpc_metadata` when it decodes a deprecated
        # `TRANSACTION_PARTICIPANTS_TO_ABORT_HEADER` from an older
        # server during a rolling upgrade; see the handling there.
        self._saw_legacy_to_abort = False

    @property
    def saw_legacy_to_abort(self) -> bool:
        return self._saw_legacy_to_abort

    def should_prepare(
        self,
        *,
        skip_read_only: bool = False,
    ) -> Iterator[Tuple[StateTypeName, StateRef]]:
        """Returns an iterator of (state_type, state_ref) tuples for each
        participant to prepare. Includes read-only participants by
        default, pass `skip_read_only=True` to exclude them.
        """
        for state_type, state_ref in self.should_commit():
            yield (state_type, state_ref)
        if not skip_read_only:
            for state_type, state_ref in self.read_only():
                yield (state_type, state_ref)

    def should_commit(self) -> Iterator[Tuple[StateTypeName, StateRef]]:
        """Returns an iterator of (state_type, state_ref) tuples for each
        participant that needs to be committed (read-only participants
        are NOT included).
        """
        for state_type, state_refs in self._should_commit.items():
            for state_ref in state_refs:
                yield (state_type, state_ref)

    def read_only(self) -> Iterator[Tuple[StateTypeName, StateRef]]:
        """Returns the read-only participants."""
        for state_type, state_refs in self._read_only.items():
            for state_ref in state_refs:
                yield (state_type, state_ref)

    def retain_as_read_only(self):
        """Demotes our to-commit participants to read-only.

        Used when a nested transaction aborts with a declared error
        that escapes to a catching caller: the states it observed must
        stay read-locked by the root transaction, at their rolled-back
        values, until the root commits — otherwise a concurrent
        transaction could change a value the caller inferred from the
        error. As read-only participants they propagate up the tree
        and are prepared-and-released (not committed) at the root's two
        phase commit."""
        for state_type, state_refs in self._should_commit.items():
            self._read_only[state_type].update(state_refs)
        self._should_commit.clear()

    def add(
        self,
        state_type: StateTypeName,
        state_ref: StateRef,
        *,
        read_only: bool = False,
    ):
        """Add a participant. `read_only=True` records it in the read-only set
        unless it is already in the commit set.  Similarly, adding a
        participant with `read_only=False` (the default) when it was
        previously read-only moves it to the commit set.
        """
        assert isinstance(state_type, str)
        assert isinstance(state_ref, StateRef)
        if read_only:
            # Non-read-only wins.
            if state_ref not in self._should_commit.get(state_type, _EMPTY):
                self._read_only[state_type].add(state_ref)
            return
        # Move out of `_read_only` if it was there. Callers use this
        # path to promote a previously-read-only entry to commit.
        if state_type in self._read_only:
            self._read_only[state_type].discard(state_ref)
        self._should_commit[state_type].add(state_ref)

    def union(self, participants: 'Participants'):
        """Merge another `Participants` instance into this one.
        Write-wins for the commit-vs-read classification (an entry
        committed on either side is committed in the result)."""
        for (state_type, state_refs) in participants._should_commit.items():
            for state_ref in state_refs:
                self.add(state_type, state_ref, read_only=False)
        for (state_type, state_refs) in participants._read_only.items():
            for state_ref in state_refs:
                self.add(state_type, state_ref, read_only=True)

    def to_grpc_metadata(
        self,
        *,
        read_only_aware: bool = False,
    ) -> GrpcMetadata:
        """Helper to encode transaction participants into gRPC
        metadata.

        - `read_only_aware=False` (default): only
          `TRANSACTION_PARTICIPANTS_HEADER` is emitted, carrying every
          participant; no read-only header is sent because the
          coordinator wouldn't understand it.

        - `read_only_aware=True`: `TRANSACTION_PARTICIPANTS_HEADER` and
          `TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER` carry disjoint
          subsets (participants that need to be committed vs read-only
          participants).
        """
        if read_only_aware:
            should_commit = self._should_commit
        else:
            should_commit = defaultdict(set)
            for (state_type, state_refs) in self._should_commit.items():
                should_commit[state_type].update(state_refs)
            for (state_type, state_refs) in self._read_only.items():
                should_commit[state_type].update(state_refs)
        metadata: GrpcMetadata = (
            (
                TRANSACTION_PARTICIPANTS_HEADER,
                json.dumps(
                    {
                        state_type:
                            [state_ref.to_str() for state_ref in state_refs]
                        for (state_type, state_refs) in should_commit.items()
                        if len(state_refs) > 0
                    }
                )
            ),
        )
        if read_only_aware:
            metadata += (
                (
                    TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER,
                    json.dumps(
                        {
                            state_type:
                                [
                                    state_ref.to_str()
                                    for state_ref in state_refs
                                ]
                            for (state_type,
                                 state_refs) in self._read_only.items()
                            if len(state_refs) > 0
                        }
                    )
                ),
            )
        return metadata

    @classmethod
    def from_grpc_metadata(cls, metadata: GrpcMetadata) -> 'Participants':
        """Helper to decode transaction participants from gRPC metadata."""
        participants = cls()
        for (key, value) in metadata:
            if key == TRANSACTION_PARTICIPANTS_HEADER:
                for (state_type_name, state_refs) in json.loads(value).items():
                    for state_ref in state_refs:
                        participants.add(state_type_name, StateRef(state_ref))
            elif key == TRANSACTION_PARTICIPANTS_TO_ABORT_HEADER:
                # Rolling-upgrade compatibility: an old server (one
                # that still has `should_abort`) propagates a nested
                # transaction's participants that need to abort in
                # this header. We no longer perform per-participant
                # abort (nested transactions handle ownership
                # relinquishment instead), so we just flag that we saw
                # it and the stub merging this metadata
                # (`reboot/aio/stubs.py`) turns the flag into a
                # retryable `Unavailable` that forces the transaction
                # to retry, hopefully, with all servers now upgraded
                # to the new release.
                participants._saw_legacy_to_abort = True
            elif key == TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER:
                for (state_type_name, state_refs) in json.loads(value).items():
                    for state_ref in state_refs:
                        participants.add(
                            state_type_name,
                            StateRef(state_ref),
                            read_only=True,
                        )
        return participants


class React:
    """Encapsulates machinery necessary for contexts that are "reactive",
    aka, those that are initiated from calls to `React.Query` and who
    then transform subsequent reader calls into `React.Query` calls
    themselves (for full transitive reactivity).
    """

    class Querier(Generic[ResponseT]):
        """Performs the `React.Query` RPCs.

        Maintains an `asyncio.Task` for every unique request that is
        used (uniqueness is determined via serializing the request).

        Expects a call to `cancel_unused()` to cancel the
        `asyncio.Task`s that are no longer necessary.
        """

        # State, service, and method we are invoking.
        _state_type_name: StateTypeName
        _state_ref: StateRef
        _method: str

        # Type of the response we are receiving.
        _response_type: type[ResponseT]

        # Event which indicates that new data has been received and we
        # should re-invoke methods.
        _event: asyncio.Event

        _channel_manager: _ChannelManager

        # Tasks that are calling `React.Query`, keyed by the
        # serialized request.
        _tasks: dict[bytes, asyncio.Task]

        # The gRPC call to `React.Query` that each of our
        # `asyncio.Task`s are making.
        _calls: dict[asyncio.Task, grpc.aio.Call]

        # The latest response or error received from calling
        # `React.Query`, set by our `asyncio.Task`s.
        _responses: dict[asyncio.Task, asyncio.Future[ResponseT]]

        # An event indicating that a response has been used and thus
        # the next response can be retrieved.
        _used_response: dict[asyncio.Task, asyncio.Event]

        # The subset of `_tasks` that's been used since the last call
        # to `cancel_*()`.  Any tasks not in this `set` are considered
        # "unused" for the purposes of `cancel_unused()`.
        _used_tasks: set[asyncio.Task]

        # Whether or not this querier has been invalidated (see
        # `React.invalidate()` for more details).
        invalidated: bool

        def __init__(
            self,
            *,
            state_type_name: StateTypeName,
            state_ref: StateRef,
            method: str,
            response_type: type[ResponseT],
            event: asyncio.Event,
            channel_manager: _ChannelManager,
        ):
            self._state_type_name = state_type_name
            self._state_ref = state_ref
            self._method = method
            self._response_type = response_type
            self._event = event
            self._channel_manager = channel_manager
            self._tasks = dict()
            self._calls = dict()
            self._responses = dict()
            self._used_response = dict()
            self._used_tasks = set()
            self.invalidated = False

        def __del__(self):
            assert len(self._tasks) == 0

        async def call(
            self,
            request: Message,
            *,
            metadata: GrpcMetadata,
        ) -> tuple[grpc.aio.Call, asyncio.Future[ResponseT]]:
            serialized_request = request.SerializeToString(deterministic=True)

            task: Optional[asyncio.Task] = self._tasks.get(serialized_request)

            if task is not None:
                self._used_tasks.add(task)

                self._used_response[task].set()

                assert task in self._calls
                assert task in self._responses

                return (self._calls[task], self._responses[task])

            # Need to track whether or not we have received
            # the first response because we don't want to
            # cause an unnecessary reaction (i.e.,
            # re-execution of the user's code) for the first
            # response.
            have_first_response = asyncio.Event()

            async def query():
                task: Optional[asyncio.Task] = asyncio.current_task()

                assert task is not None

                # In the event we receive an error from the call we
                # want to try again because it's possible that we'll
                # get a response if some other state changes, but
                # rather than continuously bombarding the server with
                # requests we exponentially backoff before retrying.
                #
                # TODO(benh): introduce a mechanism where we can
                # actually wait until a new response would be
                # produced, e.g., because we track the state
                # version/clock and only retry calls when the state
                # changes.
                backoff = Backoff(max_backoff_seconds=5)

                while True:
                    channel = self._channel_manager.get_channel_to_state(
                        self._state_type_name, self._state_ref
                    )

                    call = react_pb2_grpc.ReactStub(channel).Query(
                        react_pb2.QueryRequest(
                            method=self._method,
                            request=serialized_request,
                        ),
                        metadata=metadata,
                    )

                    # We need an extra level of indirection to loop
                    # through the gRPC responses because empirically
                    # it appears as though we cannot cancel an
                    # `asyncio.Task` that is "blocked" in the gRPC
                    # `call` generator. Possible bug:
                    # https://github.com/grpc/grpc/issues/28999
                    #
                    # We get this extra level of indirection by
                    # calling a coroutine that performs the `async
                    # for` loop such that when our `asyncio.Task` gets
                    # cancelled, we can then do `call.cancel()` which
                    # will cancel the underlying gRPC generator.
                    async def loop():
                        assert task is not None

                        async for query_response in call:
                            if not query_response.HasField('response'):
                                continue

                            response = self._response_type()
                            response.ParseFromString(query_response.response)

                            self._used_response[task].clear()

                            self._calls[task] = call

                            self._responses[task] = asyncio.Future()
                            self._responses[task].set_result(response)

                            if not have_first_response.is_set():
                                have_first_response.set()
                            else:
                                self._event.set()

                            await self._used_response[task].wait()

                        raise RuntimeError('React.Query should be infinite')

                    try:
                        await loop()
                    except asyncio.CancelledError:
                        call.cancel()
                        try:
                            await call
                        except:
                            pass
                        raise
                    except BaseException as exception:
                        if is_grpc_retryable_exception(exception):
                            continue

                        self._used_response[task].clear()

                        self._calls[task] = call

                        self._responses[task] = asyncio.Future()
                        self._responses[task].set_exception(exception)

                        if not have_first_response.is_set():
                            have_first_response.set()
                        else:
                            self._event.set()

                        await self._used_response[task].wait()

                        # Let's retry after a backoff!
                        await backoff()

            task = asyncio.create_task(query(), name=f'query() in {__name__}')

            self._tasks[serialized_request] = task
            self._used_response[task] = asyncio.Event()
            self._used_tasks.add(task)

            await have_first_response.wait()

            return await self.call(request, metadata=metadata)

        async def cancel_all(self):
            # Mark all tasks as unused and then cancel unused, which
            # will be all of them!
            self._used_tasks = set()
            await self.cancel_unused()

        async def cancel_unused(self):
            tasks = self._tasks
            self._tasks = dict()

            used_tasks = self._used_tasks
            self._used_tasks = set()

            unused_tasks = set()

            for (serialized_request, task) in tasks.items():
                if task in used_tasks:
                    self._tasks[serialized_request] = task
                else:
                    unused_tasks.add(task)

            try:
                await wait_for_tasks(unused_tasks, cancel=True)
            finally:
                for task in unused_tasks:
                    # Remove all references to the task object and its
                    # associated gRPC call so they can be
                    # garbage-collected. Using `pop` instead of `del`,
                    # since it could be a case when the task is
                    # cancelled before it makes a gRPC call and thus
                    # doesn't have an entry in `self._calls`,
                    # `self._responses` and `self._used_response`.
                    self._calls.pop(task, None)
                    self._responses.pop(task, None)
                    self._used_response.pop(task, None)
                unused_tasks.clear()

    _channel_manager: _ChannelManager
    _queriers: dict[str, Querier]
    _event: asyncio.Event

    # The "iteration" of dependency updates that we've received,
    # useful for distinguishing whether or not it is safe to wait on
    # `_event` or if it's possible that we've missed an update.
    _iteration: int

    # Lock to ensure that we only increment `_iteration` once for
    # every set of `_event.set()` calls between `_event.wait()`.
    _lock: asyncio.Lock

    _cancelled: bool

    def __init__(self, channel_manager: _ChannelManager):
        self._channel_manager = channel_manager
        self._queriers = dict()
        self._event = asyncio.Event()
        self._iteration = 0
        self._lock = asyncio.Lock()
        self._cancelled = False

    @property
    def event(self) -> asyncio.Event:
        return self._event

    @property
    def iteration(self) -> int:
        return self._iteration

    async def iterate(self, iteration: int):
        """Helper for waiting only if we're still at the current iteration."""
        if self._iteration == iteration:
            # Using a lock to ensure that even if there are multiple
            # callers to `iterate`, only one of them increments
            # `self._iteration`.
            async with self._lock:
                if self._iteration == iteration:
                    await self._event.wait()
                    self._event.clear()
                    self._iteration += 1
        return self._iteration

    async def call(
        self,
        *,
        state_type_name: StateTypeName,
        state_ref: StateRef,
        service_name: ServiceName,
        method: str,
        request: Message,
        response_type: type[ResponseT],
        metadata: GrpcMetadata,
    ) -> tuple[grpc.aio.Call, asyncio.Future[ResponseT]]:
        """Performs an RPC by calling `React.Query` instead."""
        if self._cancelled:
            raise SystemAborted(errors_pb2.Cancelled())

        # Lookup or create a `Querier` for performing this RPC and
        # then delegate the call to it.
        key = f'{service_name}.{method}/{state_ref}'

        querier: Optional[React.Querier[ResponseT]] = self._queriers.get(key)

        if querier is None:
            querier = React.Querier(
                state_type_name=state_type_name,
                state_ref=state_ref,
                method=method,
                response_type=response_type,
                event=self._event,
                channel_manager=self._channel_manager,
            )
            self._queriers[key] = querier

        assert querier is not None

        if querier.invalidated:
            # Need to remove querier before cancelling all so that any
            # other concurrent calls made while `await`ing the cancel
            # will create a new querier.
            del self._queriers[key]

            await querier.cancel_all()

            # Now just try this method again, which will either create
            # a new querier or use a querier created while we were
            # `await`ing the cancellation of the old one above.
            return await self.call(
                state_type_name=state_type_name,
                state_ref=state_ref,
                service_name=service_name,
                method=method,
                request=request,
                response_type=response_type,
                metadata=metadata,
            )

        return await querier.call(request, metadata=metadata)

    async def cancel_unused_queries(self):
        for querier in self._queriers.values():
            await querier.cancel_unused()

    async def cancel(self):
        self._cancelled = True
        for querier in self._queriers.values():
            await querier.cancel_all()
            assert len(querier._tasks) == 0

    def invalidate(
        self,
        *,
        service_name: ServiceName,
        state_ref: StateRef,
    ):
        """Invalidates a querier, if it exists, but does _NOT_ cancel it
        because we still want to get any updated responses to trigger
        re-execution, however when we re-execute we'll make a new call.

        TODO: we can improve the performance here by requiring
        idempotency for mutations within a reactive setting and then
        we can simply only expose updated responses that include the
        idempotency key of mutations to ensure we read our writes.
        """
        for key, querier in self._queriers.items():
            if (
                key.startswith(f'{service_name}.') and
                key.endswith(f'/{state_ref}')
            ):
                querier.invalidated = True


class EffectValidation(Enum):
    ENABLED = 1
    QUIET = 2
    DISABLED = 3


class EffectValidationRetry(Exception):
    """An exception type which is raised in order to abort and retry transactions
    for the purposes of effect validation."""


# Print effect validation warnings every 5 minutes.
_PRINT_EFFECT_VALIDATION_WARNINGS_DELTA = timedelta(minutes=5)


def _log_message_for_effect_validation(
    *,
    effect_validation: EffectValidation,
    identifier: str,
    timestamps: dict[str, DateTimeWithTimeZone],
    logger: Logger,
    message: str,
):
    """Helper for logging an info or debug `message` about an effect
    validation when it is set to `QUIET` given the `timestamps` that
    the last effect validation for the given `identifier` was logged.

    Updates `timestamps` regardless of whether or not anything was
    printed.
    """
    if effect_validation == EffectValidation.QUIET:
        if (
            identifier not in timestamps or (
                DateTimeWithTimeZone.now() - timestamps[identifier]
                > _PRINT_EFFECT_VALIDATION_WARNINGS_DELTA
            )
        ):
            timestamps[identifier] = DateTimeWithTimeZone.now()

            logger.info(
                f"{message} Will silence this message for the next "
                f"{_PRINT_EFFECT_VALIDATION_WARNINGS_DELTA.seconds // 60} minutes."
            )
        else:
            logger.debug(message)
    else:
        assert effect_validation == EffectValidation.ENABLED

        logger.info(message)


class Context(ABC, IdempotencyManager):
    """Common base class for all contexts.

    Contexts holds information relevant to the current call.

    Construction of a Context object is done by the servicer
    middleware. You should never need to construct a Context yourself.
    """
    # Python asyncio context variable that stores the current context.
    _context: ContextVar[Optional[Context]] = ContextVar(
        'Context of the current asyncio context',
        default=None,
    )

    @classmethod
    def get(cls) -> Optional[Context]:
        """Returns context for the current asyncio context, or None."""
        return cls._context.get()

    @classmethod
    def get_or_raise(cls) -> Context:
        """Returns context for the current asyncio context, or raises."""
        context = cls._context.get()
        if context is None:
            raise RuntimeError(
                'Missing asyncio context variable `context`; '
                'are you trying to make a call outside of a servicer?'
            )
        return context

    @classmethod
    def set(cls, context: Context):
        """Sets the context for the current asyncio context."""
        return cls._context.set(context)

    @contextmanager
    def use(self) -> Iterator[None]:
        """Context manager that uses `self` for the current asyncio context."""
        old_context = Context.get()
        try:
            Context.set(self)
            yield
        finally:
            if old_context is not None:
                Context.set(old_context)

    _channel_manager: _ChannelManager
    _headers: Headers

    # `None` unless this context is being used to run a task.
    _task: Optional[TaskEffect]

    # Participants aggregated from all RPCs rooted at the method for
    # which we initially created this context.
    #
    # We use this when a method is executed within a transaction so
    # that we can pass back to the coordinator the precise set of
    # participants.
    participants: Participants

    # Number of outstanding RPCs rooted at the method for which we
    # initially created this context. Incremented whenever an RPC
    # begins, and decremented when it completes (whether successfully
    # or not).
    #
    # We use this when a method is executed within a transaction to
    # ensure that all RPCs complete so that we know we have aggregated
    # all possible participants - this count must reach 0.
    #
    # TODO(benh): consider using this for not just transactions but
    # all methods, or at least making it the default with an option to
    # opt out.
    outstanding_rpcs: int

    # The abort that made the transaction enclosing this context
    # unrecoverable, or `None` if it does not have to abort.
    #
    # Holding the abort rather than a bool lets us re-raise it instead
    # of a generic "must abort" error, so that a caller which catches
    # and discards an abort still gets the same outcome as one which
    # lets it propagate, e.g., an `Unavailable` or a
    # `TransactionShouldRetry` still asks the coordinator for a retry.
    transaction_unrecoverable_abort: Optional[BaseException]

    # Extra machinery for handling reactive contexts. Set when using
    # the `StateManager.reactively()` helper.
    react: Optional[React]

    # Auth specific information as provided by the `TokenVerifier`, if present.
    auth: Optional[Auth]

    # Full name of the state type being invoked (e.g. `foo.v1.Bar`).
    _state_type_name: StateTypeName

    # Whether or not this context is being used for a "constructor",
    # i.e., a writer or transaction of an state that has not yet been
    # constructed.
    _constructor: bool

    # Configured effect validation.
    _effect_validation: EffectValidation

    # Any tasks scheduled with this context that we need to include as
    # part of the effects.
    _tasks: list[TaskEffect]

    # NOTE: `_colocated_upserts` argument is for internal use only. See
    # usage in the `StateManager` class.
    _colocated_upserts: Optional[list[tuple[str, Optional[bytes]]]]

    def __init__(
        self,
        *,
        channel_manager: _ChannelManager,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        effect_validation: EffectValidation,
        task: Optional[TaskEffect] = None,
    ):
        # Note: this is intended as a private constructor only to be
        # called by the middleware.
        if _servicing.get() is not Servicing.INITIALIZING:
            raise RuntimeError(
                'Context should only be constructed by middleware'
            )

        super().__init__(
            seed=uuid.UUID(bytes=task.task_id.task_uuid)
            if task is not None else None,
            required=isinstance(self, WorkflowContext),
            required_reason=
            'Calls to mutators within a `workflow` must use idempotency'
            if isinstance(self, WorkflowContext) else None,
        )

        self._channel_manager = channel_manager
        self._headers = headers
        self._state_type_name = state_type_name
        self._method = method
        self._task = task

        self.participants = Participants()
        self.outstanding_rpcs = 0
        self.transaction_unrecoverable_abort = None

        self.react = None

        self.auth = None

        self._constructor = False

        self._effect_validation = effect_validation

        self._tasks = []

        self._colocated_upserts = None

        # Store the context as an asyncio contextvar for access via
        # APIs where we don't pass a `context` but we know one has
        # been created (or should have been created).
        Context._context.set(self)

    @property
    def channel_manager(self) -> _ChannelManager:
        """Return channel manager.
        """
        return self._channel_manager

    @property
    def application_id(self) -> ApplicationId:
        """Return application ID.
        """
        assert self._headers.application_id is not None
        return self._headers.application_id

    @property
    def state_type_name(self) -> StateTypeName:
        """Return the name of the state type.
        """
        return self._state_type_name

    @property
    def method(self) -> str:
        """Return the name of the method.
        """
        return self._method

    @property
    def state_id(self) -> StateId:
        """Return state id.
        """
        return self._headers.state_ref.id

    @property
    def _state_ref(self) -> StateRef:
        return self._headers.state_ref

    @property
    def cookie(self) -> Optional[str]:
        return self._headers.cookie

    @property
    def internal_call(self) -> bool:
        """Return whether this call originated within a Reboot
        method (as opposed to externally, e.g., using `ExternalContext`).
        """
        return self._headers.internal_call

    @staticmethod
    def is_app_internal(
        headers: Headers,
        application_id: ApplicationId,
    ) -> bool:
        """Returns true if a call with `headers` is internal to the
        application `application_id`, i.e., was made from within it.

        This is the one place that decides what makes a call
        application-internal; `app_internal` and the generated code use
        it rather than restating the check.
        """
        if headers.caller_id is None:
            return False
        return headers.caller_id.application_id == application_id

    @property
    def app_internal(self) -> bool:
        """Returns true if this context is for an application internal call,
        otherwise false.
        """
        return Context.is_app_internal(self._headers, self.application_id)

    @property
    def transaction_ids(self) -> Optional[list[uuid.UUID]]:
        """Returns all transaction ids that make up the path from root and
        nested transactions to the current transaction.
        """
        return self._headers.transaction_ids

    @property
    def transaction_id(self) -> Optional[uuid.UUID]:
        """Return transaction id.
        """
        if self._headers.transaction_ids is not None:
            return self._headers.transaction_ids[-1]
        else:
            return None

    @property
    def transaction_root_id(self) -> Optional[uuid.UUID]:
        """Return transaction root id, i.e., the outermost transaction.
        """
        if self._headers.transaction_ids is not None:
            return self._headers.transaction_ids[0]
        else:
            return None

    @property
    def transaction_parent_ids(self) -> Optional[list[uuid.UUID]]:
        """Return transaction parent ids if this is a nested transaction.
        """
        if self._headers.transaction_ids is not None:
            return self._headers.transaction_ids[:-1]
        else:
            return None

    @property
    def transaction_retry_age(self) -> Optional[uuid.UUID]:
        """Return the age of the transaction as carried by a retry: the
        root transaction id of its first attempt. `None` on a first
        attempt, whose age is its own root transaction id.
        """
        return self._headers.transaction_retry_age

    @property
    def workflow_id(self) -> Optional[uuid.UUID]:
        """Return workflow id.
        """
        return self._headers.workflow_id

    @property
    def workflow_iteration(self) -> Optional[int]:
        """Return workflow iteration, if any.
        """
        return self._headers.workflow_iteration

    @property
    def transaction_coordinator_state_type(self) -> Optional[StateTypeName]:
        """Return transaction coordinator state type.
        """
        return self._headers.transaction_coordinator_state_type

    @property
    def transaction_coordinator_state_ref(self) -> Optional[StateRef]:
        """Return transaction coordinator state ref.
        """
        return self._headers.transaction_coordinator_state_ref

    @property
    def idempotency_key(self) -> Optional[uuid.UUID]:
        """Return optional idempotency key.
        """
        return self._headers.idempotency_key

    @property
    def caller_bearer_token(self) -> Optional[str]:
        """
        Return the bearer token used to call into this context, if any.

        NOTE: be careful when you use the caller's bearer token in transitive
        calls! This is only safe if the downstream service can be trusted with
        the caller's credentials.
        """
        return self._headers.bearer_token

    @property
    def constructor(self) -> bool:
        """Return whether or not this context is being used for a method that
        is acting as a constructor.
        """
        return self._constructor

    @property
    def task(self) -> Optional[TaskEffect]:
        """Returns the task if this context is being used to execute a
        task, otherwise `None`.
        """
        return self._task

    @property
    def task_id(self) -> Optional[uuid.UUID]:
        """Returns the task if this context is being used to execute a
        task, otherwise `None`.
        """
        return (
            uuid.UUID(bytes=self._task.task_id.task_uuid)
            if self._task is not None else None
        )

    def legacy_grpc_channel(self) -> grpc.aio.Channel:
        """Get a gRPC channel that can connect to any Reboot-hosted legacy
        gRPC service. Simply use this channel to create a Stub and call it, no
        address required."""
        return LegacyGrpcChannel(self._channel_manager)

    @classmethod
    def idempotency(
        cls,
        *,
        alias: Optional[str] = None,
        key: Optional[uuid.UUID | str] = None,
        how: Optional[How] = None,
    ) -> Idempotency:
        """Helper to create an `Idempotency` instance, or raise
        if being used incorrectly.
        """
        if how == PER_ITERATION and key is not None:
            raise TypeError(
                'Passing `how=PER_ITERATION` is invalid '
                'when passing `key`'
            )

        iteration: Optional[int] = None

        if how == PER_ITERATION:
            context = Context.get()

            if context is not None and isinstance(context, WorkflowContext):
                iteration = context.task.iteration
            else:
                raise TypeError(
                    'Passing `how=PER_ITERATION` is only valid '
                    'within a `workflow`'
                )

        return Idempotency(
            key=key,
            alias=alias,
            how=how,
            iteration=iteration,
        )


class ReaderContext(Context):
    """Call context for a reader call."""


class WriterContext(Context):
    """Call context for a writer call."""

    # Indicates whether or not you'd like the underlying storage layer
    # to use `fsync` (or equivalent) to persist the writer's effects.
    #
    # While a writer with `sync=False` may survive a process crash
    # (although those semantics may be changed later), it may not
    # survive a machine crash.
    #
    # NOTE: these semantics are only considered when:
    #   1. The writer is _not_ a constructor (implicitly or explicitly).
    #   2. The writer is _not_ scheduling any tasks.
    #   3. The writer is _not_ within a transaction.
    #   4. The writer is _not_ running as a task.
    sync: bool
    request_fingerprint: Optional[bytes]

    def __init__(
        self,
        *,
        channel_manager: _ChannelManager,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        effect_validation: EffectValidation,
        task: Optional[TaskEffect] = None,
    ):
        super().__init__(
            channel_manager=channel_manager,
            headers=headers,
            state_type_name=state_type_name,
            method=method,
            task=task,
            effect_validation=effect_validation,
        )

        self.sync = True
        self.request_fingerprint = None


class TransactionContext(Context):
    """Call context for a transaction call."""

    request_fingerprint: Optional[bytes]

    def __init__(
        self,
        *,
        channel_manager: _ChannelManager,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        effect_validation: EffectValidation,
        exclusive: bool,
        task: Optional[TaskEffect] = None,
        database_timestamp_ms: Optional[int] = None,
    ):
        assert (
            headers.transaction_ids is None or len(headers.transaction_ids) > 0
        )

        self._exclusive = exclusive

        # Use UUIDv7 with database-sourced timestamp when available
        # (for restart detection), otherwise fall back to UUIDv4.
        if database_timestamp_ms is not None:
            transaction_id = uuid7(timestamp_ms=database_timestamp_ms)
        else:
            transaction_id = uuid.uuid4()

        if headers.transaction_ids is None:
            headers = dataclasses.replace(
                headers,
                transaction_ids=[transaction_id],
                # The state servicing the request to executing
                # a method of kind transaction acts as the
                # transaction coordinator.
                transaction_coordinator_state_type=state_type_name,
                transaction_coordinator_state_ref=headers.state_ref,
            )
        else:
            assert (
                headers.transaction_coordinator_state_type is not None and
                headers.transaction_coordinator_state_ref is not None
            )

            headers = dataclasses.replace(
                headers,
                transaction_ids=headers.transaction_ids + [transaction_id],
            )

        super().__init__(
            channel_manager=channel_manager,
            headers=headers,
            state_type_name=state_type_name,
            method=method,
            task=task,
            effect_validation=effect_validation,
        )

        self.request_fingerprint = None

    @property
    def exclusive(self) -> bool:
        """Whether the transaction method declared that it holds the lock
        on its own state exclusive from the start, so that concurrent
        callers of the state queue behind it, rather than shared and
        upgraded to exclusive only if it writes its state.
        """
        return self._exclusive

    @property
    def transaction_ids(self) -> list[uuid.UUID]:
        """Returns all transaction ids that make up the path from root and
        nested transactions to the current transaction.
        """
        assert self._headers.transaction_ids is not None
        return self._headers.transaction_ids

    @property
    def transaction_id(self) -> uuid.UUID:
        """Return transaction id.
        """
        assert self._headers.transaction_ids is not None
        return self._headers.transaction_ids[-1]

    @property
    def transaction_root_id(self) -> uuid.UUID:
        """Return transaction root id, i.e., the outermost transaction.
        """
        assert self._headers.transaction_ids is not None
        return self._headers.transaction_ids[0]

    @property
    def transaction_parent_ids(self) -> list[uuid.UUID]:
        """Return transaction parent ids if this is a nested transaction.
        """
        assert self._headers.transaction_ids is not None
        return self._headers.transaction_ids[:-1]

    @property
    def transaction_coordinator_state_type(self) -> StateTypeName:
        """Return transaction coordinator service.
        """
        assert self._headers.transaction_coordinator_state_type is not None
        return self._headers.transaction_coordinator_state_type

    @property
    def transaction_coordinator_state_ref(self) -> StateRef:
        """Return transaction coordinator state ref.
        """
        assert self._headers.transaction_coordinator_state_ref is not None
        return self._headers.transaction_coordinator_state_ref

    @property
    def nested(self) -> bool:
        """Return whether or not this transaction is nested.
        """
        assert self._headers.transaction_ids is not None
        return len(self._headers.transaction_ids) > 1


class Loop(Protocol):

    def __call__(
        self,
        alias: str,
        *,
        interval: Optional[timedelta] = None,
    ) -> AsyncGenerator[int, Any]:
        ...


# We need to know when we're within an `until` because we treat "bare"
# calls to readers as `.always()`.
_within_until: ContextVar[bool] = ContextVar(
    "Whether or not current asyncio context is within an 'until'",
    default=False,
)

# Type variable for `Workflow.wait()`.
WaitT = TypeVar('WaitT')

# Type variable for `WorkflowContext.retry_reactively_until()`.
RetryReactivelyUntilT = TypeVar('RetryReactivelyUntilT')


class WorkflowContext(Context):
    """Call context for a workflow call."""

    # If this context called into Node.js, this is the "cancelled"
    # future that indicates if the original call was cancelled.
    _cancelled: Optional[asyncio.Future[None]]

    # Extra machinery for handling control loops, similar to how we
    # `context.react`. Set when `StateManager.task_workflow()` is
    # called.
    loop: Loop
    within_loop: Callable[[], bool]

    # State manager and state type for this context. Set by the
    # generated code so that `until()` calls (via
    # `retry_reactively_until()`) can enter `reactively()` without
    # knowing the state type or the state manager.
    _reactively_state_manager: StateManager
    _reactively_state_type: type

    # Callables for when the current `context.loop(...)` iteration
    # completes and when the method body returns or raises.
    _on_iteration_complete: list[IterationCompleteCallable]
    _on_method_complete: list[MethodCompleteCallable]

    def __init__(
        self,
        *,
        channel_manager: _ChannelManager,
        headers: Headers,
        state_type_name: StateTypeName,
        method: str,
        effect_validation: EffectValidation,
        reactively_state_manager: StateManager,
        reactively_state_type: type,
        task: Optional[TaskEffect] = None,
    ):
        super().__init__(
            channel_manager=channel_manager,
            headers=headers,
            state_type_name=state_type_name,
            method=method,
            effect_validation=effect_validation,
            task=task,
        )

        self._cancelled = None

        self._reactively_state_manager = reactively_state_manager
        self._reactively_state_type = reactively_state_type

        self._on_iteration_complete = []
        self._on_method_complete = []

    def on_iteration_complete(
        self,
        callable: IterationCompleteCallable,
    ) -> None:
        """Register `callable` to be called every time a
        `context.loop(...)` iteration completes during this workflow
        method invocation, with the just-finished iteration number
        passed as `iteration=`. Callables stay registered across
        iterations and are cleared only when the workflow method
        itself completes (see `on_method_complete`) -- callers
        register once per method invocation, not once per iteration.
        Callables may be sync or async; if async, the runtime awaits
        them to completion before continuing.

        Raising from this callable propagates out of the iteration
        body and the entire workflow method gets retried (including
        the iteration whose completion the callable was called).
        """
        self._on_iteration_complete.append(callable)

    def on_method_complete(
        self,
        callable: MethodCompleteCallable,
    ) -> None:
        """Register `callable` to be called when this workflow method body
        finishes -- whether by returning a result or raising a
        declared error (`retrying=False`) or by raising an unexpected
        error that will cause the method to be retried
        (`retrying=True`). Calls exactly once per method invocation;
        afterwards both `on_iteration_complete` and
        `on_method_complete` lists are cleared so a re-run on the same
        context starts with a fresh registration. Callables may be
        sync or async; if async, the runtime awaits them to completion
        before continuing.

        Raising from this callable propagates out of the workflow
        method body and the entire workflow method gets retried.
        """
        self._on_method_complete.append(callable)

    @contextmanager
    def idempotency_seeds(
        self,
        entries: dict[str, Any],
    ) -> Iterator[None]:
        """Push key=value `entries` that scope every
        `Idempotency`-keyed call (`at_least_once`, `at_most_once`,
        `until`, idempotent method calls, inline writer idempotency)
        made inside the `with` block. Nested blocks merge with
        inner-overrides-outer semantics; the outer state is restored
        on exit.

        Exposed on `WorkflowContext` and not `Context` because
        composing extra seeds only makes sense when the context
        already has an idempotency seed -- a `WorkflowContext` always
        does (seeded from the task's UUID).
        """
        with _merge_idempotency_seeds(entries):
            yield

    def within_until(self) -> bool:
        return _within_until.get()

    @property
    def task(self) -> TaskEffect:
        assert self._task is not None
        return self._task

    @property
    def task_id(self) -> uuid.UUID:
        assert self._task is not None
        return uuid.UUID(bytes=self._task.task_id.task_uuid)

    def make_idempotency_key(
        self,
        *,
        alias: str,
        per_workflow: Optional[bool] = None,
    ) -> uuid.UUID:
        """
        Return a deterministic idempotency key for external API calls
        within this workflow.

        When called inside a loop the current iteration number is
        automatically appended to the alias so that each iteration
        gets its own key.  Pass `per_workflow=True` to suppress this
        and produce a single key for the entire workflow regardless of
        iteration.
        """
        iteration = (
            self.task.iteration
            if self.within_loop() and not per_workflow else None
        )

        alias_iteration = make_idempotency_alias(alias, iteration)

        assert alias_iteration is not None

        # NOTE: `self.workflow_id` is the same as the task ID which is
        # also what we use as the seed in IdempotencyManager.
        assert self.workflow_id is not None

        return make_derived_idempotency_key(self.workflow_id, alias_iteration)

    @property
    def workflow_iteration(self) -> Optional[int]:
        """
        Return the current loop iteration when within a control loop, or
        `None` if not currently within a control loop.
        """
        return self.task.iteration if self.within_loop() else None

    async def wait(self, awaitable: Awaitable[WaitT]) -> WaitT:
        """
        Helper that awaits an awaitable taking into account the possibility that this
        workflow context might have been cancelled and handling that appropriately.
        """
        if self._cancelled is None:
            return await awaitable

        awaitable_future = asyncio.ensure_future(awaitable)

        done, pending = await asyncio.wait(  # type: ignore[type-var]
            [self._cancelled, awaitable_future],
            return_when=asyncio.FIRST_COMPLETED,
        )

        if self._cancelled in done:
            awaitable_future.cancel()

        return await awaitable_future

    async def retry_reactively_until(
        self,
        condition: Callable[[], Awaitable[RetryReactivelyUntilT]],
    ) -> RetryReactivelyUntilT:
        """Helper for waiting for something within a `WorkflowContext` that
        re-executes the given callable everytime that some reactive state
        has changed instead of re-executing the entire workflow from the
        beginning (even though it's safe to do so, it is more expensive).
        """
        async with self._reactively_state_manager.reactively(
            # Pylance resolves `WorkflowContext` as a partially-unresolved
            # type due to the circular import between `contexts` and
            # `state_managers` — even though `self` IS a
            # `WorkflowContext` at runtime.
            self,  # type: ignore[arg-type]
            self._reactively_state_type,
            # Should be already authorized when a task was created.
            authorize=None,
        ):
            assert self.react is not None
            iteration = self.react.iteration

            while True:
                try:
                    try:
                        _within_until.set(True)
                        result = await condition()
                    finally:
                        _within_until.set(False)

                    if not isinstance(result, bool):
                        return result
                    elif result:
                        # NOTE: the type system is insufficient to let us
                        # properly exclude types and declare the correct
                        # overloads. Thus, we have to return `True` here,
                        # but tell the type checker to ignore it.
                        return True  # type: ignore[return-value]
                except:
                    raise

                # NOTE: using `self.wait()` so calls through Node.js will
                # be cancelled.
                iteration = await self.wait(self.react.iterate(iteration))


ContextVia: TypeAlias = Literal['schedule', 'spawn', 'reactively', 'until']

TYPE_CHECKER_TIP = (
    'Tip: running a type checker such as `mypy` on your code reports '
    'this mistake before your code runs.'
)


def assert_context_type(
    context: Context | ExternalContext,
    expected: Sequence[type[Context | ExternalContext]],
    *,
    via: ContextVia,
    method: str,
) -> None:
    """Check that `context`, passed to a generated `[...].{via}(...).{method}(...)`
    call, is an instance of one of the `expected` context types.

    Raises a `TypeError` whose message names the kind of method the
    call is allowed from, the call to make instead, and a suggestion
    to run a type checker.
    """
    if any(isinstance(context, expected_type) for expected_type in expected):
        return

    call = f'`{via}(...).{method}(...)`'
    names = ', '.join(
        f'`{expected_type.__name__}`' for expected_type in expected
    )
    expected_names = names if len(expected) == 1 else f'one of {names}'

    if not isinstance(context, (Context, ExternalContext)):
        # Not a context at all, e.g., a request object was passed
        # first or the context was left out entirely.
        passed = '`None`' if context is None else f'`{type(context).__name__}`'
        raise TypeError(
            f'{call} expects {expected_names} as its first argument but '
            f'was passed {passed}. Pass the calling method\'s `context` as '
            f'the first argument, e.g., `{method}(context, ...)`. '
            f'{TYPE_CHECKER_TIP}'
        )

    problem: str
    fix: Optional[str]

    if via == 'schedule' and isinstance(
        context, (WorkflowContext, ExternalContext)
    ):
        if isinstance(context, WorkflowContext):
            problem = '`schedule()` can not be used from within a `workflow`'
        else:
            problem = '`schedule()` can not be used from outside of Reboot'
        fix = (
            'Use `spawn()` instead: replace `.schedule(` with `.spawn(` and '
            'leave the rest of the call as is. Note that `spawn()` returns '
            'a task object rather than a task ID; `await` it to get the '
            "method's response, or use its `.task_id` property."
        )
    elif via == 'schedule' and isinstance(context, WriterContext):
        problem = 'A `writer` can only schedule tasks for its own state'
        fix = (
            'Use `self.ref().schedule(...)` to schedule a task for the '
            "`writer`'s own state, or make the calling method a "
            '`transaction` to schedule a task for another state.'
        )
    elif via == 'schedule' and isinstance(context, ReaderContext):
        problem = (
            'A `reader` can not schedule tasks because a `reader` can not '
            'have effects'
        )
        fix = (
            'Schedule the task from a `writer` (via `self.ref().schedule(...)`) '
            'or a `transaction` instead, or `spawn()` it from a `workflow`.'
        )
    elif via == 'spawn' and isinstance(context, TransactionContext):
        problem = '`spawn()` can not be used from within a `transaction`'
        fix = (
            'Use `schedule()` instead: replace `.spawn(` with `.schedule(` '
            'and leave the rest of the call as is. Note that `schedule()` '
            'returns a task ID rather than a task object, because the task '
            'is only created once the `transaction` completes; to `await` '
            "a task's response, `spawn()` it from a `workflow`."
        )
    elif via == 'spawn' and isinstance(context, WriterContext):
        problem = '`spawn()` can not be used from within a `writer`'
        fix = (
            'Use `self.ref().schedule(...)` instead; a `writer` can only '
            'schedule tasks for its own state, so make the calling method '
            'a `transaction` to run a task for another state. Note that '
            '`schedule()` returns a task ID rather than a task object, '
            'because the task is only created once the `writer` completes; '
            "to `await` a task's response, `spawn()` it from a `workflow`."
        )
    elif via == 'spawn' and isinstance(context, ReaderContext):
        problem = (
            'A `reader` can not spawn tasks because a `reader` can not '
            'have effects'
        )
        fix = (
            'Spawn the task from a `workflow` or from outside of Reboot '
            'instead, or `schedule()` it from a `writer` (via '
            '`self.ref().schedule(...)`) or a `transaction`.'
        )
    elif via == 'reactively':
        problem = (
            '`reactively()` can only be used from within a `reader` or a '
            '`workflow`, or from outside of Reboot'
        )
        fix = (
            'Call the method directly instead: remove `.reactively()` from '
            'the call.'
        )
    elif via == 'until':
        problem = '`until()` can only be used from within a `workflow`'
        fix = (
            'Only a `workflow` can wait for a condition; call the method '
            'directly instead (remove `.until(...)` from the call).'
        )
    else:
        problem = f'`{via}()` can not be used with `{type(context).__name__}`'
        fix = None

    message = (
        f'{problem}: {call} was passed `{type(context).__name__}` but '
        f'expects {expected_names}.'
    )
    if fix is not None:
        message += f' {fix}'
    message += f' {TYPE_CHECKER_TIP}'

    raise TypeError(message)
