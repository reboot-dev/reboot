"""The pytest fixtures that the built-in `reboot.bdd` steps run on."""

import json
import jsonpath_ng
import pytest
from dataclasses import dataclass, field
from google.protobuf import json_format
from google.protobuf.message import Message
from jsonpath_ng.exceptions import JSONPathError
from pydantic import ValidationError
from reboot.aio import signals
from reboot.aio.aborted import Aborted
from reboot.aio.external import ExternalContext
from reboot.aio.tests import Reboot
from reboot.api import Model
from reboot.bdd.loop import EventLoopThread, start_event_loop, stop_event_loop
from typing import Any, Callable, Iterator, Optional, Union


@pytest.fixture(autouse=True)
def reboot_event_loop() -> Iterator[EventLoopThread]:
    """The scenario's event loop, which `reboot.bdd.run()` and every
    `async def` step run on. One loop per scenario, the way one
    application runs on one event loop under `rbt dev run` and
    `rbt serve`."""
    # The process signal handlers can only be installed on the main
    # thread, which pytest runs fixtures on; a scenario's steps run on
    # the loop's thread, where starting an Envoy in Docker would
    # otherwise install them and fail.
    signals.initialize()
    signals.install_cleanup(signals.TERMINATING_SIGNALS_FOR_SERVERS)
    event_loop = start_event_loop()
    try:
        yield event_loop
    finally:
        stop_event_loop(event_loop)


@pytest.fixture
def rbt(reboot_event_loop: EventLoopThread) -> Iterator[Reboot]:
    """A fresh `Reboot` test harness on the scenario's event loop,
    started before the scenario and stopped after it."""
    reboot = Reboot()
    reboot_event_loop.run(reboot.start())
    try:
        yield reboot
    finally:
        reboot_event_loop.run(reboot.stop())


# A JSON value: what property values, and the values saved under a
# name, are made of.
JsonValue = Union[None, bool, int, float, str, list['JsonValue'],
                  dict[str, 'JsonValue']]


def _json_object(
    message_or_model: Union[Message, Model],
) -> dict[str, 'JsonValue']:
    """The given message or model as its JSON object (a message via
    its canonical JSON, with fields without presence included, so
    every property is reachable, and a model via its JSON-mode dump,
    so e.g. a datetime is its string)."""
    if isinstance(message_or_model, Message):
        return json_format.MessageToDict(
            message_or_model,
            preserving_proto_field_name=True,
            always_print_fields_with_no_presence=True,
        )
    return message_or_model.model_dump(mode='json')


@dataclass(frozen=True)
class PropertyPath:
    """One property's path, in both its forms."""

    # The path as the developer wrote it, e.g. 'owners["main"].name';
    # what error messages say.
    text: str

    # The parsed path; what finds, updates, and grammar walks use.
    expression: jsonpath_ng.JSONPath

    @staticmethod
    def create(text: str) -> 'PropertyPath':
        """The property path the given text parses as."""
        try:
            expression = jsonpath_ng.parse(text)
        except JSONPathError as error:
            raise ValueError(f"Invalid property `{text}`: {error}") from error
        return PropertyPath(text=text, expression=expression)


@dataclass(frozen=True)
class Assignment:
    """A `path=value` clause in a call's 'with' list: the value put
    at the property's path when building the request."""

    # The property assigned.
    path: PropertyPath

    # The value put there, as written (JSON).
    value: JsonValue


def _json_type(value: Any) -> type:
    """The JSON type of a value: `int` and `float` are one number
    type, and `bool` is its own."""
    if isinstance(value, bool):
        return bool
    if isinstance(value, (int, float)):
        return float
    return type(value)


def _zero_indexed(path: jsonpath_ng.JSONPath) -> jsonpath_ng.JSONPath:
    """The path with every list index replaced by [0]; a path's list
    element type is the same at every index."""
    match path:
        case jsonpath_ng.Child(left=left, right=right):
            return jsonpath_ng.Child(_zero_indexed(left), _zero_indexed(right))
        case jsonpath_ng.Index():
            return jsonpath_ng.Index(0)
        case _:
            return path


@dataclass
class World:
    """What one scenario's steps have accumulated so far.

    Mutable: steps write what they did so that later steps can assert
    on it.
    """

    # The generated client class of each of the application's state
    # types, under the full state type name (e.g. 'bank.v1.Account');
    # empty until the application is up.
    client_types: dict[str, type] = field(default_factory=dict)

    # The harness the scenario's application runs on; `None` until
    # the application is up.
    rbt: Optional[Reboot] = None

    # The scenario's name; every context's name begins with it.
    name: Optional[str] = None

    # The context every call shares, once a 'Given a shared context'
    # step has created it; while `None`, each call runs on a fresh
    # context, the way each external call in production arrives with
    # its own.
    shared_context: Optional[ExternalContext] = None

    # Number of contexts created so far; makes each context's name
    # unique within the scenario.
    contexts_created: int = 0

    # The response of the most recent call a step made.
    response: Optional[Any] = None

    # The id of the state the most recent 'creates' step created,
    # given by the step or made up by the factory.
    created_state_id: Optional[str] = None

    # The id of the task the most recent 'spawns' step spawned, as
    # JSON.
    spawned_task_id: Optional[JsonValue] = None

    # Values saved under a name, as JSON; later steps say '<name>' to
    # use.
    saved: dict[str, JsonValue] = field(default_factory=dict)

    # The columns of the scenario's Examples table, for a Scenario
    # Outline; empty for a plain scenario. A '<name>' naming a column
    # is the table's value, substituted before any step runs, so a
    # save may not use a column's name.
    example_columns: frozenset[str] = frozenset()

    # The error the most recent 'attempts' step's call aborted with,
    # or `None` if that call succeeded.
    aborted: Optional[Aborted] = None

    # The bearer token of each user the scenario has declared, by
    # user id, `None` for a user declared unauthenticated; a step says
    # 'as "user id",' to call as one.
    tokens: dict[str, Optional[str]] = field(default_factory=dict)

    # The user the shared context calls as, once one exists.
    shared_user: Optional[str] = None

    def context(self, user: str) -> ExternalContext:
        """The context for one step's call as the given user: the
        scenario's shared context once an 'as "...", a shared context'
        step has created it, which must be for the same user,
        otherwise a fresh context."""
        if self.shared_context is not None:
            if user != self.shared_user:
                raise ValueError(
                    f'The shared context calls as "{self.shared_user}", so '
                    f'this step cannot call as "{user}"'
                )
            return self.shared_context
        if self.rbt is None:
            raise ValueError(
                "The application is not up; start the scenario with "
                "'Given the application is up'"
            )
        self.contexts_created += 1
        return self.rbt.create_external_context(
            name=f"{self.name}-{self.contexts_created}",
            bearer_token=self.token(user),
        )

    def _require_declared(self, user: str) -> None:
        """Raises unless the scenario has declared the named user."""
        if user not in self.tokens:
            raise ValueError(
                f'"{user}" is not a user the scenario has declared; say '
                f'\'Given "{user}" is an authenticated user\', '
                f'\'Given "{user}" is an unauthenticated user\' or '
                f'\'Given "{user}" has the bearer token "..."\' first'
            )

    def token(self, user: str) -> Optional[str]:
        """The bearer token of the named user, `None` for one declared
        unauthenticated; raises for a user the scenario has not
        declared."""
        self._require_declared(user)
        return self.tokens[user]

    def declare_user(
        self,
        user_id: str,
        bearer_token: Optional[str],
    ) -> None:
        """Declares a user the scenario's steps may call as, by the
        bearer token their calls carry, `None` for none; declaring a
        user again changes what they carry."""
        self.tokens[user_id] = bearer_token

    def share_context(self, user: str) -> None:
        """Makes every call from here on share one context, calling
        as the given user."""
        self.shared_context = self.context(user)
        self.shared_user = user

    def save(self, name: str, value: JsonValue) -> None:
        """Saves the value under the name, for later steps to say
        '<name>' to use; raises for a name that is a column of the
        scenario's Examples table, whose value '<name>' already is."""
        if name in self.example_columns:
            raise ValueError(
                f"`{name}` is a column of the scenario's Examples table, "
                f"so <{name}> in a step is the table's value, never this "
                "one; save it under another name"
            )
        self.saved[name] = value

    def client_type(self, state_type: str) -> Any:
        """The generated client class of the named state type, named
        by its full state type name (e.g. 'bank.v1.Account') or, when
        only one state type goes by it, its unqualified name (e.g.
        'Account'); raises if the application serves no such state
        type or the unqualified name is ambiguous."""
        client_type = self.client_types.get(state_type)
        if client_type is not None:
            return client_type
        qualified = sorted(
            name for name in self.client_types
            if name.endswith('.' + state_type)
        )
        if len(qualified) == 1:
            return self.client_types[qualified[0]]
        if len(qualified) > 1:
            raise ValueError(
                f"`{state_type}` names more than one of the "
                "application's state types; say one of: " +
                ', '.join(f'`{name}`' for name in qualified)
            )
        raise ValueError(
            f"Unknown state type `{state_type}`; the application "
            "serves: " +
            (', '.join(sorted(self.client_types)) or "no state types")
        )

    def factory(
        self,
        *,
        state_type: str,
        method: str,
    ) -> Callable[..., Any]:
        """The named factory on the state type's generated client
        class; raises if there is none."""
        factory = getattr(self.client_type(state_type), method, None)
        if not callable(factory):
            raise ValueError(f"`{state_type}` has no factory `{method}`")
        return factory

    def is_reader(self, *, state_type: str, method: str) -> bool:
        """Whether the named method is one of the named state type's
        unary readers."""
        # TODO: this is a bit of a hack! We check to see if
        # `StateType.reactively().method()` exists to know if it is a
        # reader because `reactively` is only for readers.
        reference = self.client_type(state_type).ref('is-reader')
        return hasattr(reference.reactively(), method)

    def request_type(
        self,
        *,
        state_type: str,
        method: str,
    ) -> Optional[type]:
        """The request type of the named method, from the generated
        client class's `<Method>Request` alias, or `None` when the
        method takes no request."""
        client_type = self.client_type(state_type)
        alias = method.replace('_', '').lower() + 'request'
        for name in dir(client_type):
            if name.lower() == alias:
                request_type = getattr(client_type, name)
                if isinstance(request_type, type):
                    return request_type
        return None

    def task_type(
        self,
        *,
        state_type: str,
        method: str,
    ) -> Optional[type]:
        """The task type of the named method, from the generated
        client class's `<Method>Task` class, or `None` when there is
        none."""
        client_type = self.client_type(state_type)
        alias = method.replace('_', '').lower() + 'task'
        for name in dir(client_type):
            if name.lower() == alias:
                task_type = getattr(client_type, name)
                if isinstance(task_type, type):
                    return task_type
        return None

    async def spawn(
        self,
        *,
        state_type: str,
        state_id: str,
        method: str,
        assignments: Union[dict[str, JsonValue], list[Assignment]],
        user: str,
    ) -> Any:
        """Spawns the named method as a task on the named state, as
        the given user, using the specified
        `assignments` to create a request, and returns the task
        handle to await for its response."""
        reference = self.client_type(state_type).ref(state_id)
        spawn = getattr(reference.spawn(), method, None)
        if not callable(spawn):
            raise ValueError(f"`{state_type}` has no method `{method}`")
        if not assignments:
            return await spawn(self.context(user))
        return await spawn(
            self.context(user),
            self.request(
                state_type=state_type,
                method=method,
                assignments=assignments,
            ),
        )

    def request(
        self,
        *,
        state_type: str,
        method: str,
        assignments: Union[dict[str, JsonValue], list[Assignment]],
    ) -> Any:
        """Returns a request with properties derived from the assignments,
        validated by the named method's request type. A dotted
        property name nests, e.g., 'owner.name' describes the
        request's `owner` message's `name`."""
        request_type = self.request_type(state_type=state_type, method=method)
        if request_type is None:
            raise ValueError(
                f"`{state_type}`'s `{method}` takes no properties"
            )

        if isinstance(assignments, dict):
            assignments = [
                Assignment(path=PropertyPath.create(text), value=value)
                for text, value in assignments.items()
            ]

        # Build the JSON object a property at a time, where a property
        # may add but never overwrite (a `find` hit is a collision).
        result: dict[str, JsonValue] = {}

        def validate(path: PropertyPath) -> None:
            """Raises for a path that names zero or many locations,
            because building a request needs each property to name
            exactly one place to update."""

            def confirmed(expression: jsonpath_ng.JSONPath) -> None:
                match expression:
                    case jsonpath_ng.Child(left=left, right=right):
                        confirmed(left)
                        confirmed(right)
                    case jsonpath_ng.Root():
                        pass
                    case jsonpath_ng.Fields(fields=(_,)):
                        pass
                    case jsonpath_ng.Index(indices=(_,)):
                        pass
                    case _:
                        raise ValueError(
                            f"Property `{path.text}` may only say "
                            'fields, ["key"]s, and [index]es, but '
                            f"says: {expression}"
                        )

            confirmed(path.expression)

        for assignment in assignments:
            # For creating a JSON object we disallow certain kinds of
            # paths that just don't make sense or are not useful.
            validate(assignment.path)
            if assignment.path.expression.find(result):
                raise ValueError(
                    f"Property `{assignment.path.text}` collides with "
                    "another property"
                )

            def update(
                # Object being updated.
                child: Any,
                # Containing object.
                parent: Any,
                # Field of containing object being updated.
                field: Any,
            ) -> Any:
                if isinstance(parent, list):
                    # A list index past a list's current end, e.g.,
                    # 'foo[5]' where the list only has 1 element, will
                    # pad the list with `{}` placeholders, even if the
                    # list is of strings or numbers, so we also
                    # confirm the value's JSON type matches the other
                    # elements': that refuses both a padded gap in a
                    # list of scalars and a mistyped element, while a
                    # gap in a list of objects stays, validated below
                    # as default-valued elements. The real backstop is
                    # doing the `model_validate` for Pydantic types
                    # and `ParseDict` for protobuf below, this is just
                    # extra.
                    for index, element in enumerate(parent):
                        if index == field:
                            continue
                        if _json_type(element) is not _json_type(
                            assignment.value
                        ):
                            raise ValueError(
                                f"Property `{assignment.path.text}` indexes "
                                f"into a list whose element "
                                f"{element!r} is not the same type "
                                "as its value"
                            )
                # There is currently a bug in jsonpath-ng where
                # returning a value does not always store it correctly
                # so we need to store it ourselves and return it until
                # h2non/jsonpath-ng#238 gets fixed.
                parent[field] = assignment.value
                return assignment.value

            try:
                # NOTE: we are using the version of `update_or_create`
                # that takes a callable because that forces
                # jsonpath-ng to raise a KeyError if a path attempts
                # to do a list index in an already existing dict
                # (i.e., treating the dict like a list incorrectly).
                assignment.path.expression.update_or_create(result, update)
            except (KeyError, TypeError) as error:
                raise ValueError(
                    f"Property `{assignment.path.text}` cannot be "
                    "applied to "
                    "what is already built"
                ) from error
        # If the request is a Pydantic model, we use `model_validate`.
        if hasattr(request_type, 'model_validate'):
            # Guard against pydantic's default of ignoring unknown
            # keys, which would make a mistyped property a silent
            # no-op.
            model_fields = getattr(request_type, 'model_fields')
            for name in result:
                if name not in model_fields:
                    raise ValueError(
                        f"`{request_type.__name__}` has no property "
                        f"`{name}`"
                    )
            try:
                return request_type.model_validate(result)
            except ValidationError as error:
                raise ValueError(
                    f"Could not build a `{request_type.__name__}` "
                    f"from {json.dumps(result)}: {error}"
                ) from error
        # The request must be protobuf, use `ParseDict`.
        try:
            return json_format.ParseDict(result, request_type())
        except json_format.ParseError as error:
            raise ValueError(
                f"Could not build a `{request_type.__name__}` from "
                f"{json.dumps(result)}: {error}"
            ) from error

    async def call(
        self,
        *,
        state_type: str,
        state_id: str,
        method: str,
        assignments: Union[dict[str, JsonValue], list[Assignment]],
        user: str,
    ) -> Any:
        """Returns the response from calling the named method on the
        named state, as the given user, using the
        specified `assignments` to create a request."""
        reference = self.client_type(state_type).ref(state_id)
        method_callable = getattr(reference, method, None)
        if not callable(method_callable):
            raise ValueError(f"`{state_type}` has no method `{method}`")
        if not assignments:
            return await method_callable(self.context(user))
        return await method_callable(
            self.context(user),
            self.request(
                state_type=state_type,
                method=method,
                assignments=assignments,
            ),
        )


@pytest.fixture
def world(_pytest_bdd_example: dict[str, str]) -> World:
    """The scenario's world: the mutable record its steps share. The
    example is pytest-bdd's: the Examples row a Scenario Outline runs
    with, and empty for a plain scenario."""
    return World(example_columns=frozenset(_pytest_bdd_example))
