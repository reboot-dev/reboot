from reboot.api import API, Field, Methods, Model, Reader, Tool, Type, Writer
from shared.errors import OverdraftError


class AccountState(Model):
    balance: float = Field(
        tag=1,
        description="What the account holds, in dollars: every deposit "
        "added and every withdrawal and transfer out taken away, and "
        "never below zero.",
    )


class BalanceResponse(Model):
    amount: float = Field(tag=1)


class DepositRequest(Model):
    amount: float = Field(tag=1)


class WithdrawRequest(Model):
    amount: float = Field(tag=1)


AccountMethods = Methods(
    # Must use this method to create an instance of Account.
    open=Writer(
        request=None,
        response=None,
        factory=True,
        description="Bring the account into existence with a zero "
        "balance.",
        mcp=None,
    ),
    balance=Reader(
        request=None,
        response=BalanceResponse,
        description="Get the balance of an account. Get the "
        "`account_id` from `bank_account_balances`.",
        mcp=Tool(),
    ),
    deposit=Writer(
        request=DepositRequest,
        response=None,
        description="Deposit an amount into an account. Get "
        "the `account_id` from `bank_account_balances`.",
        mcp=Tool(),
    ),
    withdraw=Writer(
        request=WithdrawRequest,
        response=None,
        errors=[OverdraftError],
        description="Withdraw an amount from an account; "
        "fails with an overdraft error if the balance is "
        "insufficient. Get the `account_id` from "
        "`bank_account_balances`.",
        mcp=Tool(),
    ),
    interest=Writer(
        request=None,
        response=None,
        description="Credit one period's interest at the current rate.",
        mcp=None,
    ),
)

api = API(
    Account=Type(
        state=AccountState,
        methods=AccountMethods,
        description="One account's money, and the consistency boundary "
        "for every change to it.",
    ),
)
