//! Bounded host ownership of explicit, confirmed pre-handoff Abort work.
//! No retries: an actor-only terminal RPC with a lost ACK is not safe to repeat.
use crate::{
    application_host::{HostRecovery, RecoveryCancellation},
    durable_coordinator::{CoordinatorSidecar, DurableRootCoordinator, ParticipantResolver},
    durable_participant::{ParticipantSidecar, StartedLocalTransaction},
    runtime::TransactionContext,
};
use std::{
    future::Future,
    pin::Pin,
    sync::{Arc, Mutex},
};
use tokio::sync::{OwnedSemaphorePermit, Semaphore, mpsc, oneshot};
use tokio::task::JoinSet;
use tonic::Status;
type Work = Pin<Box<dyn Future<Output = Result<(), Status>> + Send>>;
#[cfg(test)]
type AdmissionProbe = (
    std::sync::mpsc::Sender<()>,
    Arc<Mutex<std::sync::mpsc::Receiver<()>>>,
);
// The queue owns the latch, not an async stack local: this Drop runs before
// captured work/registration and capacity, even if the worker is never polled.
struct Job {
    cancel: RecoveryCancellation,
    accounted: bool,
    work: Option<Work>,
    reply: Option<oneshot::Sender<Result<(), Status>>>,
    _permit: Option<OwnedSemaphorePermit>,
    // Shared work can return captured capacity inside its final poll. Track the
    // actual Job aggregate until ALL fields have dropped, not the reply/result.
    #[cfg(feature = "test-support")]
    _retirement: JobRetirement,
}
#[cfg(feature = "test-support")]
struct JobRetirement(Arc<Mutex<State>>);
#[cfg(feature = "test-support")]
impl Drop for JobRetirement {
    fn drop(&mut self) {
        self.0.lock().unwrap().owned_jobs -= 1;
    }
}
impl Job {
    fn new(
        owner: &ExplicitAbortOwner,
        work: Work,
        reply: oneshot::Sender<Result<(), Status>>,
        permit: Option<OwnedSemaphorePermit>,
    ) -> Self {
        // Admission has already established the actual host cancellation owner.
        let cancel = owner.state.lock().unwrap().host_cancel.clone().unwrap();
        #[cfg(feature = "test-support")]
        let retirement = {
            owner.state.lock().unwrap().owned_jobs += 1;
            JobRetirement(owner.state.clone())
        };
        Self {
            cancel,
            accounted: false,
            work: Some(work),
            reply: Some(reply),
            _permit: permit,
            #[cfg(feature = "test-support")]
            _retirement: retirement,
        }
    }
    fn fail_before_drop(&mut self) {
        if !self.accounted {
            self.cancel.fail();
            self.accounted = true;
        }
    }
}
impl Drop for Job {
    fn drop(&mut self) {
        self.fail_before_drop();
    }
}
// Aggregate ownership makes Drop run BEFORE the running future (and its root
// token) or capacity permit can be destroyed, including Tokio abort/unwind.
// A stack-local latch beside `work` would depend on async generator drop order.
struct RunningAbort {
    // Destroy the captured work/root token before returning ordinary capacity.
    // Drop still latches through job before either field is destroyed.
    work: Pin<Box<tokio::time::Timeout<Work>>>,
    job: Job,
}
impl RunningAbort {
    fn new(mut job: Job, timeout: std::time::Duration) -> Self {
        let work = Box::pin(tokio::time::timeout(timeout, job.work.take().unwrap()));
        Self { job, work }
    }
}
impl Drop for RunningAbort {
    fn drop(&mut self) {
        // The moved Job keeps its latch armed throughout transfer. Latch here
        // before either aggregate field drops; Job then skips a duplicate fail.
        self.job.fail_before_drop();
    }
}
struct State {
    active: bool,
    host_cancel: Option<RecoveryCancellation>,
    receiver: Option<mpsc::Receiver<Job>>,
    registered_roots: std::collections::HashSet<uuid::Uuid>,
    retained_shared_permits: Vec<OwnedSemaphorePermit>,
    // Actual queued/running Job lifetime, not transaction/terminal membership.
    #[cfg(feature = "test-support")]
    owned_jobs: usize,
}
#[derive(Clone)]
pub struct ExplicitAbortOwner {
    sender: mpsc::Sender<Job>,
    state: Arc<Mutex<State>>,
    capacity: Arc<Semaphore>,
    limit: usize,
    timeout: std::time::Duration,
    failure: tokio::sync::watch::Sender<Option<Status>>,
    #[cfg(test)]
    admission_arrived: Arc<Mutex<Option<AdmissionProbe>>>,
}
pub struct ExplicitAbortRecovery {
    owner: ExplicitAbortOwner,
}
// Captured before future construction, including queued/unpolled work. A
// failed/dropped shared obligation remains capacity-counted until host restart.
struct SharedAbortPermit {
    owner: ExplicitAbortOwner,
    permit: Option<OwnedSemaphorePermit>,
    completed: bool,
}
impl Drop for SharedAbortPermit {
    fn drop(&mut self) {
        if !self.completed
            && let Some(permit) = self.permit.take()
        {
            self.owner
                .state
                .lock()
                .unwrap()
                .retained_shared_permits
                .push(permit);
        }
    }
}

struct Active(Arc<Mutex<State>>, Arc<Semaphore>, usize);
impl Drop for Active {
    fn drop(&mut self) {
        let mut state = self.0.lock().unwrap();
        state.active = false;
        if (!state.registered_roots.is_empty()
            || !state.retained_shared_permits.is_empty()
            || self.1.available_permits() != self.2)
            && let Some(cancel) = &state.host_cancel
        {
            cancel.fail();
        }
    }
}
impl ExplicitAbortOwner {
    pub fn new(capacity: usize) -> Result<Self, Status> {
        if capacity == 0 || capacity > 1024 {
            return Err(Status::invalid_argument(
                "explicit Abort capacity must be 1..=1024",
            ));
        }
        let (sender, receiver) = mpsc::channel(capacity);
        Ok(Self {
            sender,
            state: Arc::new(Mutex::new(State {
                active: false,
                host_cancel: None,
                receiver: Some(receiver),
                registered_roots: Default::default(),
                retained_shared_permits: Vec::new(),
                #[cfg(feature = "test-support")]
                owned_jobs: 0,
            })),
            capacity: Arc::new(Semaphore::new(capacity)),
            limit: capacity,
            timeout: std::time::Duration::from_secs(30),
            failure: tokio::sync::watch::channel(None).0,
            #[cfg(test)]
            admission_arrived: Arc::new(Mutex::new(None)),
        })
    }
    pub fn with_timeout(mut self, timeout: std::time::Duration) -> Result<Self, Status> {
        if timeout.is_zero() || timeout > std::time::Duration::from_secs(300) {
            return Err(Status::invalid_argument(
                "explicit Abort timeout must be nonzero and <=300 seconds",
            ));
        }
        self.timeout = timeout;
        Ok(self)
    }
    #[cfg(test)]
    pub(crate) fn fail_for_test(&self) {
        self.failure
            .send_replace(Some(Status::unavailable("test sticky owner failure")));
    }

    pub(crate) fn validate_builtin_root(&self, root: uuid::Uuid) -> Result<(), Status> {
        let state = self.state.lock().unwrap();
        if !state.active
            || self.failure.borrow().is_some()
            || !state.registered_roots.contains(&root)
        {
            return Err(Status::failed_precondition(
                "builtin root owner stopped or root unregistered",
            ));
        }
        Ok(())
    }

    // The shutdown seal (Active::drop) uses this exact mutex. Check admission
    // BEFORE taking capacity, and register the root in the same critical section.
    // Only plain semaphore permits are created here: no participant callbacks,
    // token/guard destruction, native I/O, or awaits may run under this lock.
    fn reserve_admission(
        &self,
        root: Option<uuid::Uuid>,
        inactive: &'static str,
        full: &'static str,
    ) -> Result<OwnedSemaphorePermit, Status> {
        #[cfg(test)]
        {
            let probe = self.admission_arrived.lock().unwrap().clone();
            if let Some((arrived, resume)) = probe {
                arrived.send(()).unwrap();
                resume
                    .lock()
                    .unwrap()
                    .recv_timeout(std::time::Duration::from_secs(2))
                    .unwrap();
            }
        }
        let mut state = self.state.lock().unwrap();
        if !state.active || self.failure.borrow().is_some() {
            return Err(Status::failed_precondition(inactive));
        }
        if root.is_some_and(|root| state.registered_roots.contains(&root)) {
            return Err(Status::failed_precondition(
                "root execution already registered",
            ));
        }
        let permit = self
            .capacity
            .clone()
            .try_acquire_owned()
            .map_err(|_| Status::resource_exhausted(full))?;
        if let Some(root) = root {
            state.registered_roots.insert(root);
        }
        Ok(permit)
    }

    /// Bounded factual observation of this exact owner's retired obligations.
    /// This is NOT an admission/authority reservation or a ledger settlement:
    /// callers must quiesce their producers, and later admission can invalidate
    /// the observation. Replies/actor availability are not retirement evidence.
    /// Checks actual state after captured work and capacity permits have dropped;
    /// never consumes capacity, clears failures, or releases unknown ownership.
    #[cfg(feature = "test-support")]
    pub async fn wait_for_idle_for_test(&self, bound: std::time::Duration) -> Result<(), Status> {
        if bound.is_zero() || bound > std::time::Duration::from_secs(300) {
            return Err(Status::invalid_argument(
                "owner idle bound must be nonzero and <=300 seconds",
            ));
        }
        let deadline = tokio::time::Instant::now() + bound;
        loop {
            {
                // Same mutex as admission/sealing and retained obligation Drop.
                let state = self.state.lock().unwrap();
                if let Some(error) = self.failure.borrow().clone() {
                    return Err(error);
                }
                // Job destruction may latch only the actual host, not the
                // owner's watch Sender. Full restored capacity cannot hide it.
                if state
                    .host_cancel
                    .as_ref()
                    .is_some_and(|cancel| cancel.failure_latched_for_test())
                {
                    return Err(Status::unavailable(
                        "explicit Abort owner has sticky host failure",
                    ));
                }
                if state.registered_roots.is_empty()
                    && state.retained_shared_permits.is_empty()
                    && state.owned_jobs == 0
                    && self.capacity.available_permits() == self.limit
                {
                    return Ok(());
                }
            }
            if tokio::time::Instant::now() >= deadline {
                return Err(Status::deadline_exceeded(
                    "explicit Abort owner did not retire within bound",
                ));
            }
            // Poll the real predicates, not a decorative completion signal.
            // Yield lets the owned worker perform work/token/permit destruction.
            tokio::task::yield_now().await;
        }
    }

    pub fn recovery_registration(&self) -> ExplicitAbortRecovery {
        ExplicitAbortRecovery {
            owner: self.clone(),
        }
    }
    /// Reserve before sealing. Once sealed, transfer has no further await; queued
    /// work owns a disarmed incarnation even if shutdown drops it without polling.
    pub async fn abort<P: ParticipantSidecar, C: CoordinatorSidecar, R: ParticipantResolver>(
        &self,
        mut local: StartedLocalTransaction<P>,
        context: TransactionContext,
        coordinator: DurableRootCoordinator<C, R>,
    ) -> Result<(), Status> {
        let permit = match self.reserve_admission(
            None,
            "explicit Abort owner is not registered and active; ownership retained",
            "explicit Abort owner is full; ownership retained",
        ) {
            Ok(permit) => permit,
            Err(error) => {
                // Never invoke local cleanup while holding the shutdown mutex.
                local.handoff_to_durable_recovery();
                if error.code() == tonic::Code::ResourceExhausted {
                    self.failure.send_replace(Some(Status::resource_exhausted(
                        "explicit Abort admission failed; ownership retained",
                    )));
                }
                return Err(error);
            }
        };
        let work = match coordinator.own_explicit_abort(local, context).await {
            Ok(work) => work,
            Err(error) => {
                self.failure.send_replace(Some(error.clone()));
                return Err(error);
            }
        };
        let (reply, observer) = oneshot::channel();
        let job = Job::new(self, work, reply, Some(permit));
        let send_result = {
            let state = self.state.lock().unwrap();
            if !state.active {
                drop(state);
                return Err(Status::unavailable(
                    "explicit Abort host stopped; ownership retained",
                ));
            }
            self.sender.try_send(job)
        };
        // A rejected Job may contain a root token whose Drop takes state.
        send_result
            .map_err(|_| Status::unavailable("explicit Abort host stopped; ownership retained"))?;
        #[cfg(feature = "test-support")]
        let _observer_drop = ObserverDrop::new();
        observer.await.map_err(|_| {
            Status::unavailable("explicit Abort stopped before ACK; ownership retained")
        })?
    }
}
/// Pre-Load execution registration, separate from an admitted actor token.
/// Dropping an unfinished Load never fabricates local participant authority.
pub struct RegisteredRoot<C: CoordinatorSidecar, R: ParticipantResolver> {
    context: TransactionContext,
    original_context: TransactionContext,
    admitted: bool,
    coordinator: DurableRootCoordinator<C, R>,
    reservation: Option<(ExplicitAbortOwner, OwnedSemaphorePermit)>,
    token: Option<RootRegistrationToken>,
}
struct RootRegistrationToken {
    owner: ExplicitAbortOwner,
    root: uuid::Uuid,
    shared: bool,
    finished: bool,
}
impl Drop for RootRegistrationToken {
    fn drop(&mut self) {
        if self.shared && !self.finished {
            if let Some(cancel) = &self.owner.state.lock().unwrap().host_cancel {
                cancel.fail();
            }
            self.owner.failure.send_replace(Some(Status::unavailable(
                "shared root registration retained without acknowledged completion",
            )));
            return;
        }
        self.owner
            .state
            .lock()
            .unwrap()
            .registered_roots
            .remove(&self.root);
    }
}
impl<C: CoordinatorSidecar, R: ParticipantResolver> RegisteredRoot<C, R> {
    pub fn before_load<P: ParticipantSidecar>(
        participant: &crate::durable_participant::DurableActorParticipant<P>,
        context: TransactionContext,
        coordinator: DurableRootCoordinator<C, R>,
        owner: Option<&ExplicitAbortOwner>,
    ) -> Result<Self, Status> {
        let mut registered = Self {
            original_context: context.clone(),
            admitted: false,
            context,
            coordinator,
            reservation: None,
            token: None,
        };
        if registered.context.is_fresh_root()
            && registered.context.mode() == crate::runtime::TransactionMode::Exclusive
            && registered.context.headers().idempotency_key.is_none()
            && let Some(owner) = owner
        {
            registered
                .coordinator
                .validate_root_registration(participant, &registered.context)?;
            let root = registered.context.transaction_root_id();
            let permit = owner.reserve_admission(
                Some(root),
                "registered root owner is not active",
                "registered root owner is full",
            )?;
            #[cfg(feature = "test-support")]
            if let Some(path) = std::env::var_os("REBOOT_TEST_REGISTERED_LOAD_PENDING") {
                std::fs::write(
                    std::path::PathBuf::from(path).with_extension("registered"),
                    b"root registered before start_owned Load",
                )
                .unwrap();
            }
            registered.token = Some(RootRegistrationToken {
                owner: owner.clone(),
                root,
                shared: false,
                finished: false,
            });
            registered.reservation = Some((owner.clone(), permit));
        }
        Ok(registered)
    }

    /// Opt-in registration BEFORE Load. A shared execution is not an exclusive
    /// tree, and only the registered guard may later install outbound authority.
    pub fn admit_shared_existing_writers<P: ParticipantSidecar>(
        participant: &crate::durable_participant::DurableActorParticipant<P>,
        mut context: TransactionContext,
        coordinator: DurableRootCoordinator<C, R>,
        owner: &ExplicitAbortOwner,
    ) -> Result<Self, Status> {
        if !context.is_fresh_root()
            || context.mode() != crate::runtime::TransactionMode::Shared
            || context.headers().idempotency_key.is_some()
            || context.headers().task_schedule.is_some()
        {
            return Err(Status::failed_precondition(
                "shared existing writers require a fresh non-idempotent shared root",
            ));
        }
        coordinator.validate_root_registration(participant, &context)?;
        let root = context.transaction_root_id();
        let permit = owner.reserve_admission(
            Some(root),
            "registered shared root owner is not active",
            "registered shared root owner is full",
        )?;
        let original_context = context.clone();
        let mut token = RootRegistrationToken {
            owner: owner.clone(),
            root,
            shared: true,
            finished: false,
        };
        if let Err(error) = context.bind_shared_writer_root(Arc::new(
            crate::shared_existing_writer_root::SharedWriterRootPolicy::registered(
                root,
                owner.clone(),
            ),
        )) {
            token.finished = true;
            return Err(error);
        }
        Ok(Self {
            context,
            original_context,
            admitted: false,
            coordinator,
            reservation: Some((owner.clone(), permit)),
            token: Some(token),
        })
    }

    pub async fn admitted<P: ParticipantSidecar>(
        mut self,
        mut local: StartedLocalTransaction<P>,
    ) -> Result<RootHandlerGuard<P, C, R>, Status> {
        if let Some((owner, _)) = &self.reservation {
            if self.context.shared_existing_writer_root() {
                self.coordinator
                    .validate_shared_writer_local(&local, &self.context)?;
            } else {
                self.coordinator
                    .validate_explicit_abort(&local, &self.context)?;
            }
            local.reserve_registered_execution(&self.context).await?;
            self.admitted = true;
            if !owner.state.lock().unwrap().active || owner.failure.borrow().is_some() {
                local.handoff_to_durable_recovery();
                return Err(Status::unavailable(
                    "registered root host stopped during admission",
                ));
            }
        }
        Ok(RootHandlerGuard {
            local: Some(local),
            constructor_child: None,
            admission_context: self.original_context.clone(),
            pre_handler_cleanup: std::sync::atomic::AtomicBool::new(true),
            context: self.context.clone(),
            coordinator: self.coordinator.clone(),
            reservation: self.reservation.take(),
            registration: self.token.take(),
            inbound: None,
            task_dispatcher: std::sync::Mutex::new(None),
            builtin_map_active: None,
            shared_handler_registration: Mutex::new(None),
        })
    }
}

impl<C: CoordinatorSidecar, R: ParticipantResolver> Drop for RegisteredRoot<C, R> {
    fn drop(&mut self) {
        // No admitted capability has been transferred to a guard. Dropped Load
        // uses the participant's own captured cleanup slot, not root fanout.
        if !self.admitted
            && let Some(token) = &mut self.token
        {
            token.finished = true;
        }
    }
}

/// Generated pre-handler lifetime. An attached active owner reserves capacity
/// before effects; cancellation submits directly, never recursively queues work.
/// The awaited handler temporary drops before this enclosing lifetime does.
pub struct RootHandlerGuard<P: ParticipantSidecar, C: CoordinatorSidecar, R: ParticipantResolver> {
    local: Option<StartedLocalTransaction<P>>,
    constructor_child: Option<(crate::registered_local::RegisteredAdapterBinding, crate::registered_local::GeneratedLocalAdapterConfig)>,
    // Authorization runs before host execution capabilities are installed.
    // Retain that immutable identity separately from the live handler context.
    admission_context: TransactionContext,
    pre_handler_cleanup: std::sync::atomic::AtomicBool,
    context: TransactionContext,
    coordinator: DurableRootCoordinator<C, R>,
    reservation: Option<(ExplicitAbortOwner, OwnedSemaphorePermit)>,
    registration: Option<RootRegistrationToken>,
    task_dispatcher: std::sync::Mutex<Option<crate::one_shot_tasks::OneShotTasks>>,
    builtin_map_active: Option<Arc<std::sync::atomic::AtomicBool>>,
    shared_handler_registration: Mutex<
        Option<(
            crate::registered_local::RegisteredAdapterBinding,
            crate::registered_local::GeneratedLocalAdapterConfig,
        )>,
    >,
    inbound: Option<(
        crate::live_participant::Reservation,
        crate::durable_participant::LiveExecution<P>,
    )>,
}
impl<P: ParticipantSidecar, C: CoordinatorSidecar, R: ParticipantResolver>
    RootHandlerGuard<P, C, R>
{
    /// Trusted generated receiver seam for a registered taskless writer
    /// constructor. The one-use ticket is consumed before any storage IO;
    /// registration alone and wire metadata never grant this authority.
    /// Generator integration must select this seam only for declared constructors
    /// and still consume the configured authorization entry before user effects.
    #[doc(hidden)]
    #[allow(clippy::too_many_arguments)]
    pub async fn registered_constructor_child<Req: prost::Message>(
        participant: &crate::durable_participant::DurableActorParticipant<P>,
        ticket: &crate::runtime::RegisteredLocalTicket,
        binding: &crate::registered_local::RegisteredAdapterBinding,
        configuration: &crate::registered_local::GeneratedLocalAdapterConfig,
        method: &str,
        headers: &crate::RebootHeaders,
        request: &Req,
        coordinator: DurableRootCoordinator<C, R>,
        owner: &crate::live_participant::LiveParticipantOwner,
    ) -> Result<(Self, TransactionContext, crate::auth::AuthorizedHandlerEntry), Status> {
        let mut context = ticket.consume(binding, configuration, method, headers, request)?;
        context.enforce_live_leaf()?;
        binding.require_host_ready(configuration)?;
        if configuration.target != participant.actor_target()
            || participant.database_endpoint() != Some(configuration.database_endpoint.as_str())
            || !configuration.methods.contains(method)
        {
            return Err(Status::failed_precondition("constructor child registration differs from participant"));
        }
        configuration.policy.require_authorizer()?;
        let (authorization_context, auth) = configuration.policy.verify(
            context.headers().clone(), configuration.target.state_type.clone(), method,
        ).await?;
        binding.require_host_ready(configuration)?;
        // Reserve real running root outcome supervision BEFORE gate/Load awaits.
        let reservation = owner.reserve(&context)?;
        let mut local = participant.start_constructor_child(&context).await?;
        let entry = configuration.policy.authorize_handler_entry(
            &local.authorized_handler_admission(), &context, &authorization_context,
            auth.as_ref(), local.state(), &request.encode_to_vec(),
        ).await?;
        // Policy precedes existence disclosure and user-state decoding. A stored
        // empty protobuf is existing state, never absent construction authority.
        if local.state().is_some() {
            return Err(Status::already_exists("constructor child actor already exists"));
        }
        binding.require_host_ready(configuration)?;
        reservation.validate_active()?;
        let execution = local.reserve_live_execution(&context).await?;
        let guard = Self {
            local: Some(local),
            constructor_child: Some((binding.clone(), configuration.clone())),
            admission_context: context.clone(),
            pre_handler_cleanup: std::sync::atomic::AtomicBool::new(true),
            context: context.clone(),
            coordinator,
            reservation: None,
            registration: None,
            inbound: Some((reservation, execution)),
            task_dispatcher: std::sync::Mutex::new(None),
            builtin_map_active: None,
            shared_handler_registration: Mutex::new(None),
        };
        // Any rejection now drops the actual Watch obligation; no disarmed local
        // capability can escape between the await and its supervising aggregate.
        guard.inbound.as_ref().unwrap().0.validate_active()?;
        binding.require_host_ready(configuration)?;
        Ok((guard, context, entry))
    }

    #[doc(hidden)]
    pub async fn before_handler(
        mut local: StartedLocalTransaction<P>,
        context: TransactionContext,
        coordinator: DurableRootCoordinator<C, R>,
        owner: Option<&ExplicitAbortOwner>,
    ) -> Result<Self, Status> {
        let reservation = if local.cancellation_eligible(&context)
            && let Some(owner) = owner
        {
            // Rejection here is pre-effect and leaves ordinary local Drop armed.
            let permit = owner.reserve_admission(
                None,
                "handler cancellation owner is not active",
                "handler cancellation owner is full",
            )?;
            coordinator.validate_explicit_abort(&local, &context)?;
            local.reserve_handler_cancellation(&context).await?;
            // Incarnation validation awaited the participant mutex. Host authority
            // must still be live before granting permission for handler effects.
            let state = owner.state.lock().unwrap();
            if !state.active || owner.failure.borrow().is_some() {
                drop(state);
                local.handoff_to_durable_recovery();
                return Err(Status::unavailable(
                    "handler cancellation owner stopped during admission; ownership retained",
                ));
            }
            Some((owner.clone(), permit))
        } else {
            None
        };
        Ok(Self {
            local: Some(local),
            constructor_child: None,
            admission_context: context.clone(),
            pre_handler_cleanup: std::sync::atomic::AtomicBool::new(true),
            context,
            coordinator,
            reservation,
            registration: None,
            inbound: None,
            task_dispatcher: std::sync::Mutex::new(None),
            builtin_map_active: None,
            shared_handler_registration: Mutex::new(None),
        })
    }
    /// Consume a previously executed policy decision against this actual admitted
    /// actor snapshot, then invoke the generated handler. This does not mint
    /// same-host authority or bypass any configured authorization policy.
    #[doc(hidden)]
    pub async fn run_authorized_handler<F, T>(
        &self,
        policy: &crate::auth::AuthorizationPolicy,
        entry: Option<crate::auth::AuthorizedHandlerEntry>,
        context: &TransactionContext,
        method: &str,
        request: &[u8],
        handler: impl FnOnce(TransactionContext) -> F,
    ) -> Result<T, Status>
    where
        F: std::future::Future<Output = T>,
    {
        self.run_registered_authorized_handler(
            policy,
            entry,
            context,
            (method, request),
            None,
            handler,
        )
        .await
    }

    /// Actual policy-validated handler boundary for optional registered outbound
    /// permission. Trusted composition supplies the same configured binding.
    #[doc(hidden)]
    pub async fn run_registered_authorized_handler<F, T>(
        &self,
        policy: &crate::auth::AuthorizationPolicy,
        entry: Option<crate::auth::AuthorizedHandlerEntry>,
        context: &TransactionContext,
        call: (&str, &[u8]),
        registration: Option<(
            crate::registered_local::RegisteredAdapterBinding,
            crate::registered_local::GeneratedLocalAdapterConfig,
        )>,
        handler: impl FnOnce(TransactionContext) -> F,
    ) -> Result<T, Status>
    where
        F: std::future::Future<Output = T>,
    {
        let (method, request) = call;
        if let Some((admitted_binding, admitted_configuration)) = &self.constructor_child {
            let (binding, configuration) = registration.as_ref().ok_or_else(|| {
                Status::failed_precondition("constructor handler requires its sealed registered configuration")
            })?;
            if entry.is_none()
                || !admitted_binding.same_registration(binding)
                || !admitted_configuration.same_identity_for_ticket(configuration)
            {
                return Err(Status::failed_precondition("constructor handler registration or policy entry differs"));
            }
        }
        if self.context.shared_existing_writer_root() && (entry.is_none() || registration.is_none())
        {
            return Err(Status::failed_precondition(
                "shared writer root requires registered authorized handler configuration",
            ));
        }
        if entry.is_some() || registration.is_some() {
            let validation = async {
                let entry = entry.ok_or_else(|| {
                    Status::failed_precondition(
                        "registered outbound requires a validated policy entry",
                    )
                })?;
                if !context.same_ownership_context(&self.context) {
                    return Err(Status::failed_precondition(
                        "authorized entry context differs from guard",
                    ));
                }
                let local = self
                    .local
                    .as_ref()
                    .ok_or_else(|| Status::failed_precondition("handler guard already consumed"))?;
                entry.validate(
                    policy,
                    &local.authorized_handler_admission(),
                    &self.admission_context,
                    local.actor_state_type(),
                    local.actor_state_ref(),
                    method,
                    local.state_bytes().as_deref(),
                    request,
                )?;
                self.validate_authorized_handler_owner()?;
                local.validate_authorized_handler_execution(context).await?;
                // Participant validation awaited a mutex; recheck host authority.
                self.validate_authorized_handler_owner()?;
                if let Some((binding, configuration)) = &registration {
                    binding.require_host_ready(configuration)?;
                    if configuration.target.state_type != local.actor_state_type()
                        || configuration.target.state_ref != local.actor_state_ref()
                        || !configuration.policy.same_entry_identity(policy)
                        || !configuration.methods.contains(method)
                    {
                        return Err(Status::failed_precondition(
                            "registered handler configuration differs from actual admission",
                        ));
                    }
                }
                if let Some(status) = context.doomed_status() {
                    return Err(status);
                }
                Ok(())
            }
            .await;
            if let Err(error) = validation {
                // No handler future has been constructed: only this admitted
                // reusable call can be discarded. Relinquishment compares its
                // exact local owner/path and restores the saved sibling effects;
                // Drop still transfers the reserved execution to Watch.
                if self.inbound.is_some() && context.reusable_participants() {
                    self.local
                        .as_ref()
                        .ok_or_else(|| {
                            Status::failed_precondition("handler guard already consumed")
                        })?
                        .relinquish_call(context, true)
                        .await?;
                    self.pre_handler_cleanup
                        .store(false, std::sync::atomic::Ordering::Release);
                }
                return Err(error);
            }
        }
        let (mut handler_context, _lifetime) = context.with_handler_lifetime()?;
        if let Some((binding, configuration)) = registration {
            // No gate rereads, user code or suspension while this reservation lives.
            let reservation = binding.reserve_host_ready(&configuration)?;
            handler_context.install_registered_outbound(
                crate::registered_local::RegisteredOutboundPermission {
                    identity: Arc::new(()),
                    binding: binding.clone(),
                    configuration: configuration.clone(),
                },
            )?;
            if self.context.shared_existing_writer_root() {
                *self.shared_handler_registration.lock().unwrap() =
                    Some((binding.clone(), configuration.clone()));
            }
            drop(reservation);
        }
        // No suspension between disarming pre-effect rollback and invoking the
        // handler closure. Handler cancellation keeps the historical semantics.
        self.pre_handler_cleanup
            .store(false, std::sync::atomic::Ordering::Release);
        Ok(handler(handler_context).await)
    }

    /// Generated constructorless-schema seam; registration names and mode flags
    /// are not authority. Reuse the admitted execution and sealed host binding.
    #[doc(hidden)]
    pub async fn authorize_default_root(
        &self,
        context: &TransactionContext,
        binding: Option<&crate::registered_local::RegisteredAdapterBinding>,
        configuration: &crate::registered_local::GeneratedLocalAdapterConfig,
    ) -> Result<(), Status> {
        if !context.is_fresh_root()
            || context.mode() != crate::runtime::TransactionMode::Exclusive
            || context.headers().idempotency_key.is_some()
            || !context.same_ownership_context(&self.context)
        {
            return Err(Status::failed_precondition("default state requires fresh exclusive registered root"));
        }
        self.validate_authorized_handler_owner()?;
        let local = self.local.as_ref().ok_or_else(|| Status::failed_precondition("default root guard consumed"))?;
        local.validate_authorized_handler_execution(context).await?;
        self.validate_authorized_handler_owner()?;
        let binding = binding.ok_or_else(|| Status::failed_precondition("default root requires bound adapter registration"))?;
        binding.require_host_ready(configuration)?;
        if configuration.target.state_type != local.actor_state_type()
            || configuration.target.state_ref != local.actor_state_ref()
            || local.database_endpoint() != Some(configuration.database_endpoint.as_str())
        {
            return Err(Status::failed_precondition("default root binding differs from admitted actor"));
        }
        Ok(())
    }

    fn validate_authorized_handler_owner(&self) -> Result<(), Status> {
        if let Some((binding, configuration)) = &self.constructor_child {
            binding.require_host_ready(configuration)?;
        }
        if self.context.is_fresh_root() {
            let token = self.registration.as_ref().ok_or_else(|| {
                Status::failed_precondition("authorized handler requires registered root")
            })?;
            if self.reservation.is_none() {
                return Err(Status::failed_precondition(
                    "authorized handler cancellation reservation missing",
                ));
            }
            let state = token.owner.state.lock().unwrap();
            if !state.active
                || token.owner.failure.borrow().is_some()
                || !state
                    .registered_roots
                    .contains(&self.context.transaction_root_id())
            {
                return Err(Status::unavailable("authorized handler root owner stopped"));
            }
            drop(state);
            let (owner, _) = self.reservation.as_ref().unwrap();
            if !owner.state.lock().unwrap().active || owner.failure.borrow().is_some() {
                return Err(Status::unavailable(
                    "authorized handler cancellation owner stopped",
                ));
            }
        } else {
            self.inbound
                .as_ref()
                .ok_or_else(|| {
                    Status::failed_precondition("authorized handler requires reserved Watch")
                })?
                .0
                .validate_active()?;
        }
        Ok(())
    }

    /// Generated legacy factories retain ownership once handler effects may begin.
    /// This is the historical handler-lifetime boundary, not an acknowledged Prepare.
    /// Keep pre-handler policy/receipt admission Drop armed until this synchronous call.
    #[doc(hidden)]
    pub fn with_legacy_factory_handler_retention(mut self) -> Result<Self, Status> {
        if self.reservation.is_some() || self.registration.is_some() || self.inbound.is_some() {
            return Err(Status::failed_precondition(
                "legacy factory retention cannot replace owned cancellation or inbound authority",
            ));
        }
        self.local.as_mut().unwrap().disarm_after_durable_prepare();
        Ok(self)
    }
    /// Installs host-only builtin authority after real root/cancellation admission.
    /// No inbound or public metadata can enable this capability.
    #[doc(hidden)]
    pub fn with_builtin_map_context(
        mut self,
        context: &mut TransactionContext,
    ) -> Result<Self, Status> {
        if context.is_fresh_root()
            && !context.shared_existing_writer_member()
            && !context.supervised_tree_execution()
            && let Some(token) = self.registration.as_ref()
            && self.reservation.is_some()
        {
            if !context.same_ownership_context(&self.context) {
                return Err(Status::failed_precondition(
                    "builtin context differs from admitted guard",
                ));
            }
            let state = token.owner.state.lock().unwrap();
            if !state.active
                || token.owner.failure.borrow().is_some()
                || !state
                    .registered_roots
                    .contains(&context.transaction_root_id())
            {
                return Err(Status::failed_precondition(
                    "builtin requires active root owner",
                ));
            }
            if let Some(endpoint) = self.local.as_ref().unwrap().database_endpoint() {
                let active = Arc::new(std::sync::atomic::AtomicBool::new(true));
                context.install_builtin_map_admission(
                    endpoint,
                    active.clone(),
                    token.owner.clone(),
                );
                self.builtin_map_active = Some(active);
                self.context = context.clone();
            }
        }
        Ok(self)
    }

    #[doc(hidden)]
    pub async fn with_live_inbound(
        mut self,
        context: &mut TransactionContext,
        owner: Option<&crate::live_participant::LiveParticipantOwner>,
    ) -> Result<Self, Status> {
        if !context.is_fresh_root()
            && let Some(owner) = owner
        {
            if !context.same_ownership_context(&self.context) {
                return Err(Status::failed_precondition(
                    "live execution context differs from guard",
                ));
            }
            context.enforce_live_leaf()?;
            self.context = context.clone();
            let reservation = owner.reserve(context)?;
            let execution = self
                .local
                .as_mut()
                .unwrap()
                .reserve_live_execution(context)
                .await?;
            self.inbound = Some((reservation, execution));
            self.inbound.as_ref().unwrap().0.validate_active()?;
        }
        Ok(self)
    }
    /// Explicit tree opt-in is not ownership: reserve and install actual execution first.
    #[doc(hidden)]
    pub async fn with_supervised_tree(
        mut self,
        context: &mut TransactionContext,
        owner: Option<&crate::live_participant::LiveParticipantOwner>,
    ) -> Result<Self, Status> {
        if !context.same_ownership_context(&self.context) {
            return Err(Status::failed_precondition(
                "tree context differs from guard",
            ));
        }
        context.validate_tree_scope()?;
        if context.is_fresh_root() {
            if self.registration.is_none() || self.reservation.is_none() {
                return Err(Status::failed_precondition(
                    "tree requires active registered root execution",
                ));
            }
            let token = self.registration.as_ref().unwrap();
            let state = token.owner.state.lock().unwrap();
            if !state.active
                || token.owner.failure.borrow().is_some()
                || !state
                    .registered_roots
                    .contains(&context.transaction_root_id())
            {
                return Err(Status::unavailable("registered tree root owner stopped"));
            }
        } else {
            let owner = owner.ok_or_else(|| {
                Status::failed_precondition("tree requires live participant owner")
            })?;
            let reservation = owner.reserve(context)?;
            let execution = self
                .local
                .as_mut()
                .unwrap()
                .reserve_live_execution(context)
                .await?;
            self.inbound = Some((reservation, execution));
            self.inbound.as_ref().unwrap().0.validate_active()?;
        }
        context.enable_supervised_tree()?;
        let local = self.local.as_ref().unwrap();
        context.install_actor_authority(
            crate::durable_coordinator::ParticipantTarget {
                state_type: local.actor_state_type().to_owned(),
                state_ref: local.actor_state_ref().to_owned(),
            },
            false,
        )?;
        if self.inbound.is_some() {
            context.mark_supervised_inbound();
        }
        self.context = context.clone();
        Ok(self)
    }

    /// Host-selected root-star: installed only after registered root or live
    /// participant admission. Every inbound execution is a direct-root leaf.
    #[doc(hidden)]
    pub async fn with_sequential_root_star(
        self,
        context: &mut TransactionContext,
        owner: Option<&crate::live_participant::LiveParticipantOwner>,
    ) -> Result<Self, Status> {
        let mut guard = self.with_supervised_tree(context, owner).await?;
        let local = guard.local.as_ref().unwrap();
        // A fresh root already owns registered execution and the exclusive
        // participant lease. Generated schema admission decides whether its
        // absent snapshot may default before entering the handler. Inbound
        // existing-writer leaves never acquire construction authority here.
        if local.state().is_none() && !context.is_fresh_root() {
            return Err(Status::failed_precondition(
                "root-star requires existing actor",
            ));
        }
        context.install_actor_authority(
            crate::durable_coordinator::ParticipantTarget {
                state_type: local.actor_state_type().to_owned(),
                state_ref: local.actor_state_ref().to_owned(),
            },
            true,
        )?;
        guard.context = context.clone();
        Ok(guard)
    }

    /// Opt-in existing-actor sequential siblings. Admission still requires an
    /// actual registered root/live participant owner, never just this flag.
    #[doc(hidden)]
    pub async fn with_sequential_reusable_participants(
        self,
        context: &mut TransactionContext,
        owner: Option<&crate::live_participant::LiveParticipantOwner>,
    ) -> Result<Self, Status> {
        let mut guard = self.with_sequential_root_star(context, owner).await?;
        context.install_reusable_policy()?;
        guard.context = context.clone();
        Ok(guard)
    }

    /// Consumes the actual admitted read-only root; no metadata opt-in.
    #[doc(hidden)]
    pub async fn with_shared_existing_writers(
        mut self,
        context: &mut TransactionContext,
    ) -> Result<Self, Status> {
        if !context.same_ownership_context(&self.admission_context)
            || !self.context.shared_existing_writer_root()
            || self.inbound.is_some()
            || self.registration.is_none()
            || self.reservation.is_none()
        {
            return Err(Status::failed_precondition(
                "shared writer policy requires the exact registered root guard",
            ));
        }
        self.validate_authorized_handler_owner()?;
        let local = self.local.as_ref().unwrap();
        self.coordinator
            .validate_shared_writer_local(local, &self.context)?;
        if local.state().is_none() {
            return Err(Status::failed_precondition(
                "shared writer root requires an existing actor",
            ));
        }
        *context = self.context.clone();
        context.install_shared_writer_execution(crate::durable_coordinator::ParticipantTarget {
            state_type: local.actor_state_type().to_owned(),
            state_ref: local.actor_state_ref().to_owned(),
        })?;
        self.context = context.clone();
        Ok(self)
    }

    fn validate_shared_handler_registration(&self) -> Result<(), Status> {
        let registration = self.shared_handler_registration.lock().unwrap();
        let (binding, config) = registration.as_ref().ok_or_else(|| {
            Status::failed_precondition(
                "shared completion requires actual registered authorized handler execution",
            )
        })?;
        binding.require_host_ready(config)
    }

    /// The only shared-with-writers completion path. No caller membership list.
    pub async fn complete_shared_existing_writers(
        mut self,
        start: crate::durable_coordinator::RootCoordinatorStart,
    ) -> Result<(), Status> {
        if let Some(status) = self.context.doomed_status() {
            return Err(status);
        }
        self.validate_shared_handler_registration()?;
        self.validate_authorized_handler_owner()?;
        let local = self
            .local
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("root guard consumed"))?;
        self.coordinator
            .validate_shared_writer_start(&start, local, &self.context)?;
        // Empty effects classify unchanged Bank read-only, never promote it.
        local
            .stage(crate::durable_participant::PendingActorEffects::default())
            .await?;
        local
            .validate_authorized_handler_execution(&self.context)
            .await?;
        self.validate_authorized_handler_owner()?;
        let receipt = crate::shared_existing_writer_root::SettledSharedWriterRoot::from_guard(
            start,
            self.context.clone(),
        )?;
        local.end_execution().await?;
        self.validate_authorized_handler_owner()?;
        self.validate_shared_handler_registration()?;
        // No await between revocation and durable-unknown, BEFORE construction
        // of any coordinator future which may start durable I/O.
        self.handoff_to_durable_recovery();
        let committed = self
            .coordinator
            .complete_shared_writer_outcome(receipt, self.local.as_ref().unwrap())
            .await?;
        self.completed()?;
        if committed {
            Ok(())
        } else {
            Err(Status::aborted("participant rejected Prepare"))
        }
    }

    /// Seal descendants and encode the local plus transitive participant union.
    #[doc(hidden)]
    pub fn inbound_participant_metadata(
        &self,
        local: crate::durable_coordinator::ParticipantTarget,
        read_only: bool,
    ) -> Result<crate::successful_trailers::ParticipantMetadata, Status> {
        if self.constructor_child.is_some()
            && (read_only || self.local.as_ref().is_none_or(|local_transaction| {
                local_transaction.state().is_some()
                    || local_transaction.actor_state_type() != local.state_type
                    || local_transaction.actor_state_ref() != local.state_ref
            }))
        {
            return Err(Status::failed_precondition("constructor child membership must be exact and writable"));
        }
        let mut returned = if self.context.tree_owned() {
            self.context.seal_explicit_abort()?
        } else {
            Vec::new()
        };
        returned.push(crate::durable_coordinator::ReturnedParticipant {
            target: local,
            read_only,
        });
        crate::successful_trailers::ParticipantMetadata::classified_aggregate(
            &returned,
            self.context.headers().coordinator_read_only_aware,
        )
        .map_err(|error| Status::failed_precondition(error.to_string()))
    }

    /// Consuming rollback keeps the exact reserved Watch obligation through return.
    #[doc(hidden)]
    pub async fn rollback_declared_leaf(self, mut status: Status) -> Result<Status, Status> {
        self.context.validate_rollback_leaf_branch()?;
        let (reservation, _) = self.inbound.as_ref().ok_or_else(|| {
            Status::failed_precondition("rollback requires active reserved Watch")
        })?;
        reservation.validate_active()?;
        let metadata = crate::successful_trailers::ParticipantMetadata::classified_single(
            &self.coordinator_state_type_for_leaf(),
            &self.context.headers().state_ref,
            true,
            true,
        )
        .map_err(|error| Status::failed_precondition(error.to_string()))?;
        if self.context.reusable_participants() {
            self.local
                .as_ref()
                .unwrap()
                .relinquish_call(&self.context, true)
                .await?;
        } else {
            self.local
                .as_ref()
                .unwrap()
                .rollback_declared_leaf(&self.context)
                .await?;
        }
        reservation.validate_active()?;
        metadata.attach_to_status(&mut status);
        #[cfg(feature = "test-support")]
        if let Ok(vector) = std::env::var("REBOOT_TEST_ROLLBACK_ERROR_VECTOR") {
            use crate::successful_trailers::{
                TRANSACTION_PARTICIPANTS_HEADER as WRITERS,
                TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER as READERS,
            };
            match vector.as_str() {
                "missing" => {
                    status.metadata_mut().remove(READERS);
                }
                "malformed" => {
                    status
                        .metadata_mut()
                        .insert(READERS, "not-json".parse().unwrap());
                }
                "writer" => {
                    let value = status.metadata_mut().remove(READERS).unwrap();
                    status.metadata_mut().insert(WRITERS, value);
                }
                "foreign" => {
                    status.metadata_mut().insert(
                        READERS,
                        "{\"foreign.Actor\":[\"foreign\"]}".parse().unwrap(),
                    );
                }
                "wrong-type" => {
                    status.metadata_mut().insert(
                        READERS,
                        format!(
                            "{{\"foreign.Actor\":[\"{}\"]}}",
                            self.context.headers().state_ref
                        )
                        .parse()
                        .unwrap(),
                    );
                }
                "malformed-rich" => {
                    status = Status::with_details(
                        tonic::Code::Unknown,
                        "malformed rich",
                        vec![0xff].into(),
                    )
                }
                "unknown" => {
                    status = crate::declared_error_status(
                        tonic::Code::Unknown,
                        "unknown declared",
                        "type.googleapis.com/foreign.Unknown",
                        &crate::database_proto::NotFound {},
                    )
                }
                "wrong-ref" => {
                    status.metadata_mut().insert(
                        READERS,
                        "{\"tests.reboot.protoc.TransactionCounter\":[\"wrong-ref\"]}"
                            .parse()
                            .unwrap(),
                    );
                }
                "extra" => {
                    status.metadata_mut().insert(
                        READERS,
                        "{\"tests.reboot.protoc.TransactionCounter\":[\"target\",\"extra\"]}"
                            .parse()
                            .unwrap(),
                    );
                }
                "overlap" => {
                    let value = status.metadata().get(READERS).unwrap().clone();
                    status.metadata_mut().insert(WRITERS, value);
                }
                "multiple" | "conflict" => {
                    use prost::Message;
                    let mut rich = crate::declared_error_details(&status).unwrap().unwrap();
                    if vector == "multiple" {
                        rich.details.push(rich.details[0].clone());
                    } else {
                        rich.code = tonic::Code::InvalidArgument as i32;
                    }
                    status = Status::with_details(
                        tonic::Code::Unknown,
                        rich.message.clone(),
                        rich.encode_to_vec().into(),
                    );
                }
                "system" => {
                    status = crate::SystemAborted::NotFound(crate::database_proto::NotFound {})
                        .into_status("system after rollback")
                }
                "transport" => status = Status::unavailable("transport after rollback"),
                _ => return Err(Status::invalid_argument("unknown rollback test vector")),
            }
        }
        self.finish_inbound()?;
        Ok(status)
    }

    fn coordinator_state_type_for_leaf(&self) -> String {
        self.local.as_ref().unwrap().actor_state_type().to_owned()
    }

    pub fn cancellation_owned(&self) -> bool {
        self.reservation.is_some()
    }
    /// Task eligibility comes from the exact admitted live execution and its
    /// reserved Watch obligation, never from a builder or caller-supplied flag.
    /// Descendant attempts doom the context and cannot regain this authority.
    #[doc(hidden)]
    pub fn live_leaf_tasks_owned(&self) -> Result<bool, Status> {
        let Some((reservation, _execution)) = &self.inbound else {
            return Ok(false);
        };
        reservation.validate_active()?;
        if self.context.tree_owned() {
            return Ok(false);
        }
        if let Some(error) = self.context.doomed_status() {
            return Err(error);
        }
        Ok(true)
    }
    /// Tree task authority is the exact registered root or reserved inbound
    /// execution, composed with the actual dispatcher store and actor gate.
    #[doc(hidden)]
    pub async fn validate_tree_tasks(
        &self,
        tasks: &crate::one_shot_tasks::OneShotTasks,
    ) -> Result<(), Status> {
        if self.context.shared_existing_writer_member() {
            return Err(Status::failed_precondition(
                "shared existing writer execution excludes tasks",
            ));
        }
        if !self.context.tree_owned() {
            return Err(Status::failed_precondition("tree task authority missing"));
        }
        self.context.validate_open_task_branch()?;
        if self.context.is_fresh_root() {
            let token = self
                .registration
                .as_ref()
                .ok_or_else(|| Status::failed_precondition("tree tasks require registered root"))?;
            if self.reservation.is_none() {
                return Err(Status::failed_precondition("tree task reservation missing"));
            }
            let state = token.owner.state.lock().unwrap();
            if !state.active
                || token.owner.failure.borrow().is_some()
                || !state
                    .registered_roots
                    .contains(&self.context.transaction_root_id())
            {
                return Err(Status::unavailable("tree task root owner stopped"));
            }
        } else {
            let (reservation, _) = self
                .inbound
                .as_ref()
                .ok_or_else(|| Status::failed_precondition("tree tasks require reserved Watch"))?;
            reservation.validate_active()?;
        }
        tasks
            .validate_guard_execution(
                self.local
                    .as_ref()
                    .ok_or_else(|| Status::failed_precondition("tree execution closed"))?,
                &self.context,
            )
            .await?;
        // Recheck host authority after the incarnation mutex await.
        if let Some((reservation, _)) = &self.inbound {
            reservation.validate_active()?;
        }
        if let Some(token) = &self.registration {
            let state = token.owner.state.lock().unwrap();
            if !state.active
                || token.owner.failure.borrow().is_some()
                || !state
                    .registered_roots
                    .contains(&self.context.transaction_root_id())
            {
                return Err(Status::unavailable("tree task root owner stopped"));
            }
        }
        self.context.validate_open_task_branch()
    }

    /// Successful completion must also prove quiescence and known membership.
    /// The caller immediately performs synchronous durable handoff afterwards.
    pub(crate) fn seal_for_handoff(
        &self,
    ) -> Result<Option<Vec<crate::durable_coordinator::ReturnedParticipant>>, Status> {
        if self.reservation.is_some() {
            let returned = self.context.seal_explicit_abort()?;
            if returned.len() > 1024 {
                return Err(Status::resource_exhausted(
                    "handler participant limit exceeded",
                ));
            }
            Ok(Some(returned))
        } else {
            Ok(None)
        }
    }

    /// Atomic pre-durable handoff: no await between revoking cancellation
    /// authority and handing off the local transaction. Never Abort a durable root.
    fn handoff_to_durable_recovery(&mut self) {
        self.local.as_mut().unwrap().handoff_to_durable_recovery();
    }
    /// Only an acknowledged successful completion releases durable uncertainty.
    fn completed(&mut self) -> Result<(), Status> {
        if !self
            .local
            .as_ref()
            .is_some_and(|local| local.was_handed_off())
        {
            let error = Status::failed_precondition("completion requires durable handoff");
            if let Some((owner, _)) = &self.reservation {
                owner.failure.send_replace(Some(error.clone()));
            }
            return Err(error);
        }
        self.reservation.take();
        if let Some(token) = &mut self.registration {
            token.finished = true;
        }
        Ok(())
    }
    /// Consuming completion owns the only public handoff path. Membership is
    /// sealed here, and the reservation is released only after actual coordinator
    /// success. Dropping this future after handoff reports fatal uncertainty.
    pub async fn complete_root(
        mut self,
        start: crate::durable_coordinator::RootCoordinatorStart,
        mut returned: Vec<crate::durable_coordinator::ReturnedParticipant>,
    ) -> Result<(), Status> {
        if let Some(status) = self.context.doomed_status() {
            return Err(status);
        }
        if self.inbound.is_some() || self.context.transaction_ids().len() != 1 {
            return Err(Status::failed_precondition(
                "inbound branch cannot drive root completion",
            ));
        }
        if start.transaction_ids != self.context.transaction_ids()
            || start.coordinator_state_type != self.context.transaction_coordinator_state_type()
            || start.coordinator_state_ref != self.context.transaction_coordinator_state_ref()
            || start.participant.state_type != self.context.transaction_coordinator_state_type()
            || start.participant.state_ref != self.context.headers().state_ref
            || start.mode != self.context.mode()
            || (self.reservation.is_some()
                && (start.mode != crate::runtime::TransactionMode::Exclusive
                    || start.read_only
                    || start.factory
                    || start.placement_requested))
        {
            return Err(Status::failed_precondition(
                "root completion does not match admitted cancellation authority",
            ));
        }
        if let Some(sealed) = self.seal_for_handoff()? {
            returned = sealed;
        }
        if self.registration.is_some() {
            self.local.as_ref().unwrap().end_execution().await?;
        }
        self.handoff_to_durable_recovery();
        self.context.take_returned_participants();
        let committed = self
            .coordinator
            .complete_classified_outcome(start, returned)
            .await?;
        self.completed()?;
        if committed {
            Ok(())
        } else {
            Err(Status::aborted("participant rejected Prepare"))
        }
    }

    #[doc(hidden)]
    pub async fn before_inbound_response(&self) -> Result<(), Status> {
        #[cfg(feature = "test-support")]
        if self.inbound.is_some()
            && let Some(path) = std::env::var_os("REBOOT_TEST_LIVE_INBOUND_RESPONSE")
        {
            self.local
                .as_ref()
                .unwrap()
                .assert_staged_for_test()
                .await?;
            struct Dropped(std::path::PathBuf);
            impl Drop for Dropped {
                fn drop(&mut self) {
                    std::fs::write(
                        self.0.with_extension("future-dropped"),
                        b"actual staged response future dropped",
                    )
                    .unwrap();
                }
            }
            let path = std::path::PathBuf::from(path);
            std::fs::write(&path, b"actual remote staging completed; trailers not sent").unwrap();
            let _drop = Dropped(path);
            if std::env::var_os("REBOOT_TEST_LIVE_INBOUND_RESPONSE_ERROR").is_some() {
                return Err(Status::unavailable(
                    "lost successful trailers after real staging",
                ));
            }
            std::future::pending::<()>().await;
        }
        Ok(())
    }

    #[doc(hidden)]
    pub async fn stage_effects(
        &self,
        effects: crate::durable_participant::PendingActorEffects,
    ) -> Result<Option<crate::durable_participant::SharedPromotion>, Status> {
        if self.constructor_child.is_some() {
            self.validate_authorized_handler_owner()?;
        }
        let local = self
            .local
            .as_ref()
            .ok_or_else(|| Status::failed_precondition("execution closed"))?;
        if self.context.shared_existing_writer_member()
            && (!effects.task_upserts.is_empty() || !effects.idempotent_mutations.is_empty())
        {
            let error = Status::failed_precondition(
                "shared existing writers exclude tasks and idempotency",
            );
            self.context.doom(error.clone());
            return Err(error);
        }
        if self.context.shared_existing_writer_root() {
            if effects
                .state
                .as_deref()
                .is_some_and(|state| Some(state) != local.state())
                || !effects.task_upserts.is_empty()
                || !effects.idempotent_mutations.is_empty()
            {
                let error = Status::failed_precondition(
                    "shared writer root must remain unchanged without tasks or idempotency",
                );
                self.context.doom(error.clone());
                return Err(error);
            }
            // Do not pass an unchanged explicit state as a writer effect.
            return local
                .stage(crate::durable_participant::PendingActorEffects::default())
                .await;
        }
        if self.context.reusable_participants() {
            // Fresh registered roots have no inbound Watch. Retained leaves
            // must still prove their reserved live execution on every stage.
            if let Some((inbound, _)) = &self.inbound {
                inbound.validate_active()?;
            } else if !self.context.is_fresh_root()
                || self.registration.is_none()
                || self.reservation.is_none()
            {
                return Err(Status::failed_precondition(
                    "reusable execution requires live guard",
                ));
            }
            self.context.validate_open_shared_writer_branch()?;
            if !effects.task_upserts.is_empty() {
                let tasks = self
                    .task_dispatcher
                    .lock()
                    .unwrap()
                    .clone()
                    .ok_or_else(|| {
                        Status::failed_precondition(
                            "reusable tasks require guarded dispatcher binding",
                        )
                    })?;
                self.validate_tree_tasks(&tasks).await?;
                let result = local
                    .stage_validated_tasks(effects, &tasks, &self.context)
                    .await;
                if let Some((inbound, _)) = &self.inbound {
                    inbound.validate_active()?;
                }
                self.validate_tree_tasks(&tasks).await?;
                return result;
            }
        }
        let result = local.stage(effects).await;
        if self.constructor_child.is_some() {
            self.validate_authorized_handler_owner()?;
        }
        result
    }

    /// Complete exactly this admitted call before successful trailers authorize
    /// the next sibling. Drop retains the stable root Watch reservation.
    #[doc(hidden)]
    pub async fn finish_generated_inbound(self) -> Result<(), Status> {
        if self.context.reusable_participants() {
            self.inbound
                .as_ref()
                .ok_or_else(|| Status::failed_precondition("reusable Watch missing"))?
                .0
                .validate_active()?;
            self.local
                .as_ref()
                .unwrap()
                .relinquish_call(&self.context, false)
                .await?;
        }
        self.finish_inbound()
    }

    #[doc(hidden)]
    pub async fn validate_staged_tasks(
        &self,
        tasks: &crate::one_shot_tasks::OneShotTasks,
        staged: &[crate::database_proto::Task],
    ) -> Result<(), Status> {
        let all = if self.context.reusable_participants() {
            self.local.as_ref().unwrap().retained_tasks(staged).await?
        } else {
            staged.to_vec()
        };
        if self.context.reusable_participants() {
            self.validate_tree_tasks(tasks).await?;
        }
        #[cfg(feature = "test-support")]
        if self.context.reusable_participants()
            && let Some(uuid) = std::env::var_os("REBOOT_TEST_GUARD_COMPLETED_UUID")
            && staged.iter().any(|task| {
                task.task_id.as_ref().is_some_and(|id| {
                    uuid::Uuid::from_slice(&id.task_uuid)
                        .is_ok_and(|id| id.to_string() == uuid.to_string_lossy())
                })
            })
        {
            // Bind a genuinely active actor dispatcher on the retained N1 batch,
            // then exercise the exported staging operation with a different batch.
            let retained = self.local.as_ref().unwrap().retained_tasks(&[]).await?;
            tasks.validate_staged(&retained).await?;
            *self.task_dispatcher.lock().unwrap() = Some(tasks.clone());
            let result = self
                .stage_effects(crate::durable_participant::PendingActorEffects {
                    task_upserts: staged.to_vec(),
                    ..Default::default()
                })
                .await;
            if let Some(marker) = std::env::var_os("REBOOT_TEST_GUARD_COMPLETED_MARKER") {
                std::fs::write(
                    marker,
                    match &result {
                        Ok(_) => "ACCEPTED".to_owned(),
                        Err(status) => format!("{:?}", status.code()),
                    },
                )
                .map_err(|error| Status::internal(error.to_string()))?;
            }
            return result
                .map(|_| ())
                .and_then(|_| Err(Status::internal("uncertified Completed task accepted")));
        }
        tasks.validate_staged(&all).await?;
        *self.task_dispatcher.lock().unwrap() = Some(tasks.clone());
        Ok(())
    }

    /// Legacy unsupported/inbound paths cannot discard a supported root's owner.
    pub fn finish_inbound(mut self) -> Result<(), Status> {
        if self.reservation.is_some() {
            return Err(Status::failed_precondition(
                "owned root cannot complete as inbound",
            ));
        }
        self.handoff_to_durable_recovery();
        Ok(())
    }

    pub async fn abort_local(mut self) -> Result<(), Status> {
        if self.inbound.is_some() {
            return Ok(());
        }
        if self.reservation.is_some() {
            return self.abort_explicit().await;
        }
        self.local.as_mut().unwrap().abort_legacy().await
    }

    /// Generated ordinary pre-Allow denial cleanup only. Keep cleanup ownership
    /// and internal errors intact, but never disclose their rich Status to callers.
    #[doc(hidden)]
    pub async fn abort_local_after_denial(self) -> Result<(), Status> {
        self.abort_local().await.map_err(|cause| {
            // Code-only diagnostic: storage messages, details, and metadata may
            // contain private actor data or credentials, even in server logs.
            eprintln!("authorization denial cleanup failed: code={:?}", cause.code());
            Status::unavailable("authorization cleanup unavailable")
        })
    }

    #[cfg(test)]
    pub(crate) fn test_shared_local(&self) -> &StartedLocalTransaction<P> {
        self.local.as_ref().unwrap()
    }
    #[cfg(test)]
    pub(crate) fn test_shared_coordinator(&self) -> &DurableRootCoordinator<C, R> {
        &self.coordinator
    }
    #[cfg(test)]
    pub(crate) fn test_shared_registration(&self) -> Result<(), Status> {
        self.validate_shared_handler_registration()
    }

    #[cfg(test)]
    pub(crate) fn test_handoff(&mut self) {
        self.handoff_to_durable_recovery();
    }
    #[cfg(test)]
    pub(crate) fn test_completed(&mut self) -> Result<(), Status> {
        self.completed()
    }

    #[doc(hidden)]
    pub async fn abort_explicit(mut self) -> Result<(), Status> {
        if self
            .local
            .as_ref()
            .is_some_and(|local| local.was_handed_off())
        {
            // Drop reports durable uncertainty; never enqueue Abort after handoff.
            return Err(Status::failed_precondition(
                "Abort requires pre-handoff ownership",
            ));
        }
        let local = self.local.take().unwrap();
        if let Some((owner, permit)) = self.reservation.take() {
            let observer = owner.submit_reserved(
                local,
                self.context.clone(),
                self.coordinator.clone(),
                permit,
                self.registration.take(),
            )?;
            #[cfg(feature = "test-support")]
            let _observer_drop = ObserverDrop::new();
            observer.await.map_err(|_| {
                Status::unavailable("explicit Abort stopped before ACK; ownership retained")
            })?
        } else {
            let mut local = local;
            self.coordinator
                .abort_explicit_root_before_handoff(&mut local, &self.context)
                .await
        }
    }
}
impl<P: ParticipantSidecar, C: CoordinatorSidecar, R: ParticipantResolver> Drop
    for RootHandlerGuard<P, C, R>
{
    fn drop(&mut self) {
        if let Some(active) = &self.builtin_map_active {
            active.store(false, std::sync::atomic::Ordering::Release);
        }
        if let Some((reservation, execution)) = self.inbound.take() {
            self.context.close_branch();
            let context = self.context.clone();
            let watch = reservation.endpoint();
            // Transfer before any request-owned await can be cancelled. The
            // reserved owner, not a detached request task, finishes pre-effect
            // cleanup against the exact captured admission incarnation.
            let rejected_local = if context.reusable_participants()
                && self
                    .pre_handler_cleanup
                    .load(std::sync::atomic::Ordering::Acquire)
            {
                self.local.take()
            } else {
                None
            };
            reservation.submit(Box::pin(async move {
                context.wait_branch_quiescent().await;
                if let Some(mut local) = rejected_local
                    && let Err(error) = local.relinquish_call(&context, true).await
                {
                    // Do not clear execution_active on failed cleanup. Queued
                    // Prepare/terminal controls remain fenced by this exact
                    // incarnation; an existing retained root Watch stays owned.
                    // Surface failure immediately to the reserved host, which
                    // must restart/recover rather than retry or fabricate Abort.
                    local.handoff_to_durable_recovery();
                    return Err(error);
                }
                execution.watch(watch).await
            }));
        }
        if let Some((owner, permit)) = self.reservation.take() {
            if self
                .local
                .as_ref()
                .is_some_and(|local| local.was_handed_off())
            {
                owner.failure.send_replace(Some(Status::unavailable(
                    "root cancelled or failed after durable handoff; ownership retained",
                )));
                if self.context.shared_existing_writer_root() {
                    owner
                        .state
                        .lock()
                        .unwrap()
                        .retained_shared_permits
                        .push(permit);
                }
                return;
            }
            let local = self.local.take().unwrap();
            let _ = owner.submit_reserved(
                local,
                self.context.clone(),
                self.coordinator.clone(),
                permit,
                self.registration.take(),
            );
            #[cfg(feature = "test-support")]
            drop(ObserverDrop::new());
        }
    }
}
impl ExplicitAbortOwner {
    fn submit_reserved<P: ParticipantSidecar, C: CoordinatorSidecar, R: ParticipantResolver>(
        &self,
        local: StartedLocalTransaction<P>,
        context: TransactionContext,
        coordinator: DurableRootCoordinator<C, R>,
        permit: OwnedSemaphorePermit,
        registration: Option<RootRegistrationToken>,
    ) -> Result<oneshot::Receiver<Result<(), Status>>, Status> {
        // CLOSE synchronously, before queue transfer or any worker await.
        // Unknown/active scopes remain unknown and cannot authorize Commit.
        if local.was_handed_off() {
            let error = Status::unavailable(
                "registered cleanup cannot Abort after durable handoff; ownership retained",
            );
            self.failure.send_replace(Some(error.clone()));
            return Err(error);
        }
        let registered = registration.is_some();
        if registered && let Err(error) = context.close_for_abandonment() {
            // Never silently release a reserved owner when closure fails.
            self.failure.send_replace(Some(error.clone()));
            return Err(error);
        }
        let shared = context.shared_existing_writer_root();
        let (job_permit, shared_permit) = if shared {
            (
                None,
                Some(SharedAbortPermit {
                    owner: self.clone(),
                    permit: Some(permit),
                    completed: false,
                }),
            )
        } else {
            (Some(permit), None)
        };
        // Own the disarmed capability and capacity even before the first poll.
        let work = Box::pin(async move {
            let mut shared_permit = shared_permit;
            let mut registration = registration;
            if registered {
                context.wait_branch_quiescent().await;
                local.end_execution().await?;
            }
            let work = if registered {
                coordinator
                    .own_registered_abandonment(local, context)
                    .await?
            } else {
                coordinator.own_explicit_abort(local, context).await?
            };
            let result = work.await;
            if result.is_ok() {
                if let Some(token) = &mut registration {
                    token.finished = true;
                }
                if let Some(permit) = &mut shared_permit {
                    permit.completed = true;
                }
            }
            result
        });
        let (reply, observer) = oneshot::channel();
        let job = Job::new(self, work, reply, job_permit);
        let state = self.state.lock().unwrap();
        let result = if state.active && self.failure.borrow().is_none() {
            self.sender.try_send(job)
        } else {
            Err(mpsc::error::TrySendError::Closed(job))
        };
        drop(state);
        if let Err(rejected) = result {
            // Captured root tokens also lock state on Drop.
            drop(rejected);
            let error =
                Status::unavailable("handler cancellation host stopped; ownership retained");
            self.failure.send_replace(Some(error.clone()));
            return Err(error);
        }
        Ok(observer)
    }
}

#[tonic::async_trait]
impl HostRecovery for ExplicitAbortRecovery {
    async fn start(
        &self,
        supervisor: &mut JoinSet<Result<(), Status>>,
        cancel: RecoveryCancellation,
    ) -> Result<(), Status> {
        let mut receiver = {
            let mut state = self.owner.state.lock().unwrap();
            let receiver = state.receiver.take().ok_or_else(|| {
                Status::failed_precondition("explicit Abort owner already registered")
            })?;
            state.active = true;
            state.host_cancel = Some(cancel.clone());
            receiver
        };
        let active = Active(
            self.owner.state.clone(),
            self.owner.capacity.clone(),
            self.owner.limit,
        );
        let timeout = self.owner.timeout;
        let mut failure = self.owner.failure.subscribe();
        supervisor.spawn(async move {
            let _active = active;
            loop {
                if let Some(error) = failure.borrow().clone() { return Err(error); }
                let job = tokio::select! { biased; _ = cancel.cancelled() => return Ok(()), changed = failure.changed() => { let _ = changed; return Err(failure.borrow().clone().unwrap_or_else(|| Status::unavailable("explicit Abort owner failed"))); }, job = receiver.recv() => match job { Some(job) => job, None => return Ok(()) } };
                // Keep the owned work OUTSIDE select: select destroys losing
                // branch futures before executing the winning branch body.
                // Latch uncertainty while the running job still owns its token
                // and permit, even for non-shared registered abandonment.
                let mut running = RunningAbort::new(job, timeout);
                let result = tokio::select! { biased;
                    _ = cancel.cancelled() => {
                        cancel.fail();
                        return Ok(());
                    },
                    changed = failure.changed() => {
                        let _ = changed;
                        cancel.fail();
                        return Err(failure.borrow().clone().unwrap_or_else(|| Status::unavailable("explicit Abort owner failed")));
                    },
                    result = &mut running.work => result.unwrap_or_else(|_| Err(Status::deadline_exceeded("explicit Abort timed out; ownership retained"))),
                };
                if result.is_err() {
                    cancel.fail();
                }
                let _ = running.job.reply.take().unwrap().send(result.clone());
                // Known success needs no latch. Known failure was latched above;
                // observer loss is not cancellation of acknowledged owned work.
                running.job.accounted = true;
                result?;
            }
        });
        Ok(())
    }
}

#[cfg(feature = "test-support")]
pub(crate) struct ObserverDrop(Option<std::path::PathBuf>);
#[cfg(feature = "test-support")]
impl ObserverDrop {
    pub(crate) fn new() -> Self {
        Self(std::env::var_os("REBOOT_TEST_EXPLICIT_ABORT_PARK").map(std::path::PathBuf::from))
    }
}
#[cfg(feature = "test-support")]
impl Drop for ObserverDrop {
    fn drop(&mut self) {
        if let Some(path) = &self.0 {
            std::fs::write(path.with_extension("observer-dropped"), b"dropped").unwrap();
        }
    }
}
#[cfg(feature = "test-support")]
pub(crate) async fn park_after_decision() {
    if let Some(path) = std::env::var_os("REBOOT_TEST_EXPLICIT_ABORT_PARK") {
        let path = std::path::PathBuf::from(path);
        std::fs::write(&path, b"real DecisionPut ACK").unwrap();
        tokio::time::timeout(std::time::Duration::from_secs(20), async {
            while !path.with_extension("release").exists() {
                tokio::time::sleep(std::time::Duration::from_millis(10)).await;
            }
        })
        .await
        .expect("explicit Abort test barrier timed out");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn enqueue(owner: &ExplicitAbortOwner, work: Work) -> oneshot::Receiver<Result<(), Status>> {
        let permit = owner.capacity.clone().try_acquire_owned().unwrap();
        let (reply, observer) = oneshot::channel();
        owner
            .sender
            .try_send(Job::new(owner, work, reply, Some(permit)))
            .ok()
            .unwrap();
        observer
    }
    #[tokio::test]
    async fn observer_drop_does_not_cancel_owned_work_and_capacity_counts_running() {
        let owner = ExplicitAbortOwner::new(1).unwrap();
        let mut supervisor = JoinSet::new();
        let cancel = RecoveryCancellation::new();
        owner
            .recovery_registration()
            .start(&mut supervisor, cancel.clone())
            .await
            .unwrap();
        let (release, wait) = oneshot::channel();
        let (done, completed) = oneshot::channel();
        drop(enqueue(
            &owner,
            Box::pin(async move {
                wait.await.unwrap();
                done.send(()).unwrap();
                Ok(())
            }),
        ));
        tokio::task::yield_now().await;
        assert!(owner.capacity.clone().try_acquire_owned().is_err());
        release.send(()).unwrap();
        completed.await.unwrap();
        cancel.cancel();
        assert!(supervisor.join_next().await.unwrap().unwrap().is_ok());
        assert!(!owner.state.lock().unwrap().active);
        assert_eq!(owner.capacity.available_permits(), 1);
    }
    #[tokio::test]
    async fn queued_unpolled_work_is_dropped_and_joined_on_shutdown() {
        struct Dropped(oneshot::Sender<()>);
        impl Drop for Dropped {
            fn drop(&mut self) {
                let _ = &self.0;
            }
        }
        let owner = ExplicitAbortOwner::new(2).unwrap();
        let mut supervisor = JoinSet::new();
        let cancel = RecoveryCancellation::new();
        owner
            .recovery_registration()
            .start(&mut supervisor, cancel.clone())
            .await
            .unwrap();
        let first = enqueue(&owner, Box::pin(std::future::pending()));
        let (sender, dropped) = oneshot::channel();
        let guard = Dropped(sender);
        let second = enqueue(
            &owner,
            Box::pin(async move {
                let _guard = guard;
                panic!("queued work must never be polled");
            }),
        );
        cancel.cancel();
        assert!(supervisor.join_next().await.unwrap().unwrap().is_ok());
        assert!(first.await.is_err());
        assert!(second.await.is_err());
        assert!(dropped.await.is_err());
        assert_eq!(owner.capacity.available_permits(), 2);
    }
    #[tokio::test]
    async fn timeout_and_preexisting_failure_surface_as_host_child_failure() {
        for preexisting in [false, true] {
            let owner = ExplicitAbortOwner::new(1)
                .unwrap()
                .with_timeout(std::time::Duration::from_millis(10))
                .unwrap();
            if preexisting {
                owner
                    .failure
                    .send_replace(Some(Status::resource_exhausted("admission uncertainty")));
            }
            let mut supervisor = JoinSet::new();
            owner
                .recovery_registration()
                .start(&mut supervisor, RecoveryCancellation::new())
                .await
                .unwrap();
            let observer = enqueue(&owner, Box::pin(std::future::pending()));
            let status = supervisor.join_next().await.unwrap().unwrap().unwrap_err();
            assert_eq!(
                status.code(),
                if preexisting {
                    tonic::Code::ResourceExhausted
                } else {
                    tonic::Code::DeadlineExceeded
                }
            );
            let _ = observer.await;
            assert!(!owner.state.lock().unwrap().active);
        }
    }
}

#[cfg(test)]
#[path = "host_explicit_abort_shutdown_tests.rs"]
mod host_explicit_abort_shutdown_tests;
