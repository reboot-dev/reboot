from __future__ import annotations

import grpc
import json
import opentelemetry.propagate
import uuid
from dataclasses import dataclass, replace
from reboot.aio.call import validate_ascii
from reboot.aio.caller_id import CallerID
from reboot.aio.internals.contextvars import get_application_id
from reboot.aio.types import (
    ApplicationId,
    GrpcMetadata,
    ServerId,
    StateId,
    StateRef,
    StateTypeName,
)
from reboot.settings import MAX_BEARER_TOKEN_LENGTH
from reboot.time import DateTimeWithTimeZone
from typing import Any, Callable, Optional

# This code ties in with the concept of a Context. There are a lot of open
# questions about what information is carried on a context and how it is
# represented and transmitted. We believe that the Context need to contain
# information about the full call DAG, but it is currently unclear how this
# information should be encoded. Similarly, it is unclear how this information
# should be transmitted. We believe that gRPC metadata is the correct way of
# transmitting this data but the encoding of the DAG into gRPC metadata is not
# well understood.
#
# From the full call DAG information, it should be possible to obtain various
# information that is needed by the Context, such as the current safety level,
# the state that is currently being served, etc. Until we have a better idea for
# how we are a) representing these and b) encoding them into metadata headers,
# we are "cherry picking" the necessary DAG information and sticking it on
# individual headers.
#
# This small library is intended as an abstraction layer to provide the ability
# to encode and decode DAG information as grpc headers without having to care
# too much about the current implementation.

# The header that tells us what application we're targeting.
APPLICATION_ID_HEADER = 'x-reboot-application-id'
# The header that carries state reference information.
STATE_REF_HEADER = 'x-reboot-state-ref'
# The header that carries information about which server this request should
# be handled by.
SERVER_ID_HEADER = 'x-reboot-server-id'

# The id of the workflow being executed, if any.
WORKFLOW_ID_HEADER = 'x-reboot-workflow-id'

# The iteration of the workflow control loop, if any.
WORKFLOW_ITERATION_HEADER = 'x-reboot-workflow-iteration'

# Transaction related headers.
TRANSACTION_IDS_HEADER = 'x-reboot-transaction-ids'
TRANSACTION_COORDINATOR_STATE_TYPE_HEADER = 'x-reboot-transaction-coordinator-state-type'
TRANSACTION_COORDINATOR_STATE_REF_HEADER = 'x-reboot-transaction-coordinator-state-ref'
TRANSACTION_PARTICIPANTS_HEADER = 'x-reboot-transaction-participants'
# Deprecated: never emitted anymore. Kept for eagerly failing
# transactions that contain a mix of servers. Remove once no old
# servers remain that may emit this header.
TRANSACTION_PARTICIPANTS_TO_ABORT_HEADER = (
    'x-reboot-transaction-participants-to-abort'
)
# Transaction participants that are read-only (expect `Prepare` but
# don't need `Commit`).
TRANSACTION_PARTICIPANTS_READ_ONLY_HEADER = (
    'x-reboot-transaction-participants-read-only'
)
# Whether the transaction coordinator supports read-only
# participants. New coordinators set this to `True` for
# transactional RPCs; old coordinators never set it.
TRANSACTION_COORDINATOR_READ_ONLY_AWARE_HEADER = (
    'x-reboot-transaction-coordinator-read-only-aware'
)
# The age of the transaction: the root transaction id of its first
# attempt. A retry carries it so that participants order the retried
# transaction as its first attempt rather than as a new, younger,
# transaction. Absent on a first attempt, whose age is then its own
# root transaction id.
TRANSACTION_RETRY_AGE_HEADER = 'x-reboot-transaction-retry-age'

# The header that carries the idempotency key for a mutation.
#
# TODO(benh): investigate using the proposed 'Idempotency-Key' header
# instead:
# https://datatracker.ietf.org/doc/draft-ietf-httpapi-idempotency-key-header
IDEMPOTENCY_KEY_HEADER = 'x-reboot-idempotency-key'

# Used to identify the caller application. Trusted by the time it is
# received by an application (i.e. it is the infrastructure's job to
# ensure that this header is set to the true identity of the caller).
CALLER_ID_HEADER = 'x-reboot-caller-id'

AUTHORIZATION_HEADER = 'authorization'

COOKIE_HEADER = 'cookie'

# Headers for calling/scheduling tasks directly.
TASK_SCHEDULE = 'x-reboot-task-schedule'

# Metadata that's only used in a _trailing_ capacity (never passed in
# a request and thus we don't try and extract it).
TASK_ID_UUID = 'x-reboot-task-id-uuid'

# OpenTelemetry W3C Trace Context header
# See: https://www.w3.org/TR/trace-context/
TRACEPARENT_HEADER = 'traceparent'
TRACESTATE_HEADER = 'tracestate'

# Header indicating this call originates from within a Reboot method
# (reader, writer, transaction, or workflow) rather than using an
# `ExternalContext`. Note that this is different from the
# `CALLER_ID_HEADER`; the latter is set on any call by a Reboot
# application, even if that call comes from an `ExternalContext`
# (e.g., a legacy gRPC servicer).
INTERNAL_CALL_HEADER = 'x-reboot-internal-call'


@dataclass(kw_only=True, frozen=True)
class Headers:
    """Dataclass for working with reboot metadata headers.

    NOTE: `from_grpc_metadata` extracts only the known headers and
    drops others. THIS IS BY DESIGN, so that Reboot will NOT
    transitively forward unknown headers from its inbound RPCs to its
    outbound sub-RPCs. This enables patterns like passing flags that
    change behavior in callee's but being able to guarnatee that if an
    upstream callee propagates said flag that means that it also is
    understand and will do the correct thing for that flag. An example
    is `TRANSACTION_COORDINATOR_READ_ONLY_AWARE_HEADER`, which if it
    gets dropped by a callee that has not yet been updated is fine,
    but would be catastrophic if it got blindly forwarded on from a
    callee that doesn't properly support it.
    """
    # The _target_ (callee) application's ID. May or may not be the same
    # as the caller's application ID, if they even have one.
    #
    # NOTE: in tests when using a `ExternalContext` we might not know
    # our target application's ID and thus this is optional. That being
    # said, when we receive an RPC we always fill in the application ID
    # based on the asyncio context variable that has been set, and thus
    # we know that we always have an application ID when we have a
    # `Context`.
    application_id: Optional[ApplicationId]
    state_ref: StateRef
    workflow_id: Optional[uuid.UUID] = None
    workflow_iteration: Optional[int] = None

    # Transaction IDs that make up the path from root and nested
    # transactions to the current transaction.
    transaction_ids: Optional[list[uuid.UUID]] = None
    transaction_coordinator_state_type: Optional[StateTypeName] = None
    transaction_coordinator_state_ref: Optional[StateRef] = None

    # The root transaction id of the transaction's first attempt; see
    # `TRANSACTION_RETRY_AGE_HEADER`.
    transaction_retry_age: Optional[uuid.UUID] = None

    idempotency_key: Optional[uuid.UUID] = None

    bearer_token: Optional[str] = None

    task_schedule: Optional[DateTimeWithTimeZone] = None

    server_id: Optional[ServerId] = None

    cookie: Optional[str] = None

    # Contains a "caller ID" that encodes the identity of the calling
    # application and, for a call from within a Reboot method, the
    # `Auth` on whose behalf it is made (see `CallerID.auth`).
    # Otherwise the user on whose behalf the call was made is
    # identified by the bearer token.
    caller_id: Optional[CallerID] = None

    # OpenTelemetry W3C Trace Context headers for manual span context
    # propagation when not using opentelemetry's automatic gRPC interceptors.
    traceparent: Optional[str] = None
    tracestate: Optional[str] = None

    # Whether this call originates from within a Reboot method, i.e.,
    # not an `ExternalContext`.
    internal_call: bool = False

    # Whether the transaction coordinator supports read-only
    # participants.
    coordinator_read_only_aware: bool = False

    def __post_init__(self):
        validate_ascii(
            self.bearer_token,
            'bearer_token',
            MAX_BEARER_TOKEN_LENGTH,
            # It is never legal to have a newline in values that may get encoded
            # into headers.
            illegal_characters='\n',
        )

        # Automatically populate OpenTelemetry tracing headers if not
        # already set and if a tracing context is present.
        if self.traceparent is None and self.tracestate is None:
            carrier: dict[str, str] = {}
            opentelemetry.propagate.inject(carrier)
            if TRACEPARENT_HEADER in carrier:
                # `__setattr__` is a workaround for this object being
                # frozen post-init.
                object.__setattr__(
                    self, 'traceparent', carrier[TRACEPARENT_HEADER]
                )
            if TRACESTATE_HEADER in carrier:
                # `__setattr__` is a workaround for this object being
                # frozen post-init.
                object.__setattr__(
                    self, 'tracestate', carrier[TRACESTATE_HEADER]
                )

    def copy_for_token_verification_and_authorization(self):
        """Returns a copy of the headers that is suitable for use when doing
        token verification or authorization.

        In particular, we drop anything related to transactions (as we
        don't want to include token verification or authorization as
        part of the transaction), the idempotency key. Some users might want to
        have access to the bearer token in their authorizers (i.e., to pass it
        to a third part service), so we keep it in the copy.
        """
        return Headers(
            application_id=self.application_id,
            server_id=self.server_id,
            state_ref=self.state_ref,
            cookie=self.cookie,
            caller_id=self.caller_id,
            bearer_token=self.bearer_token,
            traceparent=self.traceparent,
            tracestate=self.tracestate,
        )

    @classmethod
    def from_grpc_context(
        cls,
        grpc_context: grpc.aio.ServicerContext,
    ) -> Headers:
        """Convert and parse gRPC metadata from a gRPC context to `Headers`."""
        # Extract the raw gRPC metadata from gRPC context to dictionary.
        return cls.from_grpc_metadata(grpc_context.invocation_metadata())

    @classmethod
    def from_grpc_metadata(
        cls,
        metadata: GrpcMetadata,
    ) -> Headers:
        """Convert and parse gRPC metadata to `Headers`."""
        raw_headers = dict(metadata)

        def extract_maybe(
            name: str,
            *,
            required=False,
            convert: Callable[[str], Any] = lambda value: value,
        ) -> Optional[Any]:
            try:
                return convert(raw_headers[name])
            except KeyError as e:
                if required:
                    raise ValueError(f"gRPC metadata missing '{name}'") from e
                else:
                    return None

        def extract(
            name: str,
            *,
            convert: Callable[[str], Any] = lambda value: value,
        ) -> Any:
            return extract_maybe(name, required=True, convert=convert)

        # For now, we always use the application ID provided in the
        # asyncio context variable because in tests when using a
        # `ExternalContext` we don't always know the application ID (e.g.,
        # because we've done `rbt.up(...)` more than once but aren't
        # passing a `gateway` to `ExternalContext`).
        #
        # NOTE: the asyncio context variable gets set via the
        # `UseApplicationIdInterceptor` which is added to every
        # server. If we have a `grpc_context`, then we must have been
        # called through a gRPC server, with which we injected the
        # interceptor.
        application_id = get_application_id()
        assert application_id is not None

        server_id = extract_maybe(SERVER_ID_HEADER)

        # We use `from_maybe_readable` as an affordance for hand-written calls.
        state_ref = StateRef.from_maybe_readable(extract(STATE_REF_HEADER))

        workflow_id: Optional[uuid.UUID] = extract_maybe(
            WORKFLOW_ID_HEADER,
            convert=lambda value: uuid.UUID(value),
        )

        workflow_iteration: Optional[int] = extract_maybe(
            WORKFLOW_ITERATION_HEADER,
            convert=lambda value: int(value),
        )

        transaction_ids: Optional[list[uuid.UUID]] = extract_maybe(
            TRANSACTION_IDS_HEADER,
            convert=lambda value: [
                uuid.UUID(transaction_id)
                for transaction_id in json.loads(value)
            ],
        )

        transaction_coordinator_state_type: Optional[
            StateTypeName] = extract_maybe(
                TRANSACTION_COORDINATOR_STATE_TYPE_HEADER,
                required=transaction_ids is not None,
            )

        transaction_coordinator_state_ref_str: Optional[str] = extract_maybe(
            TRANSACTION_COORDINATOR_STATE_REF_HEADER,
            required=transaction_ids is not None,
        )
        transaction_coordinator_state_ref = (
            StateRef(transaction_coordinator_state_ref_str)
            if transaction_coordinator_state_ref_str is not None else None
        )

        transaction_retry_age: Optional[uuid.UUID] = extract_maybe(
            TRANSACTION_RETRY_AGE_HEADER,
            convert=lambda value: uuid.UUID(value),
        )

        idempotency_key: Optional[uuid.UUID] = extract_maybe(
            IDEMPOTENCY_KEY_HEADER,
            convert=lambda value: uuid.UUID(value),
        )

        bearer_token: Optional[str] = extract_maybe(
            AUTHORIZATION_HEADER,
            convert=lambda value: value.removeprefix('Bearer '),
        )

        task_schedule: Optional[DateTimeWithTimeZone] = extract_maybe(
            TASK_SCHEDULE,
            # If the value of the header is empty, we default to the current
            # time.
            convert=lambda value: DateTimeWithTimeZone.fromisoformat(value)
            if len(value) else DateTimeWithTimeZone.now(),
        )

        cookie: Optional[str] = extract_maybe(COOKIE_HEADER)

        caller_id: Optional[CallerID] = extract_maybe(
            CALLER_ID_HEADER,
            convert=CallerID.parse,
        )

        traceparent: Optional[str] = extract_maybe(TRACEPARENT_HEADER)
        tracestate: Optional[str] = extract_maybe(TRACESTATE_HEADER)

        internal_call: bool = extract_maybe(
            INTERNAL_CALL_HEADER,
            convert=lambda value: value == 'true',
        ) or False

        coordinator_read_only_aware: bool = (
            TRANSACTION_COORDINATOR_READ_ONLY_AWARE_HEADER in raw_headers
        )

        return cls(
            application_id=application_id,
            server_id=server_id,
            state_ref=state_ref,
            workflow_id=workflow_id,
            workflow_iteration=workflow_iteration,
            transaction_ids=transaction_ids,
            transaction_coordinator_state_type=
            transaction_coordinator_state_type,
            transaction_coordinator_state_ref=transaction_coordinator_state_ref,
            transaction_retry_age=transaction_retry_age,
            idempotency_key=idempotency_key,
            bearer_token=bearer_token,
            task_schedule=task_schedule,
            cookie=cookie,
            caller_id=caller_id,
            traceparent=traceparent,
            tracestate=tracestate,
            internal_call=internal_call,
            coordinator_read_only_aware=coordinator_read_only_aware,
        )

    @property
    def state_id(self) -> StateId:
        """Return the StateId."""
        return self.state_ref.id

    def to_grpc_metadata(self) -> GrpcMetadata:
        """Encode these headers as gRPC metadata."""

        def maybe_add_application_id_header() -> GrpcMetadata | tuple[()]:
            if self.application_id is not None:
                return ((APPLICATION_ID_HEADER, self.application_id),)
            return ()

        def maybe_add_server_id_header() -> GrpcMetadata | tuple[()]:
            if self.server_id is not None:
                return ((SERVER_ID_HEADER, self.server_id),)
            return ()

        def maybe_add_authorization_header() -> GrpcMetadata | tuple[()]:
            if self.bearer_token is not None:
                return (
                    (AUTHORIZATION_HEADER, f'Bearer {self.bearer_token}'),
                )
            return ()

        def maybe_add_cookie_header() -> GrpcMetadata | tuple[()]:
            if self.cookie is not None:
                return ((COOKIE_HEADER, self.cookie),)
            return ()

        def maybe_add_workflow_headers() -> GrpcMetadata | tuple[()]:
            headers: GrpcMetadata = ()
            if self.workflow_id is not None:
                headers += ((WORKFLOW_ID_HEADER, str(self.workflow_id)),)
            if self.workflow_iteration is not None:
                headers += (
                    (
                        WORKFLOW_ITERATION_HEADER,
                        str(self.workflow_iteration),
                    ),
                )
            return headers

        def maybe_add_transaction_headers() -> GrpcMetadata | tuple[()]:
            if self.transaction_ids is not None:
                assert len(self.transaction_ids) > 0
                assert self.transaction_coordinator_state_type is not None
                assert self.transaction_coordinator_state_ref is not None
                return (
                    (
                        TRANSACTION_IDS_HEADER,
                        json.dumps(
                            [
                                str(transaction_id)
                                for transaction_id in self.transaction_ids
                            ]
                        )
                    ),
                    (
                        TRANSACTION_COORDINATOR_STATE_TYPE_HEADER,
                        self.transaction_coordinator_state_type
                    ),
                    (
                        TRANSACTION_COORDINATOR_STATE_REF_HEADER,
                        self.transaction_coordinator_state_ref.to_str()
                    ),
                )
            return ()

        def maybe_add_transaction_retry_age_header(
        ) -> GrpcMetadata | tuple[()]:
            # Sent apart from the transaction headers above because a
            # retried transaction's age is carried by the call that
            # starts the transaction over, which has no transaction
            # ids yet: the coordinator mints those when the call
            # arrives and keeps the age it came with.
            if self.transaction_retry_age is not None:
                return (
                    (
                        TRANSACTION_RETRY_AGE_HEADER,
                        str(self.transaction_retry_age)
                    ),
                )
            return ()

        def maybe_add_idempotency_key_header() -> GrpcMetadata | tuple[()]:
            if self.idempotency_key is not None:
                return ((IDEMPOTENCY_KEY_HEADER, str(self.idempotency_key)),)
            return ()

        def maybe_add_opentelemetry_headers() -> GrpcMetadata | tuple[()]:
            headers: GrpcMetadata | tuple[()] = ()
            if self.traceparent is not None:
                headers += ((TRACEPARENT_HEADER, self.traceparent),)
            if self.tracestate is not None:
                headers += ((TRACESTATE_HEADER, self.tracestate),)
            return headers

        def maybe_add_caller_id_header() -> GrpcMetadata | tuple[()]:
            if self.caller_id is None:
                return ()
            caller_id = self.caller_id
            if self.bearer_token is not None and caller_id.auth is not None:
                # A bearer token is what gets verified for this call;
                # never pass an `Auth` along with it.
                caller_id = replace(caller_id, auth=None)
            return ((CALLER_ID_HEADER, str(caller_id)),)

        def maybe_add_internal_call_header() -> GrpcMetadata | tuple[()]:
            if self.internal_call:
                return ((INTERNAL_CALL_HEADER, 'true'),)
            return ()

        def maybe_add_coordinator_read_only_aware_header(
        ) -> GrpcMetadata | tuple[()]:
            if self.coordinator_read_only_aware:
                return (
                    (TRANSACTION_COORDINATOR_READ_ONLY_AWARE_HEADER, 'true'),
                )
            return ()

        return (
            ((STATE_REF_HEADER, self.state_ref.to_str()),) +
            maybe_add_application_id_header() + maybe_add_server_id_header() +
            maybe_add_authorization_header() + maybe_add_cookie_header() +
            maybe_add_transaction_headers() +
            maybe_add_transaction_retry_age_header() +
            maybe_add_workflow_headers() + maybe_add_idempotency_key_header() +
            maybe_add_opentelemetry_headers() + maybe_add_caller_id_header() +
            maybe_add_internal_call_header() +
            maybe_add_coordinator_read_only_aware_header()
        )
