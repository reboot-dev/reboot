"""Values shared between the dashboard application and the CLI.

Kept apart from `main.py` so that reading them does not drag in the
application and everything it serves with.
"""

from pathlib import Path

# The dashboard's built page, beside the application's module, which
# is the same arrangement `InspectServicer` uses for its own assets.
# The CLI serves it at `/` the way `--web-app-dist-path` would, by
# naming it (absolute, since no project root is involved) in the
# application's environment.
DASHBOARD_DIRECTORY = Path(__file__).parent / 'dashboard'

# The dashboard application's port. Deliberately not adjacent to
# `rbt dev run`'s default port of 9991: VS Code forwards a port
# upward when the one it wants is already taken on the developer's
# machine, so a second dev container serving on 9991 arrives on
# 9992. A dashboard sitting there could be reached in place of
# somebody else's backend, which half-works and is far more
# confusing than not working at all. 9871 is below 9991 so upward
# forwarding never reaches it, outside the 999x band (9990 k3d and
# WildFly, 9993 ZeroTier, 9997 Splunk), clear of
# 9000/9090/9200/9222/9229, hard to confuse with 9991 when reading
# logs, and outside the Linux ephemeral range. Under `--portless` the
# dashboard's address is its name, `https://dashboard.<app>.localhost`,
# and the port behind the proxy is a free one.
DEFAULT_DASHBOARD_PORT = 9871

# The `Dashboard` state holding everything the dashboard shows, as
# the dashboard application last read it.
DASHBOARD_ID = 'dashboard'

# The `Preferences` state holding what the developer has said about
# opening dashboards: the dashboard's notice writes it and
# `rbt dashboard` reads it.
PREFERENCES_ID = 'preferences'

# The `OrderedMap` of changes to the developer's API files, keyed by
# uuidv7 so a reverse range is newest first.
CHANGELOG_ID = 'changelog'

# The directory the developer's API files are in, as the `.rbtrc`
# spells it for `rbt generate`. Separate from the application's URL
# because the files are there long before anything is serving, and
# the dashboard is meant to be startable that early.
ENVVAR_RBT_API_DIRECTORY = 'RBT_API_DIRECTORY'

# The developer's application entry point, as the `.rbtrc` spells it
# for `rbt dev run`. What the API files declare says nothing about
# which file implements a state type; the application, which registers
# the servicers, is what says. Unset when the developer named none, in
# which case no implementation is looked for.
ENVVAR_RBT_APPLICATION = 'RBT_APPLICATION'

# The directory `rbt generate` writes Python code into, as the
# `.rbtrc` spells it with `--python=`. The generated code is where
# the state types are defined, which is what typing the developer's
# implementation needs. Unset when the developer named none, in which
# case nothing can be typed.
ENVVAR_RBT_GENERATED_DIRECTORY = 'RBT_GENERATED_DIRECTORY'

# The `Presence` state the dashboard page subscribes to, recording who
# is looking at a dashboard right now. `rbt dashboard` reads it to
# decide whether to open one.
#
# The page names this, `DASHBOARD_ID` and `PREFERENCES_ID` independently,
# in `frontend/src/constants.ts`, since TypeScript cannot read them
# from here. Keep the two in step.
PRESENCE_ID = 'dashboard'
