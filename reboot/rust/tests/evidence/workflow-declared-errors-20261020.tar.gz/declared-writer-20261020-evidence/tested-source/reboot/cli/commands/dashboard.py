"""The `rbt dashboard` command, which runs the developer dashboard."""
import argparse
import asyncio
import os
import reboot.portless
import secrets
import shutil
import sys
import webbrowser
from pathlib import Path
from rbt.dashboard.v1.dashboard_rbt import Preferences
from rbt.std.presence.v1.presence_rbt import Presence
from reboot.aio.backoff import Backoff
from reboot.aio.external import ExternalContext
from reboot.cli.commands.dev import (
    check_local_envoy_mode,
    try_and_become_child_subreaper_on_linux,
)
from reboot.cli.common import portless, terminal
from reboot.cli.common.dev_extra import dev_extra_installed, missing_dev_extra
from reboot.cli.common.directories import (
    add_working_directory_options,
    dot_rbt_directory,
    use_working_directory,
)
from reboot.cli.common.rc import ArgumentParser
from reboot.cli.common.subprocesses import Subprocesses
from reboot.dashboard.backend.constants import (
    DASHBOARD_DIRECTORY,
    DEFAULT_DASHBOARD_PORT,
    ENVVAR_RBT_API_DIRECTORY,
    ENVVAR_RBT_APPLICATION,
    ENVVAR_RBT_GENERATED_DIRECTORY,
    PREFERENCES_ID,
    PRESENCE_ID,
)
from reboot.settings import (
    ENVVAR_RBT_DEV,
    ENVVAR_RBT_EFFECT_VALIDATION,
    ENVVAR_RBT_FRONTEND_URL,
    ENVVAR_RBT_MCP_APP_DIST_PATH,
    ENVVAR_RBT_NAME,
    ENVVAR_RBT_NODEJS,
    ENVVAR_RBT_PORTLESS_NAME,
    ENVVAR_RBT_SERVE,
    ENVVAR_RBT_SERVERS,
    ENVVAR_RBT_STATE_DIRECTORY,
    ENVVAR_RBT_WEB_APP_DIST_PATH,
    ENVVAR_REBOOT_CRYPTO_ROOT_KEYS,
    ENVVAR_REBOOT_EXPECTED_VERSION,
    ENVVAR_REBOOT_LOCAL_ENVOY,
    ENVVAR_REBOOT_LOCAL_ENVOY_PORT,
    ENVVAR_REBOOT_OAUTH_SIGNING_SECRET,
)
from reboot.version import REBOOT_VERSION
from typing import Optional

# The dashboard application's name, which names its state directory
# under `.rbt/`. A sibling of `.rbt/dev/` rather than inside it, so
# that it can never collide with a developer's application, whose
# state lives at `.rbt/dev/<application-name>/`.
DASHBOARD_STATE_DIRECTORY_NAME = 'dashboard'


def dashboard_subcommands() -> list[str]:
    return ['dashboard']


def register_dashboard(parser: ArgumentParser):
    add_working_directory_options(parser.subcommand('dashboard'))

    parser.subcommand('dashboard').add_argument(
        '--port',
        type=int,
        help='port on which the dashboard will serve traffic; defaults to '
        f'{DEFAULT_DASHBOARD_PORT}, or under `--portless`, where the name '
        'is the address, to a free port',
    )

    parser.subcommand('dashboard').add_argument(
        '--portless',
        type=bool,
        default=False,
        help=(
            'serve under a named `.localhost` URL via portless '
            '(https://github.com/vercel-labs/portless): registers '
            'the dashboard with the running portless proxy as '
            '`https://dashboard.<application-name>.localhost`, beside '
            "the application's `https://<application-name>.localhost`. "
            'The name is the '
            "application's, from `dev run --application-name` in "
            f'{parser.dot_rc_filename}. Requires the `portless` CLI on '
            'PATH with its proxy started (`portless proxy start`).'
        ),
    )


def _api_directory(parser: ArgumentParser) -> str:
    """Returns the directory holding the developer's API files, which
    is the directory they tell `rbt generate` to read them from.

    Everything the dashboard reads of the developer's project comes
    from `.rbtrc` and nowhere else: a pydantic API under
    `generate api/`, the application under `dev run --application=`,
    and the Python `rbt generate` writes under `generate --python=`.
    `rbt dashboard` runs apart from `rbt dev run` and `rbt generate`,
    so a flag given to either on the command line reaches nothing
    here; it has to be in `.rbtrc`.

    Taken from there rather than named again here, so that moving the
    API files is one edit and the dashboard cannot end up watching a
    directory the rest of the tooling has stopped using.
    """
    for argument in parser.dot_rc_arguments('generate'):
        # The directory is the one thing `rbt generate` takes that is
        # not a flag; its flags say where to put what it generates.
        if not argument.startswith('-'):
            return argument

    terminal.fail(
        'Could not tell where your API files are. `rbt dashboard` reads '
        f'that from the same place `rbt generate` does, so name a '
        f'directory for it in your {parser.dot_rc_filename}:\n'
        '\n'
        '    generate api/\n'
    )


def _application(parser: ArgumentParser) -> Optional[str]:
    """Returns the developer's application, which is the one they tell
    `rbt dev run` to run, and `None` when they tell it none.

    Read rather than asked for again, so that moving the application
    is one edit; a second place to name it is a second place to forget
    to change. `None` is what an application this cannot read looks
    like -- a Node.js one names no Python for the servicers to be in.
    """
    for argument in parser.dot_rc_arguments('dev run'):
        name, separator, value = argument.partition('=')
        if name == '--application' and separator == '=':
            return value

    return None


def _application_name(parser: ArgumentParser) -> Optional[str]:
    """Returns the developer's application's name, which is the one
    they tell `rbt dev run` to save state under, or `None` when they
    name none.

    Read rather than asked for again, so that `rbt dev run --portless`
    and this agree on the name without anybody keeping them so.
    """
    for argument in parser.dot_rc_arguments('dev run'):
        name, separator, value = argument.partition('=')
        if name == '--application-name' and separator == '=':
            return value
    return None


def _generated_directory(parser: ArgumentParser) -> Optional[str]:
    """Returns the directory `rbt generate` writes Python code into,
    which is where its `--python=` flag points, and `None` when it
    points nowhere.

    Read rather than asked for again, for the same reason as the
    application. `None` is what an application with no generated
    Python looks like, such as a Node.js one.
    """
    for argument in parser.dot_rc_arguments('generate'):
        name, separator, value = argument.partition('=')
        if name == '--python' and separator == '=':
            return value

    return None


def _dashboard_env(
    args,
    parser: ArgumentParser,
    *,
    port: int,
    portless_name: Optional[str] = None,
    api_directory: str,
    application: Optional[str],
    generated_directory: Optional[str],
) -> dict[str, str]:
    """The environment for the dashboard application.

    Built from the ambient environment rather than from any
    application environment, so that nothing naming a developer's
    application, such as its name, state directory, port, launcher or
    frontend, reaches an application that shares none of it.
    """
    composed = os.environ.copy()

    # Every other application-flavored variable is overwritten below;
    # these four have no dashboard value to overwrite them with, so a
    # developer's shell export would leak through and make the
    # dashboard a Node.js application or serve their MCP Apps.
    for name in (
        ENVVAR_RBT_NODEJS,
        ENVVAR_RBT_FRONTEND_URL,
        ENVVAR_RBT_MCP_APP_DIST_PATH,
        ENVVAR_RBT_WEB_APP_DIST_PATH,
    ):
        composed.pop(name, None)

    # The dashboard's page is its web app, served at `/` the way
    # `--web-app-dist-path` serves a developer's; absolute, since the
    # dashboard has no project root for a relative path to resolve
    # against.
    composed[ENVVAR_RBT_WEB_APP_DIST_PATH] = str(DASHBOARD_DIRECTORY)

    # Served with `rbt serve` defaults rather than `rbt dev` ones.
    # Popped rather than left unset, since `detect_run_environment`
    # reads `RBT_DEV` first.
    composed.pop(ENVVAR_RBT_DEV, None)
    composed[ENVVAR_RBT_SERVE] = 'true'

    # Also what `rbt serve` sets: `RBT_SERVE` alone is not enough to
    # produce a `rbt serve` environment.
    composed[ENVVAR_RBT_EFFECT_VALIDATION] = 'DISABLED'

    composed[ENVVAR_REBOOT_EXPECTED_VERSION] = REBOOT_VERSION
    composed[ENVVAR_REBOOT_LOCAL_ENVOY] = 'true'
    composed[ENVVAR_REBOOT_LOCAL_ENVOY_PORT] = str(port)
    if portless_name is not None:
        # The dashboard application registers this name once it is
        # serving (see `reboot.portless.alias`).
        composed[ENVVAR_RBT_PORTLESS_NAME] = portless_name

    # A single server, so that a subscriber's `Connect` and
    # `Toggle` always land on the same process; presence tracks its
    # connections in memory there. `ENVVAR_REBOOT_LOCAL_ENVOY` is
    # set above because one server otherwise turns Envoy off, and
    # the browser has to reach this application.
    composed[ENVVAR_RBT_SERVERS] = '1'

    # Where the developer's API files are, which the dashboard can
    # read whether or not anything is running. Passed the way the
    # developer spelled it, so that a file can be shown as
    # `api/bank/v1/account.py`; the dashboard runs in this working
    # directory, where that spelling resolves.
    composed[ENVVAR_RBT_API_DIRECTORY] = api_directory

    # Where the developer's servicers are, spelled the same way and
    # for the same reason. Left out of the environment entirely when
    # the developer named no application, which is what tells the
    # dashboard there is nothing to look for.
    composed.pop(ENVVAR_RBT_APPLICATION, None)
    if application is not None:
        composed[ENVVAR_RBT_APPLICATION] = application

    # Where the developer's generated Python is, spelled the same way
    # and for the same reason. Left out when the developer named no
    # `--python` directory, which is what tells the dashboard there is
    # nothing to type the implementation with.
    composed.pop(ENVVAR_RBT_GENERATED_DIRECTORY, None)
    if generated_directory is not None:
        composed[ENVVAR_RBT_GENERATED_DIRECTORY] = generated_directory

    composed[ENVVAR_RBT_NAME] = DASHBOARD_STATE_DIRECTORY_NAME

    state_directory = (
        dot_rbt_directory(args, parser) / DASHBOARD_STATE_DIRECTORY_NAME
    )
    composed[ENVVAR_RBT_STATE_DIRECTORY] = str(state_directory)

    root_keys_path = state_directory / 'crypto-root-keys'
    if root_keys_path.exists():
        composed[ENVVAR_REBOOT_CRYPTO_ROOT_KEYS] = root_keys_path.read_text()
    else:
        root_keys = f'v1:{secrets.token_urlsafe(32)}'
        root_keys_path.parent.mkdir(parents=True, exist_ok=True)
        root_keys_path.write_text(root_keys)
        composed[ENVVAR_REBOOT_CRYPTO_ROOT_KEYS] = root_keys

    composed[ENVVAR_REBOOT_OAUTH_SIGNING_SECRET] = composed[
        ENVVAR_REBOOT_CRYPTO_ROOT_KEYS]

    return composed


async def _run_dashboard(
    *,
    env: dict[str, str],
    state_directory: Path,
    subprocesses: Subprocesses,
) -> None:
    """Runs the dashboard application, restarting it if it exits.

    The dashboard's schema changes whenever Reboot's does, so the
    expected reason for it to fail at startup is a backwards
    incompatibility after an upgrade. Its state is ours and is
    disposable, so the first failure deletes it and tries again
    without asking. A second failure is something else, and gets
    reported once rather than silently retried forever.
    """
    backoff = Backoff()
    failures = 0
    reported = False

    while True:
        async with subprocesses.exec(
            sys.executable,
            '-m',
            'reboot.dashboard.backend.main',
            env=env,
        ) as process:
            await process.wait()
            failed = process.returncode != 0

        if not failed:
            failures = 0
        else:
            failures += 1

            if failures == 1:
                await asyncio.to_thread(
                    shutil.rmtree, state_directory, ignore_errors=True
                )
            elif not reported:
                reported = True
                terminal.warn(
                    'The dashboard application keeps failing to start; '
                    'still trying.'
                )

        await backoff()


async def _viewers(dashboard_url: str) -> list[str]:
    """The subscriber ids of everyone looking at a dashboard.

    The dashboard constructs the `Presence` instance, empty, when it
    initializes, so there is an answer from the moment it is up.
    """
    context = ExternalContext(name="open-dashboard", url=dashboard_url)
    response = await Presence.ref(PRESENCE_ID).List(context)
    return list(response.subscriber_ids)


async def _should_open_automatically(dashboard_url: str) -> bool:
    """Whether the developer still wants a dashboard opened for them.

    The dashboard's notice writes this when they click "Don't reopen
    automatically", and it outlives the `rbt dashboard` they clicked
    it in. The dashboard writes the default when it initializes, so
    nobody ever clicking means a dashboard opens.
    """
    context = ExternalContext(name="open-dashboard", url=dashboard_url)
    response = await Preferences.ref(PREFERENCES_ID).Get(context)
    return not response.suppress_automatic_open


def automatically_opened_url(dashboard_url: str) -> str:
    """The URL a dashboard is opened at, which tells the page it was
    opened automatically, letting it offer not to be opened again. The
    query only ever comes from here, so nobody is told to type it.
    """
    return f'{dashboard_url}/?opened=automatically'


# How long the dashboard application, which is still starting when
# `rbt dashboard` first asks it whether to open a dashboard, gets to
# answer, and how often it is asked again.
_ANSWER_WITHIN_SECONDS = 10.0
_ASK_EVERY_SECONDS = 0.5


async def _should_open(dashboard_url: str) -> bool:
    """Whether to open a dashboard: the developer has not said not to,
    and nobody is looking at one.

    Asks again until the application answers both questions. A call
    made while the application cannot be reached retries by itself;
    one it refuses because it has not initialized its states yet is
    repeated here.
    """
    while True:
        try:
            if not await _should_open_automatically(dashboard_url):
                return False
            return len(await _viewers(dashboard_url)) == 0
        except Exception:
            await asyncio.sleep(_ASK_EVERY_SECONDS)


async def _open_when_serving(
    *,
    origin: str,
    portless_name: Optional[str] = None,
) -> None:
    """Opens a dashboard once the dashboard application is serving,
    unless the developer clicked "Don't reopen automatically" in the
    notice an automatic open shows, which is remembered until they
    say otherwise, or somebody is already looking at one: the page
    subscribes to `Presence` for as long as it is open, so a tab left
    up -- from an earlier `rbt dashboard`, or from this session's
    browser -- keeps a second one from appearing, and a tab that was
    closed is replaced.

    The application gets `_ANSWER_WITHIN_SECONDS` to answer. If it
    has not by then, a dashboard is opened anyway, since nothing said
    not to.

    `Presence` learns that a viewer has gone from the cancellation of
    the page's `Connect` RPC, and nothing else. A proxy that holds its
    server-side socket open after the browser goes away therefore
    leaves a viewer listed who is not there, and the effect is that no
    dashboard opens; the URL this prints still reaches it.

    `origin` is where the browser is sent: the loopback port, or under
    `--portless` the dashboard's name, `portless_name`. The checks go
    to the dashboard application's port either way, under `--portless`
    the one the proxy routes the name to, once it is registered.
    """
    page_url = f'{origin}/'

    try:
        dashboard_url = origin
        if portless_name is not None:
            port = await portless.wait_for_port(portless_name)
            dashboard_url = f'http://127.0.0.1:{port}'

        try:
            should_open = await asyncio.wait_for(
                _should_open(dashboard_url),
                timeout=_ANSWER_WITHIN_SECONDS,
            )
        except asyncio.TimeoutError:
            should_open = True

        if not should_open:
            return

        # `webbrowser` honors `$BROWSER`, which is what makes this
        # work in Codespaces and devcontainers, and returns `False`
        # rather than raising when there is no browser to open. The
        # page is told it was opened automatically, so it can offer
        # not to be (see `automatically_opened_url`).
        if not await asyncio.to_thread(
            webbrowser.open, automatically_opened_url(origin)
        ):
            terminal.warn(
                f"Could not open a browser; your dashboard is at {page_url}"
            )
    except Exception as e:
        # Never let this take down `rbt dashboard`; the dashboard is
        # still reachable by hand.
        terminal.warn(f"Could not open a dashboard ({e}); it is at {page_url}")


async def dashboard(
    args,
    parser: ArgumentParser,
) -> int:
    """Implementation of the 'dashboard' subcommand."""
    # The dashboard reads the application's `.feature` files with the
    # packages the `reboot[dev]` extra installs, which every
    # development environment has; without them it would show no
    # features and say why on each file, so it refuses instead.
    if not dev_extra_installed():
        terminal.fail(missing_dev_extra('`rbt dashboard` needs it'))

    with use_working_directory(args, parser):
        # If on Linux try to become a child subreaper so that we can
        # properly clean up all processes descendant from us! Envoy in
        # particular is a grandchild, and one that outlives the
        # application would keep answering on the dashboard's port.
        try_and_become_child_subreaper_on_linux()

        subprocesses = Subprocesses()

        # Pick the mode in which we'll run a local Envoy proxy and
        # check that the mode is usable, e.g. that Docker is running
        # and can access the Envoy proxy image, or that the `envoy`
        # executable runs. Fail otherwise.
        await check_local_envoy_mode(subprocesses)

        # Under `--portless` the name is the address, so unless `--port`
        # says otherwise the port behind the proxy is any free one (0),
        # and the dashboards of several applications run at once; the
        # dashboard application registers the name once it is serving.
        portless_name: Optional[str] = None
        if args.portless:
            # The dashboard is `https://dashboard.<name>.localhost`
            # beside the application's `https://<name>.localhost`.
            application_name = _application_name(parser)
            if application_name is None:
                terminal.fail(
                    '`--portless` needs the application\'s name, which is '
                    'the hostname '
                    '(`https://dashboard.<application-name>.localhost`). '
                    '`rbt dashboard` reads it from your '
                    f'{parser.dot_rc_filename}, where `rbt dev run` does:\n'
                    '\n'
                    '    dev run --application-name=<application-name>\n'
                )
            await portless.check('--portless')
            portless_name = reboot.portless.dashboard_name(application_name)
            port = args.port if args.port is not None else 0
            origin = 'https://' + reboot.portless.hostname(portless_name)
        else:
            port = args.port or DEFAULT_DASHBOARD_PORT
            origin = f'http://127.0.0.1:{port}'

        env = _dashboard_env(
            args,
            parser,
            port=port,
            portless_name=portless_name,
            api_directory=_api_directory(parser),
            application=_application(parser),
            generated_directory=_generated_directory(parser),
        )

        terminal.info(f'Your dashboard is at {origin}/\n')

        open_task = asyncio.create_task(
            _open_when_serving(origin=origin, portless_name=portless_name),
            name=f'_open_when_serving(...) in {__name__}',
        )

        try:
            await _run_dashboard(
                env=env,
                state_directory=Path(env[ENVVAR_RBT_STATE_DIRECTORY]),
                subprocesses=subprocesses,
            )
        finally:
            open_task.cancel()

    return 0


async def handle_dashboard_subcommand(
    args: argparse.Namespace,
    *,
    parser: ArgumentParser,
) -> Optional[int]:
    if args.subcommand == 'dashboard':
        return await dashboard(args, parser)
    return None
