"""Asks pyright what the developer's code means.

Pyright is a type checker built to answer questions about code as it
is being written, which is exactly the dashboard's situation: it
infers types through unannotated helpers, containers, and branches,
and it degrades to `Unknown` rather than guessing when generated
code does not exist yet.

Spoken to over the Language Server Protocol on stdio. Whoever reads
a file syncs its text, and answers are about each file's text as
last synced. Files nobody syncs, such as generated code, the server
reads from disk once, so a change to one of those takes a fresh
server to be seen.
"""
import asyncio
import hashlib
import itertools
import json
import os
import signal
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence

# How long a server gets to shut down when asked, before it is killed.
SHUTDOWN_SECONDS = 5

# The heap the Node server may grow to. Node's default, about 4 GB, is
# too small for a mid-sized application's analysis. A limit, not an
# allocation: an analysis that needs little uses little.
HEAP_MEGABYTES = 12288


@dataclass(frozen=True, kw_only=True)
class Location:
    """Where a name is defined."""

    # The file the definition is in, spelled absolutely, which is how
    # the server spells every file.
    filename: Path

    # The line the definition starts on, counting from one, which is
    # how `ast` counts.
    line: int

    @property
    def standard_library(self) -> bool:
        """Whether the definition is in the standard library, builtins
        included.

        Pyright answers for those out of the typeshed stubs bundled
        with it, under `typeshed-fallback/stdlib`, so that is where a
        definition of `print` or `asyncio.sleep` lands.
        """
        parts = self.filename.parts
        return 'typeshed-fallback' in parts and parts[
            parts.index('typeshed-fallback') +
            1:parts.index('typeshed-fallback') + 2] == ('stdlib',)


@dataclass(frozen=True, kw_only=True)
class _Synced:
    """What was last synced for one file."""

    # The version number the protocol wants counted up per file.
    version: int

    # A digest of the text synced, to skip syncing the file again if
    # its text has not changed.
    digest: bytes

    # The lines needing position translation, by zero-based line
    # number: only lines containing a character outside ASCII, since
    # an ASCII line's columns count the same in UTF-8 bytes and
    # UTF-16 code units. Empty for a typical file.
    lines: Mapping[int, str]


class Pyright:
    """One running pyright language server, answering questions.

    `start` it and ask with `definition_at` and
    `type_definition_at`, handing each the text its position came
    from; `type_at` takes a `sync` of the file's text first.
    Positions are given the way `ast` gives them: lines from one,
    columns from zero.
    """

    def __init__(self) -> None:
        self._process: Optional[asyncio.subprocess.Process] = None
        self._ids = itertools.count(1)
        self._responses: dict[int, asyncio.Future[Any]] = {}
        # Reads the server's messages from its stdout; see `_read`.
        self._stdout_reader: Optional[asyncio.Task[None]] = None
        # Reads everything the server writes to its stderr, as it is
        # written, so that it never blocks on a full pipe, and keeps
        # it to say why the server exited if it does. A server that
        # runs fine writes nothing there.
        self._stderr_reader: Optional[asyncio.Task[bytes]] = None
        # For each file that we `sync` to Pyright we keep around a
        # version number (required by Pyright) and a digest (to skip
        # syncing the file if its text has not changed). Keyed by the
        # file's resolved path, so that neither changing directories
        # between calls nor a symlink can confuse two spellings of
        # one file.
        self._synced: dict[Path, _Synced] = {}

    async def start(
        self,
        *,
        root: Path,
        extra_paths: Sequence[Path],
    ) -> None:
        """Starts the server over `root`, resolving imports through
        `extra_paths`, such as the directory `rbt generate` writes to,
        and through the packages installed for the interpreter
        `reboot` runs in."""
        # The `pyright` package's own language server entry point,
        # run with the interpreter `reboot` is installed into, so
        # that nothing depends on the `PATH`; the package, a
        # dependency of `reboot`, brings the server and, through its
        # `[nodejs]` extra, the Node it runs on.
        #
        # The entry point runs the Node server as a child of its own,
        # holding our pipes, rather than becoming it. In a session of
        # its own, the entry point and the Node server form a process
        # group that `stop` can kill as one.
        #
        # The Node server's heap is set through `NODE_OPTIONS`, which
        # the entry point passes on to it, so that the developer need
        # not know that Node is involved to give it enough.
        self._process = await asyncio.create_subprocess_exec(
            sys.executable,
            '-m',
            'pyright.langserver',
            '--stdio',
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True,
            env={
                **os.environ,
                'NODE_OPTIONS':
                    ' '.join(
                        [
                            # First, so that a limit the developer set in
                            # their own `NODE_OPTIONS` comes later and wins.
                            f'--max-old-space-size={HEAP_MEGABYTES}',
                            os.environ.get('NODE_OPTIONS', ''),
                        ]
                    ),
            },
        )

        self._stdout_reader = asyncio.create_task(self._read())
        assert self._process.stderr is not None
        self._stderr_reader = asyncio.create_task(self._process.stderr.read())

        response = await self._request(
            'initialize',
            {
                'processId': os.getpid(),
                'rootUri': root.resolve().as_uri(),
                'capabilities': {},
                'initializationOptions': {},
            },
        )

        # The protocol counts positions in UTF-16 code units unless a
        # client offers other encodings, which this one does not:
        # `_position` translates every column into UTF-16 code units.
        # A server answering with anything else is not following the
        # protocol.
        encoding = response.get('capabilities',
                                {}).get('positionEncoding', 'utf-16')
        if encoding != 'utf-16':
            raise ValueError(
                'Expected pyright to count positions in UTF-16 code '
                f"units, the protocol's default, but it answered "
                f"'{encoding}'"
            )

        await self._notify('initialized', {})
        await self._notify(
            'workspace/didChangeConfiguration',
            {
                'settings':
                    {
                        'python':
                            {
                                # The server resolves imports through
                                # the search paths of an interpreter
                                # it is told about, not the one it was
                                # launched with; without this it asks
                                # whichever `python` is on the `PATH`,
                                # whose packages are not `reboot`'s,
                                # so an import of an installed state
                                # type resolves to nothing.
                                'pythonPath': sys.executable,
                                'analysis':
                                    {
                                        'extraPaths':
                                            [
                                                str(path)
                                                for path in extra_paths
                                            ],
                                        'typeCheckingMode': 'basic',
                                        'useLibraryCodeForTypes': True,
                                    }
                            }
                    }
            },
        )

    async def stop(self) -> None:
        """Stops the server, the Node process it runs included.
        Questions after this raise."""
        if self._process is not None and self._process.returncode is None:
            try:
                # Asked the way the protocol defines, the Node server
                # exits by itself; the entry point, whose child it is,
                # then reaps it and exits too, closing our pipes.
                await asyncio.wait_for(
                    self._request('shutdown'), SHUTDOWN_SECONDS
                )
                await self._notify('exit')
                await asyncio.wait_for(self._process.wait(), SHUTDOWN_SECONDS)
            except (asyncio.TimeoutError, RuntimeError):
                # The server didn't shut down when asked, so kill the
                # entry point and the Node server together: starting the
                # server in a session of its own put both in one process
                # group.
                #
                # Then wait only for the entry point, which is our own
                # child. Don't wait for the Node server: with its parent
                # gone it now belongs to whichever process adopted it,
                # and a dead process only fully disappears once that
                # adopter collects it. Under `rbt dashboard` the adopter
                # is the CLI, which collects only when the dashboard
                # exits. Its pipes close the moment it dies, so waiting
                # for the entry point is enough.
                try:
                    os.killpg(self._process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                await self._process.wait()
        if self._stdout_reader is not None:
            self._stdout_reader.cancel()
        if self._stderr_reader is not None:
            self._stderr_reader.cancel()

    async def sync(
        self,
        *,
        filename: Path,
        text: str,
    ) -> None:
        """Sync the specified `text` with Pyright so it uses that
        text to resolve any subsequent queries. If the `text` for
        `filename` has not changed then nothing is sent to
        Pyright."""
        filename = filename.resolve()
        digest = hashlib.sha256(text.encode()).digest()

        file = self._synced.get(filename)
        if file is None:
            await self._notify(
                'textDocument/didOpen',
                {
                    'textDocument':
                        {
                            'uri': filename.as_uri(),
                            'languageId': 'python',
                            'version': 1,
                            'text': text,
                        }
                },
            )
            self._synced[filename] = _Synced(
                version=1,
                digest=digest,
                lines=(
                    {
                        index: line
                        for index, line in enumerate(text.splitlines())
                        if not line.isascii()
                    } if not text.isascii() else {}
                ),
            )
            return

        if file.digest == digest:
            return

        version = file.version + 1
        await self._notify(
            'textDocument/didChange',
            {
                'textDocument': {
                    'uri': filename.as_uri(),
                    'version': version,
                },
                'contentChanges': [{
                    'text': text
                }],
            },
        )
        self._synced[filename] = _Synced(
            version=version,
            digest=digest,
            lines=(
                {
                    index: line
                    for index, line in enumerate(text.splitlines())
                    if not line.isascii()
                } if not text.isascii() else {}
            ),
        )

    def synced(self) -> list[Path]:
        """Returns every file whose text is synced, each in the
        resolved spelling `sync` keys files by."""
        return list(self._synced)

    async def discard(self, *, filename: Path) -> None:
        """Tells Pyright to discard previously synced text at
        `filename`. If the file has since been deleted Pyright should
        properly detect that because it is no longer on disk."""
        filename = filename.resolve()
        if filename not in self._synced:
            return

        await self._notify(
            'textDocument/didClose',
            {'textDocument': {
                'uri': filename.as_uri(),
            }},
        )
        del self._synced[filename]

    async def type_at(
        self,
        *,
        filename: Path,
        line: int,
        character: int,
    ) -> Optional[str]:
        """Returns the type of the expression at a position in the
        text of the specified `filename`, which must have been synced
        with Pyright already or a `ValueError` is raised. Note
        that the type returned is not always a fully qualified name,
        and as such may not be entirely useful without more context.
        If the type is `Unknown`, or if Pyright doesn't know for some
        other reason (e.g., it is missing files it needs to infer the
        type, such as files that might need to be generated by the
        build system), then `None` is returned.
        """
        filename = self._synced_filename(filename)
        response = await self._request(
            'textDocument/hover',
            self._position(
                filename=filename,
                line=line,
                character=character,
            ),
        )

        if response is None:
            return None

        contents = response.get('contents')
        if isinstance(contents, dict):
            contents = contents.get('value', '')
        if not isinstance(contents, str):
            return None

        # Pyright writes hovers like `(variable) shop: Shop` or
        # `(class) Shop`; the type is what follows the last `: ` on
        # the first line that has one.
        for line_of in contents.splitlines():
            if ': ' in line_of:
                result = line_of.rsplit(': ', 1)[1].strip('` ')
                if result and 'Unknown' not in result:
                    return result
                return None

        return None

    async def definition_at(
        self,
        *,
        filename: Path,
        line: int,
        character: int,
        text: str,
    ) -> Optional[Location]:
        """Returns the definition for the name at the position in
        `text`, or `None` when Pyright can not determine the
        definition (e.g., it is missing files it needs to find the
        definition, such as files that might need to be generated by
        the build system).

        `text` must be the text of `filename` the position came
        from, so that the answer cannot be about a file that changed
        underneath the asking; it is synced first, which `sync`
        deduplicates by digest."""
        return await self._location_at(
            'textDocument/definition',
            filename=filename,
            line=line,
            character=character,
            text=text,
        )

    async def type_definition_at(
        self,
        *,
        filename: Path,
        line: int,
        character: int,
        text: str,
    ) -> Optional[Location]:
        """Returns where the type of the expression at the position
        in `text` is defined: e.g. the `class ShopServicer` that a
        base spelled `Shop.Servicer` refers to, resolved through
        however the expression gets there, an alias like the
        generator's `Servicer: TypeAlias = ShopServicer`, a chain
        of assignments, a name imported from anywhere, or a
        function's return type. `None` when Pyright can not
        determine the type, such as when generated code has not
        been written yet.

        `text` must be the text of `filename` the position came
        from, so that the answer cannot be about a file that changed
        underneath the asking; it is synced first, which `sync`
        deduplicates by digest."""
        return await self._location_at(
            'textDocument/typeDefinition',
            filename=filename,
            line=line,
            character=character,
            text=text,
        )

    async def _location_at(
        self,
        method: str,
        *,
        filename: Path,
        line: int,
        character: int,
        text: str,
    ) -> Optional[Location]:
        """Returns the first location a request answering with
        locations answers, as a `Location`, and `None` for an
        empty answer."""
        await self.sync(filename=filename, text=text)
        filename = self._synced_filename(filename)
        response = await self._request(
            method,
            self._position(
                filename=filename,
                line=line,
                character=character,
            ),
        )

        match response:
            case [
                {
                    'uri': str(uri),
                    'range': {
                        'start': {
                            'line': int(line_at),
                        }
                    },
                }, *_
            ] if uri.startswith('file://'):
                return Location(
                    filename=Path(uri[len('file://'):]),
                    line=line_at + 1,
                )

        return None

    def _synced_filename(self, filename: Path) -> Path:
        """Returns the file's resolved spelling, the way `_synced`
        keys it, refusing a file whose text was never synced."""
        filename = filename.resolve()
        if filename not in self._synced:
            raise ValueError(
                f'`{filename}` has not been synced; call `sync` with '
                'its text before asking about it'
            )
        return filename

    def _utf16_character(
        self,
        *,
        filename: Path,
        line: int,
        character: int,
    ) -> int:
        """Returns a column counted in UTF-16 code units, the way
        the protocol counts, from one counted in UTF-8 bytes, the
        way `ast` counts."""
        line_text = self._synced[filename].lines.get(line - 1)
        if line_text is None:
            return character

        prefix = line_text.encode()[:character].decode()
        return len(prefix.encode('utf-16-le')) // 2

    def _position(
        self,
        *,
        filename: Path,
        line: int,
        character: int,
    ) -> dict[str, Any]:
        character = self._utf16_character(
            filename=filename,
            line=line,
            character=character,
        )
        return {
            'textDocument': {
                'uri': filename.as_uri()
            },
            'position': {
                'line': line - 1,
                'character': character,
            },
        }

    async def _request(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
    ) -> Any:
        assert self._process is not None and self._process.stdin is not None
        id = next(self._ids)
        future: asyncio.Future[Any] = asyncio.get_running_loop().create_future(
        )
        self._responses[id] = future
        # A method that takes no parameters, such as `shutdown`, is sent
        # without any.
        message: dict[str, Any] = {
            'jsonrpc': '2.0',
            'id': id,
            'method': method
        }
        if params is not None:
            message['params'] = params
        self._write(message)
        await self._process.stdin.drain()
        return await future

    async def _notify(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
    ) -> None:
        assert self._process is not None and self._process.stdin is not None
        message: dict[str, Any] = {'jsonrpc': '2.0', 'method': method}
        if params is not None:
            message['params'] = params
        self._write(message)
        await self._process.stdin.drain()

    def _write(self, message: dict[str, Any]) -> None:
        assert self._process is not None and self._process.stdin is not None
        body = json.dumps(message).encode()
        self._process.stdin.write(
            b'Content-Length: %d\r\n\r\n%s' % (len(body), body)
        )

    async def _read(self) -> None:
        assert self._process is not None and self._process.stdout is not None
        while True:
            length = 0
            ended = False
            while True:
                header = await self._process.stdout.readline()
                if not header:
                    ended = True
                    break
                if header.startswith(b'Content-Length:'):
                    length = int(header.split(b':')[1])
                if header == b'\r\n':
                    break
            if ended:
                # The server died. Whoever is waiting on it finds
                # out now rather than waiting forever, and why, with
                # everything it wrote to its stderr, such as Node's
                # own "JavaScript heap out of memory".
                #
                # What it wrote as it died may still be arriving, so
                # its stderr is read to the end, but not waited on
                # forever: a Node server orphaned by the entry point
                # could hold it open.
                assert self._stderr_reader is not None
                await asyncio.wait(
                    [self._stderr_reader],
                    timeout=SHUTDOWN_SECONDS,
                )
                message = 'pyright exited'
                if (
                    self._stderr_reader.done() and
                    not self._stderr_reader.cancelled() and
                    self._stderr_reader.exception() is None
                ):
                    stderr = self._stderr_reader.result().decode(
                        # Decoded with `errors='replace'` so that bytes
                        # that aren't UTF-8 can't raise here, which would
                        # end this task before the pending requests below
                        # are failed, leaving them waiting forever.
                        errors='replace',
                    ).strip()
                    if stderr != '':
                        message += f': {stderr}'
                for future in self._responses.values():
                    if not future.done():
                        future.set_exception(RuntimeError(message))
                self._responses.clear()
                return
            body = json.loads(await self._process.stdout.readexactly(length))
            # A body with both an `id` and a `method` is a
            # server-to-client request, which must be answered or the
            # server waits on us the way we wait on it.
            if 'id' in body and 'method' in body:
                self._write(
                    {
                        'jsonrpc': '2.0',
                        'id': body['id'],
                        'result': None,
                    }
                )
                continue
            if 'id' in body:
                waiting = self._responses.pop(body['id'], None)
                if waiting is not None and not waiting.done():
                    waiting.set_result(body.get('result'))
