import datetime, fcntl, hashlib, json, os, pathlib, signal, subprocess, sys, time
root=pathlib.Path('/home/benchbuild/.cache/declared-writer-20261020-src')
evidence=pathlib.Path('/home/benchbuild/.cache/declared-writer-20261020-evidence')
evidence.mkdir(exist_ok=True)
stage=sys.argv[1]
locks=[]
for path in ['/home/benchbuild/reboot-rust/.cargo-target-acceptance/.declared-writer-owner.lock','/home/benchbuild/.cargo/.declared-writer-owner.lock']:
    handle=open(path,'a+'); fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB); locks.append(handle)
env=os.environ.copy(); env.update(CARGO_HOME='/home/benchbuild/.cargo',CARGO_TARGET_DIR='/home/benchbuild/reboot-rust/.cargo-target-acceptance',CARGO_BUILD_JOBS='2',PATH='/home/benchbuild/.cargo/bin:'+env['PATH'], REBOOT_NATIVE2PC_CXX_DATABASE='/home/benchbuild/.cache/hello-image-evidence/rust-context/database')
command=sys.argv[2:]
temp=evidence/'tmp'; temp.mkdir(exist_ok=True); env['TMPDIR']=str(temp)
def inputs():
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.suffix in ['.rs','.proto','.py','.toml','.lock'] and 'target' not in p.parts}
record={'stage':stage,'owner_pid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'source_inputs':inputs(),'children':[],'complete':False}
try:
    with (evidence/(stage+'.log')).open('wb') as out:
        p=subprocess.Popen(command,cwd=root/'reboot/rust',env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        record['children'].append({'pid':p.pid,'parent_pid':os.getpid()})
        try: p.wait(timeout=500)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try: p.wait(timeout=15)
            except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
            record['timed_out']=True
        record['children'][0].update(wait_returncode=p.returncode,waited_by_owner=True)
        record['complete']=True
finally:
    record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['source_unchanged'] = inputs() == record['source_inputs']
    (evidence/(stage+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k != 'source_inputs'})); print((evidence/(stage+'.log')).read_text()[-18000:])
sys.exit(0 if record['complete'] and p.returncode==0 and not record.get('timed_out') else 1)
