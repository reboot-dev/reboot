import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path('/home/benchbuild/.cache/declared-writer-20261020-src/reboot/rust')
evidence=pathlib.Path('/home/benchbuild/.cache/declared-writer-20261020-evidence')/sys.argv[1]
evidence.mkdir(exist_ok=False)
source=root/'src/ordinary_writer_store.rs'
original=source.read_bytes()
old=b'declared = Some(durable_declared_status(&mutation.response)?);'
assert original.count(old)==1
red=original.replace(old,b'continue; // RED: omit only durable target error replay')
record={'owner_pid':os.getpid(),'original_sha256':hashlib.sha256(original).hexdigest(),'red_sha256':hashlib.sha256(red).hexdigest(),'children':[]}
def run(stage,args):
    with (evidence/(stage+'.log')).open('wb') as out:
        p=subprocess.Popen(args,cwd=root,stdout=out,stderr=subprocess.STDOUT)
        p.wait(timeout=180)
        record['children'].append({'pid':p.pid,'parent_pid':os.getpid(),'command':args,'returncode':p.returncode,'waited_by_parent':True})
    return p.returncode
try:
    source.write_bytes(red)
    assert run('red-build',['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'])==0
    code=run('red-native',['python3','tests/fixtures/workflow_app/prove_declared.py',os.environ['CARGO_TARGET_DIR']+'/debug/generated-workflow-app',str(evidence/'red-native')])
    assert code!=0, 'negative control unexpectedly passed'
    text=(evidence/'red-native.log').read_text()
    assert "lines().count('remote-declared-handler') == 1" in text, text
    record['invariant_specific_red']=True
finally:
    source.write_bytes(original)
    record['restored']=source.read_bytes()==original
    code=run('restored-build',['cargo','build','--locked','--offline','--manifest-path','tests/fixtures/workflow_app/Cargo.toml'])
    record['restored_build_returncode']=code
    (evidence/'red-control.json').write_text(json.dumps(record,indent=2))
assert record['restored'] and code==0
print(json.dumps(record))
